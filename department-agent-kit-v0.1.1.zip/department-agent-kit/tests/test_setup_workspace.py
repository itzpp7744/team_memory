"""End-to-end tests: all writable data lives in temporary directories."""
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import stat
from types import SimpleNamespace
from unittest.mock import patch
import tempfile
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / 'scripts' / 'setup_workspace.py'


class WorkspaceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='department agent 中文 ')
        self.base = Path(self.temp.name).resolve()
        self.private = self.base / '私有 工作區'
        self.shared = self.base / '共同 專案'
        self.shared.mkdir()
        self.addCleanup(self.temp.cleanup)

    def run_cli(self, command, *extra, ok=True, private=None, shared=None, member='Wilson', project='project-a'):
        args = [sys.executable, str(SCRIPT), command, '--private-root', str(private or self.private)]
        if command in ('plan', 'install'):
            args += ['--shared-root', str(shared or self.shared), '--member', member, '--project', project]
        args += list(extra)
        result = subprocess.run(args, text=True, capture_output=True, encoding='utf-8')
        self.assertEqual(result.returncode, 0 if ok else 2, result.stdout + result.stderr)
        self.assertTrue(result.stdout.startswith("{"), result.stdout + result.stderr)
        return json.loads(result.stdout)

    def test_plan_writes_nothing_and_marks_unverified(self):
        result = self.run_cli('plan')
        self.assertFalse(self.private.exists())
        self.assertEqual(list(self.shared.iterdir()), [])
        self.assertEqual(result['sync_status'], 'UNVERIFIED')
        self.assertEqual(result['cloud_status'], 'NOT_CONFIGURED')
        self.assertIn(str(self.private / '.department-agent' / 'config.json'), result.get('planned_files', []))
        self.assertIn(str(self.shared / '99_同步驗收'), result.get('planned_directories', []))

    def test_install_idempotent_preserves_custom_instructions_and_user_files(self):
        self.private.mkdir()
        (self.private / 'CLAUDE.md').write_text('我的自訂規則', encoding='utf-8')
        (self.shared / '40_已核准交付').mkdir()
        original = self.shared / '40_已核准交付' / '報告.txt'
        original.write_text('已核准原稿', encoding='utf-8')
        result = self.run_cli('install')
        config = self.private / '.department-agent' / 'config.json'
        before = config.read_bytes()
        self.run_cli('install')
        self.assertEqual(config.read_bytes(), before)
        self.assertEqual((self.private / 'CLAUDE.md').read_text(encoding='utf-8'), '我的自訂規則')
        self.assertEqual(original.read_text(encoding='utf-8'), '已核准原稿')
        self.assertIn('.department-agent/WORKSPACE.md', result['additional_instruction'])
        self.assertTrue((self.shared / '80_修改提案' / 'Avril').is_dir())
        self.assertEqual(result['sync_status'], 'UNVERIFIED')
        self.assertEqual(self.run_cli('doctor')['cloud_status'], 'NOT_CONFIGURED')

    def test_roots_overlap_rejected_without_writes(self):
        for private, shared in [(self.shared, self.shared), (self.shared / 'private', self.shared), (self.base, self.shared)]:
            self.run_cli('install', private=private, shared=shared, ok=False)
        self.assertEqual(list(self.shared.iterdir()), [])

    def test_home_and_filesystem_root_rejected(self):
        for private in [Path.home(), Path(self.base.anchor)]:
            self.run_cli('install', private=private, ok=False)
        self.assertEqual(list(self.shared.iterdir()), [])

    def test_repository_root_rejected(self):
        self.run_cli('install', private=SCRIPT.parents[1] / 'invalid-workspace', ok=False)

    def test_missing_shared_root_rejected(self):
        self.run_cli('install', shared=self.base / 'does-not-exist', ok=False)
        self.assertFalse(self.private.exists())

    def test_symlink_escape_rejected_before_writes(self):
        outside = self.base / 'outside'
        outside.mkdir()
        try:
            (self.shared / '80_修改提案').symlink_to(outside, target_is_directory=True)
        except (OSError, NotImplementedError):
            self.skipTest('This Windows account cannot create symlinks')
        self.run_cli('install', ok=False)
        self.assertFalse(self.private.exists())
        self.assertEqual(list(outside.iterdir()), [])

    def test_nested_symlink_rejected(self):
        approved = self.shared / '40_已核准交付'
        approved.mkdir()
        try:
            (approved / 'external').symlink_to(self.base, target_is_directory=True)
        except (OSError, NotImplementedError):
            self.skipTest('This Windows account cannot create symlinks')
        self.run_cli('install', ok=False)
        self.assertFalse(self.private.exists())

    def test_root_and_ancestor_symlinks_rejected_before_resolve(self):
        outside = self.base / 'outside'
        outside.mkdir()
        alias = self.base / 'alias'
        try:
            alias.symlink_to(outside, target_is_directory=True)
        except (OSError, NotImplementedError):
            self.skipTest('This Windows account cannot create symlinks')
        for private, shared in [
            (alias, self.shared), (alias / 'new-workspace', self.shared),
            (self.private, alias),
        ]:
            with self.subTest(private=private, shared=shared):
                self.run_cli('install', private=private, shared=shared, ok=False)
                self.assertEqual(list(outside.iterdir()), [])
                self.assertEqual(list(self.shared.iterdir()), [])
        (outside / 'existing').mkdir()
        self.run_cli('install', shared=alias / 'existing', ok=False)
        self.assertFalse(self.private.exists())

    @unittest.skipUnless(sys.platform == 'darwin', 'macOS system aliases only')
    def test_macos_system_aliases_remain_usable(self):
        for alias in ('/var', '/tmp'):
            with self.subTest(alias=alias):
                if alias == '/var' and not self.base.is_relative_to('/private/var'):
                    self.skipTest('Temporary directory is outside /private/var')
                parent = str(Path('/var') / self.base.relative_to('/private/var')) if alias == '/var' else '/tmp'
                with tempfile.TemporaryDirectory(dir=parent, prefix='department-alias-') as temporary:
                    lexical = Path(temporary)
                    shared = lexical / 'shared'
                    shared.mkdir()
                    result = self.run_cli('plan', private=lexical / 'private', shared=shared)
                    self.assertEqual(result['shared_root'], str(shared.resolve()))
                    self.assertFalse((lexical / 'private').exists())

    def test_error_without_mcp_reports_not_configured(self):
        result = self.run_cli('install', shared=self.base / 'missing', ok=False)
        self.assertEqual(result['cloud_status'], 'NOT_CONFIGURED')

    def test_probe_identity_uses_exact_bytes_checked_by_hash(self):
        self.run_cli('install')
        probe = self.run_cli('probe-create')
        peer = self.base / 'peer'
        self.run_cli('install', private=peer, member='Avril')
        spec = importlib.util.spec_from_file_location('workspace_installer', SCRIPT)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        prepared = module.inspect_workspace(str(peer))
        contents = Path(probe['probe_path']).read_bytes()
        replaced = json.loads(contents)
        replaced['member'] = 'Avril'
        with patch.object(module, 'read_bytes', side_effect=[contents, json.dumps(replaced).encode('utf-8')]) as reads:
            try:
                result = module.verify_probe(prepared, probe['probe_id'], probe['sha256'])
            except module.WorkspaceError as exc:
                self.fail(f'Identity must come from the original hashed bytes: {exc}')
        self.assertEqual(result['sender'], 'Wilson')
        self.assertEqual(reads.call_count, 1)

    def test_windows_junction_reparse_tag_is_rejected_on_python_311(self):
        # Simulate only Windows metadata; the integration tests use real files.
        spec = importlib.util.spec_from_file_location('workspace_installer', SCRIPT)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        path = self.base / 'junction'
        path.mkdir()
        metadata = SimpleNamespace(st_mode=stat.S_IFDIR, st_reparse_tag=0xA0000003)
        with patch.object(type(path), 'lstat', return_value=metadata):
            with self.assertRaises(module.WorkspaceError):
                module.check_tree(path)

    def installer_module(self):
        spec = importlib.util.spec_from_file_location('workspace_installer', SCRIPT)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def test_interleaved_members_cannot_report_wrong_ready_config(self):
        module = self.installer_module()
        wilson = module.prepare('Wilson', 'project-a', str(self.private), str(self.shared), None)
        avril = module.prepare('Avril', 'project-a', str(self.private), str(self.shared), None)
        module.install(wilson)
        with self.assertRaises(module.WorkspaceError):
            module.install(avril)
        actual = json.loads((self.private / '.department-agent/config.json').read_bytes())
        self.assertEqual(actual['member'], 'Wilson')

    def test_matching_exclusive_create_race_remains_idempotent(self):
        module = self.installer_module()
        prepared = module.prepare('Wilson', 'project-a', str(self.private), str(self.shared), None)
        original_write = module.exclusive_write
        raced = False

        def concurrent_write(path, data):
            nonlocal raced
            if path.name == 'config.json' and not raced:
                raced = True
                original_write(path, data)
                raise FileExistsError(str(path))
            original_write(path, data)

        with patch.object(module, 'exclusive_write', side_effect=concurrent_write):
            try:
                result = module.install(prepared)
            except FileExistsError as exc:
                self.fail(f'An identical concurrently created config must be compared: {exc}')
        self.assertEqual(result['member'], 'Wilson')
        self.assertEqual(result['local_status'], 'READY')

    def test_final_verification_rejects_config_replaced_during_install(self):
        module = self.installer_module()
        prepared = module.prepare('Wilson', 'project-a', str(self.private), str(self.shared), None)
        original_write = module.exclusive_write

        def concurrent_write(path, data):
            original_write(path, data)
            if path.name == 'CLAUDE.md':
                config_path = self.private / '.department-agent/config.json'
                changed = json.loads(config_path.read_bytes())
                changed['member'] = 'Avril'
                config_path.write_bytes(module.encoded(changed))

        with patch.object(module, 'exclusive_write', side_effect=concurrent_write):
            with self.assertRaises(module.WorkspaceError):
                module.install(prepared)

    def test_config_collision_refuses_all_changes(self):
        self.run_cli('install')
        config = self.private / '.department-agent' / 'config.json'
        before = config.read_bytes()
        self.run_cli('install', member='Avril', ok=False)
        self.assertEqual(config.read_bytes(), before)

    def test_workspace_instruction_collision_refuses_all_changes(self):
        owned = self.private / '.department-agent'
        owned.mkdir(parents=True)
        (owned / 'WORKSPACE.md').write_text('使用者資料', encoding='utf-8')
        self.run_cli('install', ok=False)
        self.assertFalse((owned / 'config.json').exists())
        self.assertEqual(list(self.shared.iterdir()), [])

    def test_invalid_mcp_urls_rejected_without_writes(self):
        for url in ['http://example.com/mcp', 'https://localhost/mcp', 'https://127.0.0.1/mcp', 'https://[::1]/mcp', 'https://user:pass@example.com/mcp', 'https://example.com/mcp?token=x', 'https://example.com/mcp#token', 'https://example.com:invalid/mcp', 'https://example.com/mcp?']:
            with self.subTest(url=url):
                self.run_cli('install', '--mcp-url', url, ok=False)
                self.assertFalse(self.private.exists())

    def test_mcp_merge_preserves_unrelated_entries(self):
        self.private.mkdir()
        path = self.private / '.mcp.json'
        old = {'mcpServers': {'existing': {'type': 'http', 'url': 'https://example.org/other'}}, 'custom': True}
        path.write_text(json.dumps(old), encoding='utf-8')
        result = self.run_cli('install', '--mcp-url', 'https://example.com/mcp')
        merged = json.loads(path.read_text(encoding='utf-8'))
        self.assertEqual(merged['mcpServers']['existing'], old['mcpServers']['existing'])
        self.assertTrue(merged['custom'])
        self.assertEqual(merged['mcpServers']['department-agent'], {'type': 'http', 'url': 'https://example.com/mcp'})
        self.assertEqual(result['cloud_status'], 'UNVERIFIED')
        self.run_cli('install', '--mcp-url', 'https://example.com/mcp')
        self.assertFalse((self.shared / '.mcp.json').exists())

    def test_mcp_collision_rejected_before_any_generated_file(self):
        self.private.mkdir()
        path = self.private / '.mcp.json'
        path.write_text(json.dumps({'mcpServers': {'department-agent': {'url': 'https://other.example/mcp'}}}), encoding='utf-8')
        self.run_cli('install', '--mcp-url', 'https://example.com/mcp', ok=False)
        self.assertFalse((self.private / '.department-agent').exists())
        self.assertEqual(list(self.shared.iterdir()), [])

    def test_doctor_missing_folder_fails(self):
        self.run_cli('install')
        (self.private / 'drafts').rmdir()
        result = self.run_cli('doctor', ok=False)
        self.assertEqual(result['cloud_status'], 'NOT_CONFIGURED')

    def test_probe_peer_verification_and_tamper(self):
        self.run_cli('install')
        probe = self.run_cli('probe-create')
        args = ['--probe-id', probe['probe_id'], '--sha256', probe['sha256']]
        self.run_cli('probe-verify', *args, ok=False)
        peer_shared = self.base / 'peer shared'
        shutil.copytree(self.shared, peer_shared)
        peer_private = self.base / 'peer private'
        self.run_cli('install', member='Avril', private=peer_private, shared=peer_shared)
        verified = self.run_cli('probe-verify', *args, private=peer_private)
        self.assertEqual(verified['sync_status'], 'UNVERIFIED')
        self.assertEqual(verified['peer_file_status'], 'VERIFIED')
        path = peer_shared / '99_同步驗收' / (probe['probe_id'] + '.json')
        path.write_text(path.read_text(encoding='utf-8') + ' ', encoding='utf-8')
        self.run_cli('probe-verify', *args, private=peer_private, ok=False)

    def test_probe_project_mismatch_rejected(self):
        self.run_cli('install')
        probe = self.run_cli('probe-create')
        peer = self.base / 'peer'
        self.run_cli('install', private=peer, member='Avril', project='other-project')
        self.run_cli('probe-verify', '--probe-id', probe['probe_id'], '--sha256', probe['sha256'], private=peer, ok=False)


if __name__ == '__main__':
    unittest.main()
