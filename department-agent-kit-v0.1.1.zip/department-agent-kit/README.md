# 部門 AI 工作區安裝包

把這個儲存庫交給 Wilson 或 Avril 的 AI，請它從 [START_HERE.md](START_HERE.md) 開始。本包提供本機安裝器、工作範本與管理者要部署的服務程式；下載完成不代表雲端服務已上線。

## 三個位置各放什麼

| 位置 | 用途 |
| --- | --- |
| GitHub 儲存庫 | 放程式、安裝說明與空白範本。下載到共享文件區以外的位置，不提交工作文件或私人設定。 |
| 個人私有工作區 | 放 AI 草稿、暫存與本機設定。選擇不會同步給同事的專用資料夾。 |
| SharePoint／OneDrive 共享專案資料夾 | SharePoint 是公司的文件存放處；OneDrive 用戶端把選定文件同步到電腦。雙方各自登入公司 Microsoft 帳號，選到同一個專案。 |

Neon 是服務端使用的雲端資料庫，保存共用記憶與正式待辦。文件仍放在 SharePoint。範本只引用待辦編號，不另養一份狀態表。

Claude 個人帳號與公司 Microsoft 帳號是兩個身分。各人用自己的 Claude，再由自己的公司 Microsoft 帳號授權資料存取；不要共用密碼、登入憑證或資料庫金鑰。

交付儲存庫：[itzpp7744/team_memory](https://github.com/itzpp7744/team_memory)。

Avril 的第二台公司電腦沿用 `Avril` 身分、相同專案代號與公司 Microsoft 帳號；各台電腦分別執行安裝，填自己的實際路徑。若第二台是 Windows，使用下方 Windows 指令並把 `--member Wilson` 改成 `--member Avril`。不要複製另一台的 `.department-agent` 或 `.mcp.json`，其中含有該機路徑。私有草稿不會自動跨裝置；要接續的內容需由本人選入共享提案區。

## 安裝指令範例

需要 Python 3.11 或更新版本。本機安裝器只用 Python 內建功能，不必安裝服務端套件。請在下載後的儲存庫目錄執行。

下列 `YOUR_NAME`、公司／路徑名稱、`sample-project` 都是示例，必須換成本人確認的實際值。共享路徑要先存在；不要為了讓指令通過而隨便建立一個假同步資料夾。`--member` 可用 `Wilson` 或 `Avril`；兩人使用同一個專案代號。

macOS（Avril 主力電腦）：

```sh
python3 --version
python3 scripts/setup_workspace.py plan --member Avril --project sample-project --private-root "/Users/YOUR_NAME/AgentWork/sample-project" --shared-root "/Users/YOUR_NAME/Library/CloudStorage/OneDrive-COMPANY/SharedProject"
python3 scripts/setup_workspace.py install --member Avril --project sample-project --private-root "/Users/YOUR_NAME/AgentWork/sample-project" --shared-root "/Users/YOUR_NAME/Library/CloudStorage/OneDrive-COMPANY/SharedProject"
python3 scripts/setup_workspace.py doctor --private-root "/Users/YOUR_NAME/AgentWork/sample-project"
```

Windows PowerShell（Wilson）：

```powershell
py -3 --version
py -3 scripts/setup_workspace.py plan --member Wilson --project sample-project --private-root "C:\Users\YOUR_NAME\AgentWork\sample-project" --shared-root "C:\Users\YOUR_NAME\OneDrive - COMPANY\SharedProject"
py -3 scripts/setup_workspace.py install --member Wilson --project sample-project --private-root "C:\Users\YOUR_NAME\AgentWork\sample-project" --shared-root "C:\Users\YOUR_NAME\OneDrive - COMPANY\SharedProject"
py -3 scripts/setup_workspace.py doctor --private-root "C:\Users\YOUR_NAME\AgentWork\sample-project"
```

`plan` 只列出預計建立的資料夾與檔案；`install` 才寫入；`doctor` 檢查本機設定。私有、共享與儲存庫路徑必須分開，不能互相包含。相同設定可以重跑；不同設定會拒絕覆寫。

已有 `AGENTS.md` 或 `CLAUDE.md` 會原樣保留。AI 必須另外讀取私有工作區的 `.department-agent/WORKSPACE.md`，不能因為原有指示檔未改就跳過它。

## 怎樣才算完成

| 回報 | 代表什麼 |
| --- | --- |
| `local_status: READY` | 本機資料夾與設定已通過檢查。 |
| `cloud_status: NOT_CONFIGURED` | 本機尚未設定部門 MCP 網址。MCP 是讓 AI 呼叫外部工具的介面。 |
| `cloud_status: UNVERIFIED` | 有設定網址，但還沒證明登入、權限與工具操作成功。 |
| `peer_file_status: VERIFIED` | 對方的指定驗收檔已出現在這裡，檔案指紋一致。 |
| `sync_status: UNVERIFIED` | 程式無法判定檔案由哪個同步服務送達；這個欄位不會自行變成成功。 |

雙方仍要完成 [驗收清單](docs/ACCEPTANCE.md)。本包已在 macOS 執行本機安裝器測試；本機暫存 PostgreSQL（資料庫軟體）的權限、重試與同時修改也已通過整合測試。Windows 實機與 Windows CI（GitHub 自動測試）、真實 Neon、公司登入及跨電腦同步，仍須另外留下驗收證據。

## 雲端接通與日常文件

管理者先依 [ADMIN_SETUP.md](docs/ADMIN_SETUP.md) 部署服務，再提供正式 HTTPS（加密連線）網址。收到之前可以完成本機安裝與雙向檔案驗收，雲端部分保留待辦。

若第一次安裝時已拿到網址，在 `plan`、`install` 兩個指令都加上 `--mcp-url "https://YOUR-SERVICE.example/mcp"`；這是佔位網址，不能直接拿來連線。若先前已用空網址安裝，請依 [START_HERE.md](START_HERE.md) 的後續接通步驟處理，不要直接修改受管設定。

可用範本：[需求文件](templates/PRD.md)、[會議紀錄](templates/MEETING.md)、[簡報需求](templates/PRESENTATION_BRIEF.md)。複製到私有 `drafts` 開始寫，送審時只放自己的 `80_修改提案/Wilson` 或 `80_修改提案/Avril`。正式原稿由負責人審閱後更新。

資料庫金鑰留在管理者的服務端。兩人的電腦不需要這些金鑰，也不要把 API Key（程式存取服務的密鑰）寫進設定檔或 `.env`。不整批上傳個人聊天紀錄。

驗證細節：[交付前驗證](docs/VERIFICATION.md)、[已知限制](docs/KNOWN_LIMITATIONS.md)。
