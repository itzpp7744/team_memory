# Claude 安裝入口

先讀 [AGENTS.md](AGENTS.md) 與 [START_HERE.md](START_HERE.md)，照已確認的範圍協助 Wilson 或 Avril 安裝。

本儲存庫存放安裝工具，不能當作日常共享文件區。個人 Claude 帳號與公司 Microsoft 帳號各自登入，不共用密碼；本機 `--member` 參數不能取代公司身分驗證。

保留使用者已有的個人指示檔。安裝後另讀私有工作區的 `.department-agent/WORKSPACE.md`，讓草稿、修改提案與核准文件各放在指定位置。Neon 是共用記憶與正式待辦的來源，未接通時只準備「待送出草稿」。

本機安裝不會部署服務或登入雲端。收到管理者的正式網址後，再完成私有 `.mcp.json` 或 Claude 網頁 Connector 設定與本人授權，按 `docs/ACCEPTANCE.md` 留下實測結果。
