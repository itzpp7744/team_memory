# 交付前驗證

版本：0.1.1。日期：2026-10-27。

0.1.1 只更新交付網址、裝置分配與多裝置說明，程式碼與通過 54 項測試的 0.1.0 相同。

這是安裝套件的驗證紀錄，不是公司正式環境的上線證明。

| 項目 | 結果 |
| --- | --- |
| 本機環境 | macOS、Python 3.13.2 |
| 完整測試 | 54 項通過，沒有跳過 |
| 本機安裝器 | 24 項；包含重跑、保留原稿、路徑隔離、連結／junction、防止交錯安裝誤報，以及雙人校驗檔 |
| 設定與資料規則 | 12 項；缺設定拒絕、指定公司身分、版本衝突與輸入驗證 |
| 文件讀取 | 6 項；限制文件庫、文字擷取、不安全 XML 與大小限制 |
| MCP 服務 | 5 項；未登入 HTTP 拒絕、工具清單、登入 token 不露出為模型參數、文件重試及讀取稽核 |
| Postgres 整合 | 7 項；獨立本機 PostgreSQL 16.0、虛構資料、私有 Unix socket，沒有連到現有 Neon |
| 受限角色實測 | 可操作必要資料；不能改成員、刪稽核或建表；拒絕繼承其他角色 |
| 獨立審查 | 本機與服務各經規格審查、程式品質審查，已修正發現問題 |
| 套件內容 | Python 與 YAML 語法檢查、文件相對連結及個人路徑／金鑰樣式掃描 |
| 依賴 | 84 個直接與間接套件固定版本；測試環境依賴規格無缺漏或衝突 |

重跑本機安裝器測試，不需要安裝外部套件：

```sh
python3 -m unittest discover -s tests -p test_setup_workspace.py -v
```

完整測試需要安裝 `requirements.lock`，並把 `TEST_DATABASE_URL` 設為專用的可丟棄測試資料庫。測試會建立並刪除自己的 `department_agent` schema，不可把這個變數指向正式資料庫。測試角色需要建立測試角色與 schema 的權限。

```sh
python3 -m unittest discover -s tests -v
```

若沒有 `TEST_DATABASE_URL`，7 個資料庫整合測試會明確跳過；不能把這種結果寫成「全部通過且無跳過」。

## 尚未實際驗證

- GitHub Actions 的 Windows／Linux／macOS 矩陣，需發布 repo 後執行。
- Docker 映像建置、Caddy 憑證與主機部署；已提供建置檔與 CI 步驟。
- 公司真實 Entra OAuth、Graph 授權及 SharePoint 原檔讀取。
- 真實 Neon 的方案、連線、備份與還原。
- Wilson 與 Avril 的兩台電腦、個人 Claude／手機／Claude Code，以及真實雙向同步。

這些需依 ADMIN_SETUP 與 ACCEPTANCE 完成，不得用單元測試代替。程式測試中的 Microsoft ID、密碼及加密金鑰均為虛構測試值，不可複製到正式設定。
