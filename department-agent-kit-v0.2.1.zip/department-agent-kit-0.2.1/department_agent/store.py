"""Postgres storage: membership, optimistic updates, atomic retries and audit."""
import json
from uuid import UUID, uuid4
import psycopg
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb
from .logic import Conflict, apply_change, request_digest, text

class Store:
    def __init__(self,dsn,project_id):
        self.dsn=dsn
        self.project_id=project_id

    def connection(self):
        return psycopg.connect(self.dsn,connect_timeout=10,row_factory=dict_row,
                               options='-c statement_timeout=15000 -c lock_timeout=10000')

    def _member(self,conn,actor):
        row=conn.execute('SELECT oid FROM department_agent.members WHERE oid=%s AND active=true',(actor,)).fetchone()
        if row is None:
            raise PermissionError('此公司身分未獲授權或已停用')

    def authorize(self,actor):
        with self.connection() as conn:self._member(conn,actor)

    @staticmethod
    def _output(row):
        return {'id':str(row['id']),'kind':row['kind'],'version':row['version'],
                'body':row['body'],'updated_by':row['updated_by'],
                'updated_at':row['updated_at'].isoformat()}

    def _event(self,conn,actor,action,record_id=None,previous=None,current=None,reason=None):
        conn.execute('INSERT INTO department_agent.events(actor,project_id,action,record_id,previous,current,reason) VALUES (%s,%s,%s,%s,%s,%s,%s)',
                     (actor,self.project_id,action,record_id,Jsonb(previous),Jsonb(current),reason))

    def _request(self,conn,actor,key,digest):
        key=str(UUID(key))
        conn.execute('INSERT INTO department_agent.requests(actor,project_id,request_id,digest) VALUES (%s,%s,%s,%s) ON CONFLICT DO NOTHING',
                     (actor,self.project_id,key,digest))
        row=conn.execute('SELECT digest,result FROM department_agent.requests WHERE actor=%s AND project_id=%s AND request_id=%s FOR UPDATE',
                         (actor,self.project_id,key)).fetchone()
        if row['digest']!=digest:raise Conflict('同一請求編號已用於不同內容，請使用新編號')
        return key,row['result']

    def _finish(self,conn,actor,key,result):
        conn.execute('UPDATE department_agent.requests SET result=%s WHERE actor=%s AND project_id=%s AND request_id=%s',
                     (Jsonb(result),actor,self.project_id,key))
        return result

    def lookup_completed(self,actor,request_id,digest):
        with self.connection() as conn:
            self._member(conn,actor)
            row=conn.execute('SELECT digest,result FROM department_agent.requests WHERE actor=%s AND project_id=%s AND request_id=%s',
                             (actor,self.project_id,str(UUID(request_id)))).fetchone()
            if row is None:return None
            if row['digest']!=digest:raise Conflict('同一請求編號已用於不同內容，請使用新編號')
            return row['result']

    def create(self,actor,kind,body,request_id,digest=None):
        if kind not in {'note','task','document'}:raise ValueError('資料類型錯誤')
        with self.connection() as conn:
            self._member(conn,actor)
            key,cached=self._request(conn,actor,request_id,digest or request_digest('create_'+kind,body))
            if cached is not None:return cached
            if kind=='document':
                existing=conn.execute("SELECT id FROM department_agent.records WHERE project_id=%s AND kind='document' AND body->>'drive_id'=%s AND body->>'item_id'=%s",
                                      (self.project_id,body['drive_id'],body['item_id'])).fetchone()
                if existing:raise Conflict('此文件已登記，請提供文件編號與版本更新')
            row=conn.execute('INSERT INTO department_agent.records(id,project_id,kind,body,created_by,updated_by) VALUES (%s,%s,%s,%s,%s,%s) RETURNING *',
                             (uuid4(),self.project_id,kind,Jsonb(body),actor,actor)).fetchone()
            output=self._output(row)
            self._event(conn,actor,'create_'+kind,row['id'],current=output)
            return self._finish(conn,actor,key,output)

    def update(self,actor,record_id,kind,expected_version,changes,request_id,reason,digest=None):
        record_id=str(UUID(record_id))
        reason=text(reason,'更正／更新理由',2000)
        with self.connection() as conn:
            self._member(conn,actor)
            key,cached=self._request(conn,actor,request_id,digest or request_digest('update_'+kind,{'id':record_id,'expected_version':expected_version,'changes':changes,'reason':reason}))
            if cached is not None:return cached
            old=conn.execute('SELECT * FROM department_agent.records WHERE id=%s AND project_id=%s AND kind=%s FOR UPDATE',
                             (record_id,self.project_id,kind)).fetchone()
            if old is None:raise ValueError('找不到這個專案中的紀錄')
            body=apply_change(old['body'],old['version'],expected_version,changes,kind)
            new=conn.execute('UPDATE department_agent.records SET body=%s,version=version+1,updated_by=%s,updated_at=now() WHERE id=%s RETURNING *',
                             (Jsonb(body),actor,record_id)).fetchone()
            output=self._output(new)
            self._event(conn,actor,'update_'+kind,record_id,self._output(old),output,reason)
            return self._finish(conn,actor,key,output)

    def get(self,actor,record_id,kind):
        with self.connection() as conn:
            self._member(conn,actor)
            row=conn.execute('SELECT * FROM department_agent.records WHERE id=%s AND project_id=%s AND kind=%s',(str(UUID(record_id)),self.project_id,kind)).fetchone()
            if row is None:raise ValueError('找不到這個專案中的紀錄')
            self._event(conn,actor,'read_'+kind,row['id'])
            return self._output(row)

    def read_context(self,actor,limit=50):
        limit=max(1,min(int(limit),100))
        with self.connection() as conn:
            self._member(conn,actor)
            result={'project_id':self.project_id,'limit_per_kind':limit,'notes':[],'tasks':[],'source':'department_agent'}
            for kind,field in [('note','notes'),('task','tasks')]:
                rows=conn.execute('SELECT * FROM department_agent.records WHERE project_id=%s AND kind=%s ORDER BY updated_at DESC,id LIMIT %s',
                                  (self.project_id,kind,limit)).fetchall()
                result[field]=[self._output(row) for row in rows]
            self._event(conn,actor,'read_context')
            return result

    def audit_document_read(self,actor,drive_id,item_id,revision):
        with self.connection() as conn:
            self._member(conn,actor)
            self._event(conn,actor,'read_document',reason=json.dumps({'drive_id':drive_id,'item_id':item_id,'source_revision':revision}))

    def find_documents(self,actor,query='',limit=30):
        limit=max(1,min(int(limit),100))
        if len(query)>200:raise ValueError('搜尋條件太長')
        with self.connection() as conn:
            self._member(conn,actor)
            # Search a literal substring, not user-provided SQL/wildcards.
            rows=conn.execute("SELECT * FROM department_agent.records WHERE project_id=%s AND kind='document' AND position(lower(%s) in lower(body->>'title'))>0 ORDER BY updated_at DESC,id LIMIT %s",
                              (self.project_id,query,limit)).fetchall()
            self._event(conn,actor,'find_documents')
            return [self._output(row) for row in rows]
