"""Bounded Graph reads and text extraction; no arbitrary URLs or disk extraction."""
import io
import re
import zipfile
from pathlib import PurePosixPath
from urllib.parse import urlsplit, quote
import httpx
from defusedxml.ElementTree import fromstring

MAX_FILE_BYTES = 10 * 1024 * 1024
MAX_UNPACKED_BYTES = 40 * 1024 * 1024
MAX_TEXT_CHARS = 100000
GRAPH_BASE = 'https://graph.microsoft.com/v1.0'
GRAPH_SCOPE = 'https://graph.microsoft.com/Files.Read.All'

def extract_text(name, data):
    if len(data) > MAX_FILE_BYTES:
        raise ValueError('文件超過 10 MiB，請使用原生應用程式閱讀')
    suffix = PurePosixPath(name).suffix.lower()
    limitations = '僅擷取文字；未閱讀圖片、圖表意義、版面與嵌入物件。'
    if suffix in {'.txt','.md','.csv'}:
        result = data.decode('utf-8-sig')
    elif suffix in {'.docx','.pptx'}:
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as archive:
                infos=archive.infolist()
                if len(infos)>2000 or sum(i.file_size for i in infos)>MAX_UNPACKED_BYTES:
                    raise ValueError('文件解壓後超過限制')
                if suffix=='.docx':
                    names=['word/document.xml']
                else:
                    names=sorted([i.filename for i in infos if re.fullmatch(r'ppt/slides/slide[0-9]+\.xml',i.filename)],key=lambda x:int(re.search(r'slide([0-9]+)',x)[1]))
                if not names:raise ValueError('文件沒有可讀取內容')
                chunks=[]
                for name in names:
                    root=fromstring(archive.read(name))
                    words=[node.text for node in root.iter() if node.tag.split('}')[-1]=='t' and node.text]
                    location='本文' if suffix=='.docx' else '投影片 '+re.search(r'slide([0-9]+)',name)[1]
                    chunks.append(location+'\n'+'\n'.join(words))
                result='\n\n'.join(chunks)
        except Exception:
            raise ValueError('Office 文件格式不支援、已加密、損壞或含不安全結構') from None
    else:
        raise ValueError('第一版只讀 UTF-8 文字、Markdown、CSV、DOCX、PPTX；PDF、XLSX 與圖片請用原生工具')
    return {'text':result[:MAX_TEXT_CHARS], 'truncated':len(result)>MAX_TEXT_CHARS,'limitations':limitations}

class GraphDocuments:
    def __init__(self,drive_id,root_id):
        self.drive_id=drive_id
        self.root_id=root_id
        self.item_url(root_id)

    def item_url(self,item_id):
        for value in (self.drive_id,item_id):
            if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z0-9!_-]{1,256}',value):
                raise ValueError('檔案識別格式錯誤')
        return f'{GRAPH_BASE}/drives/{quote(self.drive_id,safe="")}/items/{quote(item_id,safe="")}'

    async def item(self,item_id,token):
        async with httpx.AsyncClient(timeout=30,follow_redirects=False) as client:
            response=await client.get(self.item_url(item_id),headers={'Authorization':'Bearer '+token})
            if response.status_code!=200:
                raise PermissionError('雲端文件不存在或目前無讀取權限；請重新登入或請管理者檢查')
            return response.json()

    async def authorized_item(self,item_id,token):
        original=await self.item(item_id,token)
        current=original
        seen=set()
        for _ in range(50):
            if current.get('remoteItem'):
                raise PermissionError('不接受指向其他文件庫的捷徑')
            parent=current.get('parentReference',{})
            if parent.get('driveId')!=self.drive_id:
                raise PermissionError('文件不在指定文件庫')
            if current.get('id')==self.root_id:
                return original
            parent_id=parent.get('id')
            if parent_id==self.root_id:
                return original
            if not parent_id or parent_id in seen:
                break
            seen.add(parent_id)
            current=await self.item(parent_id,token)
        raise PermissionError('文件不在已授權共享資料夾內')

    async def read(self,item_id,token):
        meta=await self.authorized_item(item_id,token)
        if 'file' not in meta:
            raise ValueError('選取的是資料夾，請指定文件')
        if meta.get('size',MAX_FILE_BYTES+1)>MAX_FILE_BYTES:
            raise ValueError('文件超過讀取上限')
        async with httpx.AsyncClient(timeout=30,follow_redirects=False) as client:
            url=self.item_url(item_id)+'/content'
            headers={'Authorization':'Bearer '+token}
            data=bytearray()
            for attempt in range(4):
                async with client.stream('GET',url,headers=headers) as response:
                    if response.status_code in {301,302,303,307,308}:
                        target=response.headers.get('location','')
                        parsed=urlsplit(target)
                        if parsed.scheme!='https' or parsed.username or parsed.password or not parsed.hostname or not parsed.hostname.endswith('.sharepoint.com') or parsed.port not in (None,443):
                            raise PermissionError('拒絕非 SharePoint 的下載重新導向')
                        url=target
                        headers={}  # Never forward the Graph bearer token to a download host.
                        continue
                    if response.status_code!=200:
                        raise ValueError('雲端下載失敗，沒有讀到完整文件')
                    async for chunk in response.aiter_bytes():
                        data.extend(chunk)
                        if len(data)>MAX_FILE_BYTES:raise ValueError('文件超過讀取上限')
                    break
            else:
                raise ValueError('下載重新導向次數過多')
        after=await self.authorized_item(item_id,token)
        if not meta.get('eTag') or meta['eTag']!=after.get('eTag'):
            raise ValueError('讀取期間文件已修改，請重試取得一致版本')
        return {**extract_text(meta['name'],bytes(data)),'title':meta['name'],
                'source_revision':meta['eTag'],'web_url':meta.get('webUrl',''),
                'drive_id':self.drive_id,'item_id':item_id}
