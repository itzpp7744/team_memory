"""Business validation, independent of transport and database."""
import hashlib
import json
from datetime import date

class Conflict(ValueError):
    pass

def identity(claims, tenant):
    if claims.get('tid') != tenant or not isinstance(claims.get('oid'), str) or not claims['oid']:
        raise PermissionError('缺少經驗證的公司成員身分')
    return claims['oid']

def text(value, field, limit=20000):
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        raise ValueError(f'{field} 必須有內容，且不超過 {limit} 字元')
    return value.strip()

def validate_note(title, content, category, status, source):
    if category not in {'fact', 'hypothesis', 'decision', 'handoff'}:
        raise ValueError('紀錄種類錯誤')
    # Explicit confirmed decisions are recorded as such, not inferred by the model.
    if status not in {'pending', 'confirmed', 'void'} or (category == 'hypothesis' and status == 'confirmed'):
        raise ValueError('紀錄狀態錯誤；假設不能直接標為確認')
    return dict(title=text(title,'標題',200), content=text(content,'內容'),
                category=category,status=status,source=text(source,'來源',2000))

def validate_task(title, assignee, due_date, completion):
    if assignee is not None:
        assignee = text(assignee,'負責人',200)
    if due_date is not None:
        if not isinstance(due_date,str) or len(due_date) != 10:
            raise ValueError('日期使用 YYYY-MM-DD')
        date.fromisoformat(due_date)
    return dict(title=text(title,'標題',200),assignee=assignee,due_date=due_date,
                completion=text(completion,'完成條件',2000),status='open')

def apply_change(body, current_version, expected_version, changes, kind):
    if type(expected_version) is not int or expected_version < 1:
        raise ValueError('必須提供讀取時的版本')
    if current_version != expected_version:
        raise Conflict(f'資料已被更新；目前版本 {current_version}，請重新讀取後比較')
    allowed = {'task': {'title','assignee','due_date','completion','status'},
               'note': {'title','content','category','status','source'},
               'document': {'title','drive_id','item_id','web_url','source_revision','summary','summary_revision','status'}}
    if not changes or set(changes) - allowed.get(kind,set()):
        raise ValueError('不允許的更新欄位')
    result = {**body, **changes}
    if kind == 'task':
        validated = validate_task(result['title'],result.get('assignee'),result.get('due_date'),result['completion'])
        if result['status'] not in {'open','doing','done','cancelled'}:
            raise ValueError('待辦狀態錯誤')
        result = {**validated,'status':result['status']}
    elif kind == 'note':
        result = validate_note(**result)
    return result

def request_digest(operation, payload):
    serialized = json.dumps([operation,payload],sort_keys=True,ensure_ascii=False,separators=(',',':'))
    return hashlib.sha256(serialized.encode()).hexdigest()
