"""Strict environment configuration; never load secrets from repository files."""
from dataclasses import dataclass, field
from pathlib import Path
import base64
import os
import re
from urllib.parse import urlsplit, parse_qs
from uuid import UUID

@dataclass(frozen=True)
class Settings:
    database_url: str = field(repr=False)
    tenant_id: str
    client_id: str
    client_secret: str = field(repr=False)
    base_url: str
    project_id: str
    jwt_signing_key: str = field(repr=False)
    storage_encryption_key: str = field(repr=False)
    auth_storage_path: str
    drive_id: str = ''
    shared_root_id: str = ''

    @property
    def documents_enabled(self):
        return bool(self.drive_id and self.shared_root_id)

    @classmethod
    def from_env(cls, env=None):
        env = os.environ if env is None else env
        required = ['DATABASE_URL', 'TENANT_ID', 'CLIENT_ID', 'CLIENT_SECRET',
                    'BASE_URL', 'PROJECT_ID', 'JWT_SIGNING_KEY',
                    'STORAGE_ENCRYPTION_KEY', 'AUTH_STORAGE_PATH']
        missing = ['DEPT_' + name for name in required if not env.get('DEPT_' + name)]
        if missing:
            raise ValueError('缺少環境變數：' + ', '.join(missing))
        values = {key.lower(): env['DEPT_' + key] for key in required}
        for key in ['tenant_id', 'client_id']:
            try:
                values[key] = str(UUID(values[key]))
            except (ValueError, TypeError):
                raise ValueError(key + ' 必須是指定公司的 UUID') from None
        url = urlsplit(values['base_url'])
        if (url.scheme != 'https' or not url.hostname or url.username or url.password
                or url.query or url.fragment or url.path not in ('', '/')):
            raise ValueError('DEPT_BASE_URL 必須是無帳密、參數及子路徑的 HTTPS 網址')
        values['base_url'] = values['base_url'].rstrip('/')
        db = urlsplit(values['database_url'])
        if db.scheme not in ('postgres', 'postgresql') or not db.hostname or parse_qs(db.query).get('sslmode') not in (['require'], ['verify-full']):
            raise ValueError('DEPT_DATABASE_URL 必須是使用 sslmode=require 或 verify-full 的 Postgres 連線')
        if not re.fullmatch(r'[a-z0-9][a-z0-9-]{0,63}', values['project_id']):
            raise ValueError('DEPT_PROJECT_ID 只能用小寫英文、數字及連字號')
        if len(values['jwt_signing_key']) < 32:
            raise ValueError('DEPT_JWT_SIGNING_KEY 至少 32 個字元')
        try:
            if len(base64.urlsafe_b64decode(values['storage_encryption_key'])) != 32:
                raise ValueError()
        except Exception:
            raise ValueError('DEPT_STORAGE_ENCRYPTION_KEY 必須是 Fernet 金鑰') from None
        storage = Path(values['auth_storage_path'])
        if storage.resolve() in (Path(storage.anchor), Path.home().resolve()):
            raise ValueError('登入狀態必須使用專用子目錄，不能是根目錄或家目錄')
        if not storage.is_absolute():
            raise ValueError('DEPT_AUTH_STORAGE_PATH 必須是主機上非共享區的絕對路徑')
        values['drive_id'] = env.get('DEPT_DRIVE_ID', '')
        values['shared_root_id'] = env.get('DEPT_SHARED_ROOT_ID', '')
        if bool(values['drive_id']) != bool(values['shared_root_id']):
            raise ValueError('文件庫與共享根目錄 ID 必須一起設定')
        return cls(**values)
