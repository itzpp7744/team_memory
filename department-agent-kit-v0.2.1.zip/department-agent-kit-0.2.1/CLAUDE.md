# PP 團隊安裝包

請讀本目錄 AGENTS.md 與 START_HERE.md，按同一入口安裝。這個目錄是程式與規則來源；日常工作要切到安裝後的私有工作區，並讀 .department-agent/WORKSPACE.md。
