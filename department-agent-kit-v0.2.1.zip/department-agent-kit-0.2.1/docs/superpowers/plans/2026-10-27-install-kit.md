# Department Agent Kit Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** 交付可以交給 Wilson、Avril 的 AI 執行的安裝套件，包含本機設定、同步驗收、部門服務程式、資料表與管理者部署說明。

**Architecture:** SharePoint／OneDrive 負責共享文件，Neon 負責結構化記憶與文件目錄。本機安裝器使用 Python 標準函式庫，不需要資料庫密碼。遠端 MCP 使用 FastMCP 的 Entra OAuth 元件；雲端服務只能在管理者提供實際身分、專案與授權後啟用。

**Tech Stack:** Python 3.11+、FastMCP AzureProvider、Postgres／Neon、Microsoft Graph、GitHub。

## Task 1 — 本機安裝與同步驗收

Files: `scripts/setup_workspace.py`, `tests/test_setup_workspace.py`.

- [x] 先寫測試：私有與共享根目錄重疊時拒絕；指向外部的連結拒絕；重跑不覆蓋使用者文件；無服務網址時不得回報雲端可用；兩個使用者可交換校驗檔。
- [x] 執行 `python3 -m unittest discover -s tests -p 'test_setup_workspace.py' -v`，記錄預期失敗。
- [x] 實作 `plan`、`install`、`doctor`、`probe-create`、`probe-verify`。所有參數經驗證後才寫檔。寫入只限已指定路徑，不讀憑證、不改系統設定、不自動搬檔。
- [x] 同一測試命令通過；以含空格與中文的暫存目錄執行完整流程。

## Task 2 — 資料與身分邊界

Files: `department_agent/settings.py`, `department_agent/store.py`, `sql/001_init.sql`, `tests/test_store.py`, `tests/test_settings.py`.

- [x] 先寫測試驗證身分缺失拒絕、版本衝突拒絕、同次請求重送不重複、操作事件保留。
- [x] SQL 使用固定 schema `department_agent`；應用程式角色不得擁有 DDL 權限。
- [x] CRUD 以參數化查詢實作，成員身分由已驗證 token 取得，所有讀寫限定單一設定專案。
- [x] 測試使用本機合成資料；真實 Neon 連線與 schema 寫入均不在本次授權範圍。

## Task 3 — 遠端工具與文件讀取

Files: `department_agent/server.py`, `department_agent/documents.py`, `tests/test_documents.py`, `tests/test_server.py`.

- [x] 先測文件路徑逃逸拒絕、過大或壓縮炸彈拒絕、錯誤文件庫拒絕；來源版本改變時摘要標為過期。
- [x] 提供 5 個記憶／待辦工具與 3 個文件工具；使用 FastMCP AzureProvider，不自製 OAuth。
- [x] Microsoft Graph 請求僅允許固定 Graph 網域及設定文件庫／共享根目錄；按使用者權限讀取，來源內容不當系統指令。
- [x] HTTP 未驗證請求必須拒絕；缺環境參數不得啟動；服務狀態不得把健康檢查誤當兩人整體驗收。

## Task 4 — 交接與發布

Files: `README.md`, `START_HERE.md`, `AGENTS.md`, `CLAUDE.md`, `docs/ADMIN_SETUP.md`, `docs/ACCEPTANCE.md`, `config/team.example.json`, `requirements.lock`, `Dockerfile`, `.gitignore`, `.github/workflows/tests.yml`.

- [x] 安裝指引區分管理者一次性設定與兩人的安裝；缺少的 ID 使用空值，由檢查器列出，不使用假裝可用的服務網址。
- [x] 檢查所有輸出無秘密、個人路徑、真實資料庫識別與聊天內容。
- [x] 執行完整測試、依賴檢查與安裝流程，將實測／未實測項目分別記錄。
- [x] 由獨立 reviewer 先核對規格，再審查程式品質；修正後重驗。
- [ ] GitHub 發布：本機 ZIP 會完成；目的地尚待提供，未對外發布。

## 不會由安裝檔假造的前置條件

部門 GitHub repo、Entra 應用程式授權、兩個成員的物件 ID、SharePoint 文件庫與共享根目錄、Neon 應用程式連線、HTTPS 服務網址與主機。這些需要真實值與管理者操作，套件內提供完整設定位置與檢查方法。
