# PP 管理者設定入口

本版先完成 Google Drive 文件工作區與統一規則。雲端記憶服務另外部署，不是執行本機安裝就自動完成。

## 這次實際需要準備

1. 確認 PP 團隊 Gmail `itzpp7744@gmail.com` 的用途、Google Drive 可用空間與公司資料放置政策。不要從 Gmail 網域推定有付費 Workspace 或共用雲端硬碟。
2. 確認 Wilson、Avril 各自獲准的 Google 帳號；由管理者建立／指定共享專案並分享給兩人，不開放公開連結。
3. 給兩人相同專案代號、同一共享資料夾網址和同一安裝包版本。從 [START_HERE](../START_HERE.md) 開始；路徑不同不影響共用格式。
4. 依 [Google Drive 指南](../team-assets/reference/GOOGLE_DRIVE_SETUP.md) 完成各台同步設定，依 [驗收清單](ACCEPTANCE.md) 留下證據。

共享區內 `00_專案說明/PP_TEAM_STANDARD.json` 記錄專案、套件與格式指紋，兩人安裝時必須相符。若不符，不可刪掉它讓安裝通過；確認是否選錯資料夾、使用不同版本，或有其他人的修改。版本升級需有專案管理者統一安排。

## 共用記憶服務

程式提供 Neon/Postgres 儲存與遠端 MCP（AI 呼叫工具的介面）服務，但尚未部署。這版不建立資料庫、不搬動既有資料，也不使用個人的 Neon。

現有服務使用 Microsoft Entra 公司身分驗證。若沿用公司既有 Microsoft 身分，管理者可按 [Microsoft 記憶服務部署說明](MICROSOFT_SERVICE_SETUP.md) 設定；**Google Drive 路線不要設定 `DEPT_DRIVE_ID`／`DEPT_SHARED_ROOT_ID`，也不要為它申請 Graph 文件權限**。那兩個變數只屬於舊版 SharePoint 文件讀取，不支援 Google Drive。

若要完全改用 Google 登入，需要另做服務身分驗證整合；本次沒有用共享 Gmail 密碼替代。使用者端在正式網址、登入及專案驗收完成前，不設定假的 MCP URL，記憶只存私有待送出草稿。

服務部署後，管理者記錄固定 project_id 並告知兩人。先用測試紀錄驗證 Wilson 新增→Avril 讀取、衝突處理、撤權、重試不重複；測試通過才讓兩人的 AI 保存正式共用記憶。文件原稿留 Google Drive，待辦與決策以 Neon 為準。

## 升級與撤權

本版不覆寫既有 0.1.x 工作區，也不自動改共用版本標記。第一次使用 0.2.1，選新私有工作區；若共享區已有舊版無標記的分類，可在檢查內容後沿用，安裝器不搬原稿。若共享區已有不同版本標記，改用管理者安排的新專案共享位置，或另做審閱過的版本遷移，不自行編輯版本欄位。

移除成員時分別處理 Google Drive 分享、GitHub 權限及記憶服務成員資格。已下載的文件及已進入私人 AI 聊天的內容，不能靠雲端撤權收回。

## Elio 現在要完成的事

「PP 團隊專案」已建立，但交付時尚未分享。請把 [指定資料夾](https://drive.google.com/drive/folders/1_OrdKAQBzqSQt9EIaKza9SwzA4GvZ2-J) 分享給兩人各自核准的 Google 帳號，給工作所需的編輯權限；讓兩人各自的 GitHub 帳號可讀私人 repo，再確認共同專案代號（範例 pp-product）。不要交付共用密碼。

兩人電腦上的 AI 會依 [ONBOARDING](../team-assets/reference/ONBOARDING.md) 檢查 Obsidian、既有 Vault 與實際分享權限。你再和兩人安排一次雙向檔案驗收。

若要 Claude 手機／桌面與 Claude Code 共用正式記憶，還須部署並授權部門 MCP 記憶服務；Drive 資料夾建立完成不會自動完成這一步。GitHub 用於工具版本與需求審查，成員作品要依 [TEAM_EVOLUTION](../team-assets/reference/TEAM_EVOLUTION.md) 核准發布。
