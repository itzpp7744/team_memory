import tempfile
import unittest
from pathlib import Path
import httpx
from test_settings import BASE
from department_agent.settings import Settings
from department_agent.server import build_server

class ServerTests(unittest.IsolatedAsyncioTestCase):
    async def test_unauthenticated_http_cannot_call_tools(self):
        with tempfile.TemporaryDirectory() as tmp:
            settings=Settings.from_env({**BASE,'DEPT_AUTH_STORAGE_PATH':str(Path(tmp)/'auth')})
            server=build_server(settings)
            app=server.http_app()
            async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url=settings.base_url) as client:
                response=await client.post('/mcp',json={'jsonrpc':'2.0','id':1,'method':'tools/list'})
                self.assertEqual(response.status_code,401)
                health=await client.get('/healthz')
                self.assertEqual(health.status_code,200)
                self.assertEqual(health.json()['external_acceptance'],'NOT_VERIFIED')
    async def test_no_unauthenticated_fallback(self):
        with self.assertRaises(ValueError):build_server(Settings.from_env({}))

    async def test_document_tools_hide_oauth_token_parameter(self):
        with tempfile.TemporaryDirectory() as tmp:
            settings=Settings.from_env({**BASE,'DEPT_AUTH_STORAGE_PATH':str(Path(tmp)/'auth'),
                                       'DEPT_DRIVE_ID':'drive','DEPT_SHARED_ROOT_ID':'root'})
            server=build_server(settings)
            tools=await server.list_tools()
            self.assertEqual({t.name for t in tools},{'read_context','save_note','create_task','update_task','correct_note','find_documents','read_document','register_document'})
            for tool in tools:
                self.assertNotIn('graph_token',tool.parameters.get('properties',{}))

    async def test_registered_document_retry_survives_new_source_revision(self):
        from types import SimpleNamespace
        from unittest.mock import patch, Mock, AsyncMock
        saved={'id':'saved-id','version':1,'body':{'summary':'old confirmed save'}}
        store=Mock()
        store.lookup_completed.return_value=saved
        graph=Mock()
        graph.authorized_item=AsyncMock(return_value={'eTag':'new-version'})
        graph.read=AsyncMock(side_effect=AssertionError('replay must not reread changed content'))
        with tempfile.TemporaryDirectory() as tmp:
            settings=Settings.from_env({**BASE,'DEPT_AUTH_STORAGE_PATH':str(Path(tmp)/'auth'),
                                       'DEPT_DRIVE_ID':'drive','DEPT_SHARED_ROOT_ID':'root'})
            with patch('department_agent.server.Store',return_value=store), patch('department_agent.server.GraphDocuments',return_value=graph), patch('department_agent.server.get_access_token',return_value=SimpleNamespace(claims={'tid':BASE['DEPT_TENANT_ID'],'oid':'wilson'})):
                server=build_server(settings)
                tool=await server.get_tool('register_document')
                result=await tool.fn(item_id='item',source_revision='old-version',summary='summary',request_id='request',graph_token='fixture')
                self.assertTrue(result['replayed'])
                self.assertTrue(result['source_has_changed'])
                self.assertEqual(result['id'],'saved-id')
                graph.read.assert_not_called()
                graph.authorized_item.side_effect=PermissionError('revoked')
                store.lookup_completed.reset_mock()
                from fastmcp.exceptions import ToolError
                with self.assertRaises(ToolError):
                    await tool.fn(item_id='item',source_revision='old-version',summary='summary',request_id='request',graph_token='fixture')
                store.lookup_completed.assert_not_called()

    async def test_document_read_audits_source_without_token_or_content(self):
        from types import SimpleNamespace
        from unittest.mock import patch, Mock, AsyncMock
        store=Mock()
        graph=Mock()
        graph.read=AsyncMock(return_value={'source_revision':'v1','text':'private document'})
        with tempfile.TemporaryDirectory() as tmp:
            settings=Settings.from_env({**BASE,'DEPT_AUTH_STORAGE_PATH':str(Path(tmp)/'auth'),
                                       'DEPT_DRIVE_ID':'drive','DEPT_SHARED_ROOT_ID':'root'})
            with patch('department_agent.server.Store',return_value=store), patch('department_agent.server.GraphDocuments',return_value=graph), patch('department_agent.server.get_access_token',return_value=SimpleNamespace(claims={'tid':BASE['DEPT_TENANT_ID'],'oid':'wilson'})):
                server=build_server(settings)
                tool=await server.get_tool('read_document')
                await tool.fn(item_id='item',graph_token='secret-fixture')
                store.audit_document_read.assert_called_once_with('wilson','drive','item','v1')
