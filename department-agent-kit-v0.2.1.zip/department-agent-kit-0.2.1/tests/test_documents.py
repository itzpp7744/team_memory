import asyncio
import io
import unittest
import zipfile
from department_agent.documents import extract_text, GraphDocuments, MAX_FILE_BYTES

def office(name, xml):
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w') as z:z.writestr(name,xml)
    return out.getvalue()

class DocumentTests(unittest.TestCase):
    def test_office_text_has_source_locations(self):
        data=office('ppt/slides/slide1.xml','<p xmlns:a="a"><a:t>Hello team</a:t></p>')
        result=extract_text('proposal.pptx',data)
        self.assertIn('投影片 1',result['text'])
        self.assertIn('Hello team',result['text'])
        self.assertIn('圖片',result['limitations'])
    def test_unsupported_or_oversized_files_fail(self):
        for name,data in [('scan.pdf',b'pdf'),('data.txt',b'x'*(MAX_FILE_BYTES+1))]:
            with self.subTest(name=name), self.assertRaises(ValueError):extract_text(name,data)
    def test_entities_rejected(self):
        data=office('word/document.xml','<!DOCTYPE x [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><r>&xxe;</r>')
        with self.assertRaises(ValueError):extract_text('a.docx',data)
    def test_wrong_drive_or_outside_shared_root_rejected(self):
        graph=GraphDocuments('drive','root')
        async def fetch(item_id,token):
            return {'id':item_id,'parentReference':{'driveId':'other','id':'root'}}
        graph.item=fetch
        with self.assertRaises(PermissionError):asyncio.run(graph.authorized_item('file','fake'))
    def test_root_and_descendant_allowed(self):
        graph=GraphDocuments('drive','root')
        items={'file':{'id':'file','file':{},'name':'a.md','parentReference':{'driveId':'drive','id':'folder'}},
               'folder':{'id':'folder','parentReference':{'driveId':'drive','id':'root'}}}
        async def fetch(item_id,token):return items[item_id]
        graph.item=fetch
        result=asyncio.run(graph.authorized_item('file','fake'))
        self.assertEqual(result['id'],'file')
    def test_graph_query_injection_rejected(self):
        graph=GraphDocuments('drive','root')
        with self.assertRaises(ValueError):graph.item_url('../other?x')
