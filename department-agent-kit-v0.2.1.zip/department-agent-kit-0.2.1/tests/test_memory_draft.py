"""Offline memory drafts: validate strict shape, paths, and exclusive writes."""
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import uuid

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / 'scripts/memory_draft.py'
NOTE = dict(title=' 決策 ', content=' 使用共用格式 ', category='decision', status='confirmed', source=' 使用者確認 ')
TASK = dict(title=' 完成文件 ', completion=' Wilson 審閱 ', assignee='Avril', due_date='2026-10-30')


class MemoryDraftTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='pp memory 中文 ')
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name).resolve()
        self.private = self.base / 'private'
        self.drafts = self.private / 'drafts/memory'
        self.drafts.mkdir(parents=True)
        managed = self.private / '.department-agent'
        managed.mkdir()
        self.config = dict(version=2, member='Wilson', project_id='pp-team', private_root=str(self.private), shared_root=str(self.base / 'shared'), mcp_url=None)
        (managed / 'config.json').write_text(json.dumps(self.config))

    def cli(self, command, *args, ok=True, script=SCRIPT):
        result = subprocess.run([sys.executable, str(script), command, '--private-root', str(self.private), *map(str, args)], capture_output=True, text=True, encoding='utf-8')
        self.assertEqual(result.returncode, 0 if ok else 2, result.stdout + result.stderr)
        self.assertTrue(result.stdout.startswith('{'), result.stderr)
        return json.loads(result.stdout)

    def new(self, payload=NOTE, kind='note', ok=True, script=SCRIPT):
        source = self.base / 'input.json'
        source.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
        return self.cli('new', '--kind', kind, '--input', source, ok=ok, script=script)

    def test_valid_note_and_task_are_private_drafts_with_minimal_output(self):
        for kind, payload in [('note', NOTE), ('task', TASK)]:
            result = self.new(payload, kind)
            self.assertEqual(set(result), {'draft_path', 'request_id', 'cloud_status'})
            self.assertEqual(result['cloud_status'], 'NOT_SENT')
            path = Path(result['draft_path'])
            self.assertEqual(path.parent, self.drafts)
            self.assertEqual(path.name, result['request_id'] + '.json')
            data = json.loads(path.read_bytes())
            self.assertEqual(set(data), {'schema_version', 'project_id', 'kind', 'request_id', 'submitted_by', 'delivery', 'payload'})
            self.assertEqual(data['schema_version'], 'pp-memory/2')
            self.assertEqual(data['submitted_by'], 'Wilson')
            self.assertEqual(data['delivery'], 'draft')
            self.assertEqual(data['payload']['title'], payload['title'].strip())
            if kind == 'task':
                self.assertNotIn('status', data['payload'])
            self.assertEqual(self.cli('check', '--file', path), result)

    def test_rejects_unknown_missing_fields_invalid_values_and_oversized_content(self):
        invalid = [(dict(NOTE, token='secret'), 'note'),
                   ({key: val for key, val in NOTE.items() if key != 'source'}, 'note'),
                   (dict(NOTE, status='void'), 'note'),
                   (dict(NOTE, category='hypothesis'), 'note'),
                   (dict(NOTE, content='x' * 20001), 'note'),
                   (dict(NOTE, title=['unsafe']), 'note'),
                   (dict(TASK, status='open'), 'task'),
                   (dict(TASK, assignee='   '), 'task'),
                   (dict(TASK, assignee='x' * 201), 'task'),
                   (dict(TASK, assignee=42), 'task'),
                   (dict(TASK, due_date='2026-02-30'), 'task'),
                   (dict(TASK, due_date='2026-W44-1'), 'task'),
                   ({'__class__': 'evil'}, 'task')]
        for payload, kind in invalid:
            with self.subTest(kind=kind, fields=list(payload)):
                result = self.new(payload, kind, ok=False)
                self.assertEqual(result['cloud_status'], 'NOT_SENT')
                self.assertEqual(list(self.drafts.iterdir()), [])

    def test_nullable_task_fields_and_normalization(self):
        result = self.new(dict(TASK, assignee=None, due_date=None), 'task')
        self.cli('check', '--file', result['draft_path'])

    def test_schema_text_patterns_and_runtime_agree_on_canonical_whitespace(self):
        schema = json.loads((ROOT / 'team-assets/memory-draft.schema.json').read_bytes())
        conditional = schema['allOf'][0]
        for kind, payload, branch, fields in [
            ('note', NOTE, 'then', ('title', 'content', 'source')),
            ('task', TASK, 'else', ('title', 'completion')),
        ]:
            definitions = conditional[branch]['properties']['payload']['properties']
            input_payload = dict(payload)
            for field in fields:
                input_payload[field] = '\t ' + payload[field].strip() + '\n第二行\r\n'
            result = self.new(input_payload, kind)
            path = Path(result['draft_path'])
            original = json.loads(path.read_bytes())
            self.cli('check', '--file', path)
            for field in fields:
                canonical = original['payload'][field]
                pattern = definitions[field]['pattern']
                with self.subTest(kind=kind, field=field, canonical=True):
                    self.assertEqual(canonical, input_payload[field].strip())
                    self.assertIsNotNone(re.search(pattern, canonical))
                for changed in (' ' + canonical, canonical + ' ', canonical + '\n', canonical + '\r\n'):
                    with self.subTest(kind=kind, field=field, changed=repr(changed)):
                        modified = {**original, 'payload': {**original['payload'], field: changed}}
                        path.write_text(json.dumps(modified, ensure_ascii=False), encoding='utf-8')
                        self.cli('check', '--file', path, ok=False)
                        self.assertIsNone(re.search(pattern, changed))

    def test_modified_envelope_and_filename_are_rejected(self):
        result = self.new()
        path = Path(result['draft_path'])
        original = json.loads(path.read_bytes())
        for field, value in [('submitted_by', 'Avril'), ('project_id', 'other'), ('delivery', 'sent'),
                             ('schema_version', 'pp-memory/1'), ('request_id', str(uuid.uuid4())), ('extra', True)]:
            path.write_text(json.dumps({**original, field: value}))
            self.cli('check', '--file', path, ok=False)

    def test_check_cannot_read_outside_draft_directory(self):
        result = self.new()
        outside = self.base / Path(result['draft_path']).name
        shutil.copyfile(result['draft_path'], outside)
        self.cli('check', '--file', outside, ok=False)
        self.cli('check', '--file', self.drafts / '..' / outside.name, ok=False)

    def test_links_rejected_for_input_output_and_checked_file(self):
        result = self.new()
        original = Path(result['draft_path'])
        destination = self.base / 'outside'
        destination.mkdir()
        try:
            linked = destination / original.name
            linked.symlink_to(original)
        except (OSError, NotImplementedError):
            self.skipTest('Symlinks unavailable')
        self.cli('check', '--file', linked, ok=False)
        self.cli('new', '--kind', 'note', '--input', linked, ok=False)
        original.unlink()
        self.drafts.rmdir()
        self.drafts.symlink_to(destination, target_is_directory=True)
        self.new(ok=False)
        self.assertEqual(list(destination.iterdir()), [linked])

    def test_duplicate_json_keys_and_oversized_input_are_rejected_without_echo(self):
        source = self.base / 'input.json'
        for content in ['{"title":"secret","title":"duplicate"}', 'secret' * 200000]:
            source.write_text(content)
            result = self.cli('new', '--kind', 'note', '--input', source, ok=False)
            self.assertNotIn('secret', json.dumps(result))

    def test_installed_tool_runs_without_repository(self):
        self.assertTrue(SCRIPT.is_file(), 'standalone memory tool must be provided')
        tools = self.private / '.department-agent/tools'
        tools.mkdir()
        shutil.copyfile(SCRIPT, tools / 'memory_draft.py')
        shutil.copyfile(ROOT / 'department_agent/logic.py', tools / 'logic.py')
        result = self.new(script=tools / 'memory_draft.py')
        self.cli('check', '--file', result['draft_path'], script=tools / 'memory_draft.py')

    def test_installed_check_creates_no_bytecode_or_other_files(self):
        result = self.new()
        tools = self.private / '.department-agent/tools'
        tools.mkdir()
        shutil.copyfile(SCRIPT, tools / 'memory_draft.py')
        shutil.copyfile(ROOT / 'department_agent/logic.py', tools / 'logic.py')
        before = {path.relative_to(self.private): path.read_bytes() for path in self.private.rglob('*') if path.is_file()}
        environment = dict(os.environ)
        environment.pop('PYTHONPYCACHEPREFIX', None)
        environment.pop('PYTHONDONTWRITEBYTECODE', None)
        result = subprocess.run([sys.executable, str(tools / 'memory_draft.py'), 'check', '--private-root', str(self.private), '--file', result['draft_path']], env=environment, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        after = {path.relative_to(self.private): path.read_bytes() for path in self.private.rglob('*') if path.is_file()}
        self.assertEqual(before, after)

    def test_private_root_alias_and_linked_config_are_rejected(self):
        alias = self.base / 'alias'
        try:
            alias.symlink_to(self.private, target_is_directory=True)
        except (OSError, NotImplementedError):
            self.skipTest('Symlinks unavailable')
        self.private = alias
        self.new(ok=False)

    def test_malformed_config_and_unsafe_member_do_not_create_drafts(self):
        path = self.private / '.department-agent/config.json'
        for changed in [dict(self.config, member='../Mallory'), dict(self.config, version=1), dict(self.config, project_id='../project')]:
            path.write_text(json.dumps(changed))
            self.new(ok=False)
            self.assertEqual(list(self.drafts.iterdir()), [])

    def test_new_members_and_display_assignees_work_without_code_changes(self):
        config_path = self.private / '.department-agent/config.json'
        for member in ('林小光', 'Alex Chen', 'José', 'Member_3', 'Member-4'):
            with self.subTest(member=member):
                config_path.write_text(json.dumps(dict(self.config, member=member)))
                result = self.new(dict(TASK, assignee="  Pat O'Connor  "), 'task')
                data = json.loads(Path(result['draft_path']).read_bytes())
                self.assertEqual(data['submitted_by'], member)
                self.assertEqual(data['payload']['assignee'], "Pat O'Connor")
                self.assertEqual(data['schema_version'], 'pp-memory/2')
                self.cli('check', '--file', result['draft_path'])

    def test_member_safe_name_rules_are_not_silently_normalized(self):
        config_path = self.private / '.department-agent/config.json'
        for member in ('', ' Alex', 'Alex ', 'Alex\nChen', 'Alex/Chen', '_Alex', 'Alex-',
                       'CON', 'lpt1', 'COM¹', 'Jose\u0301', '🧑', 'x' * 81, None, [], {}, 1, True):
            with self.subTest(member=member):
                config_path.write_text(json.dumps(dict(self.config, member=member)))
                result = self.new(ok=False)
                self.assertEqual(result['message'], '設定的工作區或本機成員名稱不符。')
                self.assertEqual(list(self.drafts.iterdir()), [])

    def test_member_validation_matches_installer_contract(self):
        modules = []
        for filename in ('memory_draft.py', 'setup_workspace.py'):
            spec = importlib.util.spec_from_file_location(filename[:-3], ROOT / 'scripts' / filename)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            modules.append(module)
        draft, installer = modules
        for value in ('林小光', 'Alex Chen', 'José', 'Member_3', 'Member-4', '123',
                      '', ' Alex', 'Alex ', 'Alex\nChen', 'Alex/Chen', '_Alex', 'Alex-',
                      'CON', 'lpt1', 'COM¹', 'Jose\u0301', '🧑', 'x' * 81, None, [], {}, 1, True):
            with self.subTest(value=value):
                try:
                    accepted = installer.validate_member(value) == value
                except installer.WorkspaceError:
                    accepted = False
                self.assertEqual(draft.valid_member(value), accepted)

    def test_draft_requires_exact_member_and_old_format_is_preserved_on_rejection(self):
        config_path = self.private / '.department-agent/config.json'
        config_path.write_text(json.dumps(dict(self.config, member='Alex Chen')))
        result = self.new()
        path = Path(result['draft_path'])
        original = json.loads(path.read_bytes())
        for changed in (dict(original, submitted_by='alex chen'), dict(original, submitted_by='林小光'),
                        dict(original, schema_version='pp-memory/1')):
            path.write_text(json.dumps(changed))
            before = path.read_bytes()
            self.cli('check', '--file', path, ok=False)
            self.assertEqual(path.read_bytes(), before)

    def test_schema_supports_new_members_and_canonical_assignee_labels(self):
        schema = json.loads((ROOT / 'team-assets/memory-draft.schema.json').read_bytes())
        self.assertEqual(schema['properties']['schema_version']['const'], 'pp-memory/2')
        member = schema['properties']['submitted_by']
        self.assertNotIn('enum', member)
        self.assertEqual(member['type'], 'string')
        self.assertEqual(member['maxLength'], 80)
        assignee = schema['allOf'][0]['else']['properties']['payload']['properties']['assignee']
        self.assertEqual(assignee['type'], ['string', 'null'])
        for value, expected in [("Pat O'Connor", True), ('林小光', True), ('A', True), ('', False),
                                (' Alex', False), ('Alex ', False), ('Alex\n', False)]:
            with self.subTest(value=value):
                self.assertEqual(bool(re.search(assignee['pattern'], value)), expected)
        self.assertEqual(assignee['maxLength'], 200)

    def test_uuid_collision_does_not_overwrite(self):
        self.assertTrue(SCRIPT.is_file(), 'memory tool must exist')
        spec = importlib.util.spec_from_file_location('memory_draft', SCRIPT)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        value = uuid.uuid4()
        source = self.base / 'payload.json'
        source.write_text(json.dumps(NOTE))
        existing = self.drafts / (str(value) + '.json')
        existing.write_bytes(b'keep me')
        with patch.object(module.uuid, 'uuid4', return_value=value):
            with self.assertRaises(FileExistsError):
                module.new_draft(str(self.private), 'note', str(source))
        self.assertEqual(existing.read_bytes(), b'keep me')


if __name__ == '__main__':
    unittest.main()
