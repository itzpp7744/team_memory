import unittest
from department_agent.logic import identity, validate_note, validate_task, apply_change, request_digest, Conflict

class LogicTests(unittest.TestCase):
    def test_identity_needs_verified_tenant_and_object_id(self):
        for claims in [{}, {'name':'Wilson'}, {'tid':'other','oid':'user'}]:
            with self.subTest(claims=claims), self.assertRaises(PermissionError):
                identity(claims, 'tenant')
        self.assertEqual(identity({'tid':'tenant','oid':'member'},'tenant'), 'member')
    def test_note_does_not_invent_approval(self):
        note=validate_note('Title','Discussion','hypothesis','pending','meeting')
        self.assertEqual(note['status'],'pending')
        with self.assertRaises(ValueError):
            validate_note('Title','Discussion','hypothesis','approved','meeting')
    def test_invalid_dates_and_empty_task_rejected(self):
        for title,date in [('',None),('Launch','tomorrow'),('Launch','2026-02-30')]:
            with self.subTest(title=title,date=date), self.assertRaises(ValueError):
                validate_task(title,None,date,'done when approved')
    def test_stale_write_never_overwrites(self):
        with self.assertRaises(Conflict):
            apply_change({'status':'open'},2,1,{'status':'done'},'task')
    def test_update_rejects_unknown_fields(self):
        with self.assertRaises(ValueError):
            apply_change({'status':'open'},1,1,{'actor':'Wilson'},'task')
    def test_request_digest_distinguishes_payloads(self):
        self.assertEqual(request_digest('task',{'a':1,'b':2}), request_digest('task',{'b':2,'a':1}))
        self.assertNotEqual(request_digest('task',{'a':1}),request_digest('task',{'a':2}))
