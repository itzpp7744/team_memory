"""Integration tests require an explicitly disposable TEST_DATABASE_URL."""
import os
import unittest
from uuid import uuid4
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import psycopg
from department_agent.store import Store
from department_agent.logic import Conflict

DSN=os.environ.get('TEST_DATABASE_URL')
@unittest.skipUnless(DSN,'需要獨立測試 Postgres；不得使用正式資料庫')
class StoreTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with psycopg.connect(DSN) as conn:
            conn.execute(Path('sql/001_init.sql').read_text())
            conn.execute("INSERT INTO department_agent.members(oid,display_name) VALUES ('wilson','Wilson'),('avril','Avril')")
    @classmethod
    def tearDownClass(cls):
        with psycopg.connect(DSN) as conn:
            conn.execute('DROP SCHEMA department_agent CASCADE')
    def setUp(self):
        self.store=Store(DSN,'test-'+uuid4().hex)
        self.task={'title':'demo','assignee':None,'due_date':None,'completion':'approved','status':'open'}
    def test_unknown_or_revoked_member_denied(self):
        with self.assertRaises(PermissionError): self.store.read_context('intruder')
        with psycopg.connect(DSN) as conn: conn.execute("UPDATE department_agent.members SET active=false WHERE oid='avril'")
        try:
            with self.assertRaises(PermissionError): self.store.read_context('avril')
        finally:
            with psycopg.connect(DSN) as conn: conn.execute("UPDATE department_agent.members SET active=true WHERE oid='avril'")
    def test_retry_returns_original_result_and_new_payload_is_rejected(self):
        key=str(uuid4())
        a=self.store.create('wilson','task',self.task,key)
        b=self.store.create('wilson','task',self.task,key)
        self.assertEqual(a,b)
        with self.assertRaises(Conflict): self.store.create('wilson','task',{**self.task,'title':'other'},key)
        self.assertEqual(len(self.store.read_context('avril')['tasks']),1)
    def test_concurrent_updates_preserve_one_version_and_audit(self):
        item=self.store.create('wilson','task',self.task,str(uuid4()))
        def change(actor):
            try:return self.store.update(actor,item['id'],'task',1,{'status':'done'},str(uuid4()),'completed')
            except Conflict:return 'conflict'
        with ThreadPoolExecutor(2) as pool: results=list(pool.map(change,['wilson','avril']))
        self.assertEqual(results.count('conflict'),1)
        current=self.store.get('wilson',item['id'],'task')
        self.assertEqual(current['version'],2)
        with psycopg.connect(DSN) as conn:
            count=conn.execute('SELECT count(*) FROM department_agent.events WHERE project_id=%s AND action=%s',(self.store.project_id,'update_task')).fetchone()[0]
        self.assertEqual(count,1)
    def test_other_project_record_not_visible(self):
        item=self.store.create('wilson','task',self.task,str(uuid4()))
        with self.assertRaises(ValueError): Store(DSN,'another').get('wilson',item['id'],'task')
    def test_runtime_role_has_only_required_table_permissions(self):
        import subprocess,sys
        role='dept_runtime_'+uuid4().hex[:12]
        with psycopg.connect(DSN) as conn:conn.execute(psycopg.sql.SQL('CREATE ROLE {}').format(psycopg.sql.Identifier(role)))
        try:
            result=subprocess.run([sys.executable,'scripts/admin_db.py','grant','--confirm-project',self.store.project_id,'--app-role',role],
                                  env={**os.environ,'DEPT_ADMIN_DATABASE_URL':DSN,'DEPT_PROJECT_ID':self.store.project_id},capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            restricted=Store(DSN,self.store.project_id)
            def connection():
                conn=psycopg.connect(DSN,row_factory=psycopg.rows.dict_row)
                conn.execute(psycopg.sql.SQL('SET ROLE {}').format(psycopg.sql.Identifier(role)))
                return conn
            restricted.connection=connection
            item=restricted.create('wilson','task',self.task,str(uuid4()))
            self.assertEqual(restricted.get('avril',item['id'],'task')['version'],1)
            restricted.audit_document_read('wilson','drive','item','revision')
            for query in ['UPDATE department_agent.members SET active=false',
                          'DELETE FROM department_agent.events',
                          'CREATE TABLE department_agent.forbidden(id int)']:
                with connection() as conn:
                    with self.assertRaises(psycopg.errors.InsufficientPrivilege):conn.execute(query)
        finally:
            with psycopg.connect(DSN) as conn:
                conn.execute(psycopg.sql.SQL('DROP OWNED BY {}').format(psycopg.sql.Identifier(role)))
                conn.execute(psycopg.sql.SQL('DROP ROLE {}').format(psycopg.sql.Identifier(role)))
    def test_grant_rejects_role_memberships(self):
        import subprocess,sys
        role='dept_child_'+uuid4().hex[:12]
        parent='dept_parent_'+uuid4().hex[:12]
        with psycopg.connect(DSN) as conn:
            for name in [role,parent]:conn.execute(psycopg.sql.SQL('CREATE ROLE {}').format(psycopg.sql.Identifier(name)))
            conn.execute(psycopg.sql.SQL('GRANT {} TO {}').format(psycopg.sql.Identifier(parent),psycopg.sql.Identifier(role)))
        try:
            result=subprocess.run([sys.executable,'scripts/admin_db.py','grant','--confirm-project',self.store.project_id,'--app-role',role],
                                  env={**os.environ,'DEPT_ADMIN_DATABASE_URL':DSN,'DEPT_PROJECT_ID':self.store.project_id},capture_output=True,text=True)
            self.assertNotEqual(result.returncode,0)
            self.assertIn('繼承',result.stdout+result.stderr)
        finally:
            with psycopg.connect(DSN) as conn:
                for name in [role,parent]:conn.execute(psycopg.sql.SQL('DROP ROLE {}').format(psycopg.sql.Identifier(name)))
    def test_completed_document_retry_retrieval_keeps_original_version(self):
        from department_agent.logic import request_digest
        key=str(uuid4())
        body={'title':'doc','drive_id':'drive','item_id':'item','source_revision':'old','summary':'old summary'}
        digest=request_digest('register_document',{'item_id':'item','source_revision':'old'})
        created=self.store.create('wilson','document',body,key,digest=digest)
        self.assertEqual(self.store.lookup_completed('wilson',key,digest),created)
        with self.assertRaises(Conflict):self.store.lookup_completed('wilson',key,'different-digest')
        with self.assertRaises(PermissionError):self.store.lookup_completed('unknown',key,digest)
