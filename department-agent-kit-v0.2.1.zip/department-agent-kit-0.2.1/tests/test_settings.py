import unittest
from department_agent.settings import Settings

BASE = {
    'DEPT_DATABASE_URL': 'postgresql://app:fixture@db.example.test/app?sslmode=require',
    'DEPT_TENANT_ID': '11111111-1111-4111-8111-111111111111',
    'DEPT_CLIENT_ID': '22222222-2222-4222-8222-222222222222',
    'DEPT_CLIENT_SECRET': 'synthetic-test-secret',
    'DEPT_BASE_URL': 'https://agent.example.test',
    'DEPT_PROJECT_ID': 'product-a',
    'DEPT_JWT_SIGNING_KEY': 'synthetic-test-signing-key-long-enough',
    'DEPT_STORAGE_ENCRYPTION_KEY': 'o8QwAFjF0VYtxOIGUZ-FZuMWqfD0sBpqcFIQhUTDRhg=',
    'DEPT_AUTH_STORAGE_PATH': '/tmp/department-agent-test-auth',
}
class SettingsTests(unittest.TestCase):
    def test_missing_setting_fails_without_showing_secrets(self):
        with self.assertRaises(ValueError) as e:
            Settings.from_env({'DEPT_CLIENT_SECRET': 'do-not-print-me'})
        self.assertNotIn('do-not-print-me', str(e.exception))
    def test_requires_https_and_no_url_credentials(self):
        for url in ['http://example.test', 'https://user:pass@example.test', 'https://example.test?token=x', 'https://example.test/base']:
            with self.subTest(url=url), self.assertRaises(ValueError):
                Settings.from_env({**BASE, 'DEPT_BASE_URL': url})
    def test_requires_specific_tenant_and_encrypted_database(self):
        for change in [{'DEPT_TENANT_ID':'common'}, {'DEPT_DATABASE_URL':'postgresql://app:x@db.test/app'}]:
            with self.subTest(change=change), self.assertRaises(ValueError):
                Settings.from_env({**BASE, **change})
    def test_graph_partial_configuration_rejected(self):
        with self.assertRaises(ValueError):
            Settings.from_env({**BASE, 'DEPT_DRIVE_ID': 'drive'})
    def test_disabled_documents_is_explicit(self):
        settings = Settings.from_env(BASE)
        self.assertFalse(settings.documents_enabled)
        self.assertEqual(settings.project_id, 'product-a')
    def test_auth_storage_cannot_be_filesystem_root(self):
        with self.assertRaises(ValueError):
            Settings.from_env({**BASE,'DEPT_AUTH_STORAGE_PATH':'/'})
