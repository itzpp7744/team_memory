"""Admin member input checks; database access is always mocked."""
import importlib.util
import io
import os
from pathlib import Path
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('admin_db', ROOT / 'scripts/admin_db.py')
admin_db = importlib.util.module_from_spec(spec)
spec.loader.exec_module(admin_db)
OID = '12345678-1234-4234-8234-123456789abc'


class AdminMemberTests(unittest.TestCase):
    def invoke(self, name, oid=OID):
        argv = ['admin_db.py', 'add-member', '--confirm-project', 'pp-team', '--oid', oid, '--name', name]
        environment = {'DEPT_PROJECT_ID': 'pp-team', 'DEPT_ADMIN_DATABASE_URL': 'synthetic-unused-dsn'}
        with patch('sys.argv', argv), patch.dict(os.environ, environment), patch('sys.stdout', new_callable=io.StringIO):
            admin_db.main()

    def test_new_member_name_is_normalized_and_inserted_as_parameter(self):
        for name in (' 林小光 ', "Pat O'Connor", 'Alex Chen'):
            with self.subTest(name=name), patch.object(admin_db.psycopg, 'connect') as connect:
                self.invoke(name)
                connection = connect.return_value.__enter__.return_value
                connection.execute.assert_called_once_with(
                    'INSERT INTO department_agent.members(oid,display_name) VALUES (%s,%s)',
                    (OID, name.strip()))

    def test_invalid_display_names_are_rejected_before_database_access(self):
        for name in ('', '   ', 'x' * 201, 'Alex\nChen', 'Alex\x00Chen'):
            with self.subTest(name=repr(name)), patch.object(admin_db.psycopg, 'connect') as connect:
                with self.assertRaises(SystemExit):
                    self.invoke(name)
                connect.assert_not_called()

    def test_invalid_company_oid_is_rejected_before_database_access(self):
        with patch.object(admin_db.psycopg, 'connect') as connect:
            with self.assertRaises((SystemExit, ValueError)):
                self.invoke('Alex Chen', oid='not-a-company-uuid')
            connect.assert_not_called()


if __name__ == '__main__':
    unittest.main()
