#!/usr/bin/env python3
"""Create/check local PP memory drafts. No network, database, or identity claims."""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import sys
import unicodedata
import uuid

MAX_BYTES = 1024 * 1024
CONFIG_KEYS = {'version', 'member', 'project_id', 'private_root', 'shared_root', 'mcp_url'}
ENVELOPE_KEYS = {'schema_version', 'project_id', 'kind', 'request_id', 'submitted_by', 'delivery', 'payload'}
PAYLOAD_KEYS = {'note': {'title', 'content', 'category', 'status', 'source'},
                'task': {'title', 'completion', 'assignee', 'due_date'}}


class DraftError(ValueError):
    pass


def valid_member(value: object) -> bool:
    """Same portable folder-label contract as setup_workspace; not identity proof."""
    return (isinstance(value, str) and 1 <= len(value) <= 80
            and unicodedata.normalize('NFC', value) == value
            and value[0].isalnum() and value[-1].isalnum()
            and all(character.isalnum() or character in ' _-' for character in value)
            and re.fullmatch(r'(?:con|prn|aux|nul|com[1-9¹²³]|lpt[1-9¹²³])', value, re.IGNORECASE) is None)


def checked_path(value: str | Path) -> Path:
    path = Path(value).expanduser()
    if '..' in path.parts or any(ord(character) < 32 for character in str(path)):
        raise DraftError('路徑不可包含上層跳轉或控制字元。')
    if not path.is_absolute():
        path = Path.cwd() / path
    for part in [*reversed(path.parents), path]:
        try:
            metadata = part.lstat()
        except FileNotFoundError:
            continue
        if part.is_symlink() or getattr(metadata, 'st_reparse_tag', 0) == 0xA0000003:
            aliases = {'/var': '/private/var', '/tmp': '/private/tmp'}
            if not (sys.platform == 'darwin' and str(part) in aliases
                    and part.is_symlink() and str(part.resolve()) == aliases[str(part)]):
                raise DraftError('路徑不可包含符號連結或 junction。')
    return path.resolve()


def unique_object(pairs: list) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise DraftError('JSON 不可重複欄位。')
        result[key] = value
    return result


def read_object(path: Path) -> dict:
    path = checked_path(path)
    if not stat.S_ISREG(path.stat().st_mode) or path.stat().st_size > MAX_BYTES:
        raise DraftError('只接受不超過 1 MiB 的一般 JSON 檔案。')
    with path.open('rb') as stream:
        contents = stream.read(MAX_BYTES + 1)
    if len(contents) > MAX_BYTES:
        raise DraftError('JSON 檔案超過 1 MiB。')
    try:
        data = json.loads(contents.decode('utf-8'), object_pairs_hook=unique_object)
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise DraftError('檔案必須是有效的 UTF-8 JSON。') from exc
    if not isinstance(data, dict):
        raise DraftError('JSON 最外層必須是物件。')
    return data


def workspace(private_value: str) -> tuple[dict, Path]:
    if not Path(private_value).expanduser().is_absolute():
        raise DraftError('私有工作區必須是絕對路徑。')
    private = checked_path(private_value)
    if private == Path(private.anchor) or private == Path.home().resolve():
        raise DraftError('請使用專案專用的私有工作區。')
    config = read_object(private / '.department-agent/config.json')
    if set(config) != CONFIG_KEYS or type(config['version']) is not int or config['version'] != 2:
        raise DraftError('設定版本不符，請使用這一版安裝器建立新的私有工作區。')
    if config['private_root'] != str(private) or not valid_member(config['member']):
        raise DraftError('設定的工作區或本機成員名稱不符。')
    project = config['project_id']
    if not isinstance(project, str) or len(project) > 80 or not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', project):
        raise DraftError('專案代號格式錯誤。')
    drafts = checked_path(private / 'drafts/memory')
    if not drafts.is_dir():
        raise DraftError('缺少 drafts/memory，請先完成工作區安裝與 doctor 檢查。')
    return config, drafts


def validated_payload(kind: str, payload: dict) -> dict:
    if kind not in PAYLOAD_KEYS or not isinstance(payload, dict) or set(payload) != PAYLOAD_KEYS[kind]:
        raise DraftError('草稿種類或 payload 欄位不符；不接受缺漏或額外欄位。')
    # The installed tool imports its adjacent managed copy; repository execution
    # uses the same business validator without importing the server dependencies.
    local = Path(__file__).resolve().parent / 'logic.py'
    source = local if local.is_file() else Path(__file__).resolve().parents[1] / 'department_agent/logic.py'
    spec = importlib.util.spec_from_file_location('pp_memory_logic', checked_path(source))
    module = importlib.util.module_from_spec(spec)
    previous = sys.dont_write_bytecode
    try:
        sys.dont_write_bytecode = True
        spec.loader.exec_module(module)
    finally:
        sys.dont_write_bytecode = previous
    try:
        if kind == 'note':
            if payload['status'] not in ('pending', 'confirmed'):
                raise DraftError('新記憶狀態僅接受 pending 或 confirmed。')
            return module.validate_note(**payload)
        due = payload['due_date']
        if due is not None and (not isinstance(due, str) or not re.fullmatch(r'[0-9]{4}-[0-9]{2}-[0-9]{2}', due)):
            raise DraftError('日期必須是 YYYY-MM-DD 或 null。')
        result = module.validate_task(**payload)
        result.pop('status')
        return result
    except (ValueError, TypeError) as exc:
        if isinstance(exc, DraftError):
            raise
        raise DraftError('內容欄位、長度、狀態或日期格式不符。') from exc


def validate_envelope(data: dict, config: dict) -> dict:
    if set(data) != ENVELOPE_KEYS or data['schema_version'] != 'pp-memory/2' or data['delivery'] != 'draft':
        raise DraftError('記憶封套欄位、版本或 delivery 不符。')
    if data['project_id'] != config['project_id'] or data['submitted_by'] != config['member']:
        raise DraftError('草稿的專案或本機成員名稱與目前工作區不符。')
    request_id = data['request_id']
    if not isinstance(request_id, str):
        raise DraftError('request_id 必須是標準 UUID。')
    try:
        valid = str(uuid.UUID(request_id))
    except ValueError as exc:
        raise DraftError('request_id 必須是標準 UUID。') from exc
    if request_id != valid:
        raise DraftError('request_id 必須是小寫標準 UUID。')
    normalized = validated_payload(data['kind'], data['payload'])
    if normalized != data['payload']:
        raise DraftError('草稿含尚未正規化的空白；請重新建立草稿。')
    return data


def summary(path: Path, request_id: str) -> dict:
    return dict(draft_path=str(path), request_id=request_id, cloud_status='NOT_SENT')


def new_draft(private_value: str, kind: str, input_value: str) -> dict:
    config, drafts = workspace(private_value)
    payload = validated_payload(kind, read_object(Path(input_value)))
    request_id = str(uuid.uuid4())
    data = dict(schema_version='pp-memory/2', project_id=config['project_id'], kind=kind,
                request_id=request_id, submitted_by=config['member'], delivery='draft', payload=payload)
    validate_envelope(data, config)
    # Recheck immediately before creating; never replace a same-named file.
    current_config, current_drafts = workspace(private_value)
    if current_config != config or current_drafts != drafts:
        raise DraftError('工作區設定在檢查後已變更。')
    path = checked_path(drafts / (request_id + '.json'))
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, 'w', encoding='utf-8', newline='\n') as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    if read_object(path) != data:
        raise DraftError('草稿寫入後讀回不符，未送出。')
    return summary(path, request_id)


def check_draft(private_value: str, file_value: str) -> dict:
    config, drafts = workspace(private_value)
    path = checked_path(file_value)
    if path.parent != drafts:
        raise DraftError('只能檢查目前工作區 drafts/memory 內的草稿。')
    data = validate_envelope(read_object(path), config)
    if path.name != data['request_id'] + '.json':
        raise DraftError('草稿檔名與 request_id 不符。')
    return summary(path, data['request_id'])


def main() -> int:
    parser = argparse.ArgumentParser(description='PP 本機記憶草稿：不連外、不送出')
    commands = parser.add_subparsers(dest='command', required=True)
    for name in ('new', 'check'):
        command = commands.add_parser(name)
        command.add_argument('--private-root', required=True)
        if name == 'new':
            command.add_argument('--kind', required=True, choices=('note', 'task'))
            command.add_argument('--input', required=True)
        else:
            command.add_argument('--file', required=True)
    args = parser.parse_args()
    try:
        if sys.version_info < (3, 11):
            raise DraftError('需要 Python 3.11 或更新版本。')
        result = (new_draft(args.private_root, args.kind, args.input) if args.command == 'new'
                  else check_draft(args.private_root, args.file))
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (OSError, ValueError, TypeError, RecursionError) as exc:
        message = str(exc) if isinstance(exc, DraftError) else '檔案或欄位無效；草稿未送出，既有檔案不會被覆寫。'
        print(json.dumps(dict(status='ERROR', message=message, cloud_status='NOT_SENT'), ensure_ascii=False, indent=2))
        return 2


if __name__ == '__main__':
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    raise SystemExit(main())
