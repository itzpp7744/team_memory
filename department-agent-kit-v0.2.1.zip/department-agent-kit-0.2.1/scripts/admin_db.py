"""Explicit admin-only setup. No automatic migrations on service start."""
import argparse
import os
import re
from pathlib import Path
from uuid import UUID
import psycopg
from psycopg import sql

def main():
    parser=argparse.ArgumentParser(description='只供管理者設定已核准的全新部門資料庫')
    parser.add_argument('action',choices=['init','grant','add-member','revoke-member'])
    parser.add_argument('--confirm-project',required=True)
    parser.add_argument('--app-role')
    parser.add_argument('--oid')
    parser.add_argument('--name')
    args=parser.parse_args()
    project=os.environ.get('DEPT_PROJECT_ID')
    if not project or args.confirm_project!=project:
        raise SystemExit('專案確認不符；沒有執行資料庫操作')
    dsn=os.environ.get('DEPT_ADMIN_DATABASE_URL')
    if not dsn:raise SystemExit('缺少 DEPT_ADMIN_DATABASE_URL；請由管理者在環境變數設定，不要貼進聊天')
    if args.action=='grant' and (not args.app_role or not re.fullmatch(r'[a-z][a-z0-9_]{0,62}',args.app_role)):
        raise SystemExit('grant 需要指定已存在的受限 --app-role')
    if args.action in {'add-member','revoke-member'}:
        if not args.oid:raise SystemExit('需要公司成員 --oid')
        args.oid=str(UUID(args.oid))
    if args.action=='add-member':
        if not args.name or not args.name.strip() or len(args.name)>200 or not args.name.isprintable():
            raise SystemExit('--name 必須是 1–200 字元的有效顯示姓名，不可含控制字元')
        args.name=args.name.strip()
    try:
        with psycopg.connect(dsn,connect_timeout=10) as conn:
            if args.action=='init':
                existing=conn.execute('SELECT 1 FROM pg_namespace WHERE nspname=%s',('department_agent',)).fetchone()
                if existing:raise SystemExit('department_agent schema 已存在；拒絕覆蓋或重建')
                conn.execute((Path(__file__).resolve().parents[1]/'sql/001_init.sql').read_text())
            elif args.action=='grant':
                role=sql.Identifier(args.app_role)
                info=conn.execute('SELECT rolsuper,rolcreaterole,rolcreatedb,rolreplication,rolbypassrls FROM pg_roles WHERE rolname=%s',(args.app_role,)).fetchone()
                if not info or any(info):raise SystemExit('應用程式角色不存在或具有管理權限；拒絕授權')
                inherited=conn.execute('SELECT 1 FROM pg_auth_members m JOIN pg_roles r ON r.oid=m.member WHERE r.rolname=%s LIMIT 1',(args.app_role,)).fetchone()
                db_create=conn.execute("SELECT has_database_privilege(%s,current_database(),'CREATE')",(args.app_role,)).fetchone()[0]
                if inherited or db_create:raise SystemExit('應用程式角色不得繼承其他角色或擁有資料庫建立權限')
                owner=conn.execute("SELECT pg_get_userbyid(nspowner) FROM pg_namespace WHERE nspname='department_agent'").fetchone()
                if not owner or owner[0]==args.app_role:raise SystemExit('應用程式角色不能是 schema 擁有者')
                owned=conn.execute("SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='department_agent' AND pg_get_userbyid(c.relowner)=%s LIMIT 1",(args.app_role,)).fetchone()
                if owned:raise SystemExit('應用程式角色不能擁有部門資料表或序列')
                conn.execute(sql.SQL('REVOKE ALL ON SCHEMA department_agent FROM {}').format(role))
                conn.execute(sql.SQL('REVOKE ALL ON ALL TABLES IN SCHEMA department_agent FROM {}').format(role))
                conn.execute(sql.SQL('REVOKE ALL ON ALL SEQUENCES IN SCHEMA department_agent FROM {}').format(role))
                conn.execute(sql.SQL('GRANT USAGE ON SCHEMA department_agent TO {}').format(role))
                conn.execute(sql.SQL('GRANT SELECT ON department_agent.members TO {}').format(role))
                conn.execute(sql.SQL('GRANT SELECT,INSERT,UPDATE ON department_agent.records,department_agent.requests TO {}').format(role))
                conn.execute(sql.SQL('GRANT INSERT ON department_agent.events TO {}').format(role))
                conn.execute(sql.SQL('GRANT USAGE ON ALL SEQUENCES IN SCHEMA department_agent TO {}').format(role))
            elif args.action=='add-member':
                conn.execute('INSERT INTO department_agent.members(oid,display_name) VALUES (%s,%s)',(args.oid,args.name))
            else:
                changed=conn.execute('UPDATE department_agent.members SET active=false WHERE oid=%s RETURNING oid',(args.oid,)).fetchone()
                if not changed:raise SystemExit('找不到成員；未變更任何身分')
    except psycopg.Error:
        raise SystemExit('資料庫設定失敗；請管理者檢查目標、連線與權限。未輸出連線密碼。') from None
    print('管理者操作完成；這不代表成員登入與同步已驗收。')

if __name__=='__main__':main()
