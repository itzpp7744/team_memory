# PP 團隊上手與 Obsidian

Vault 就是 Obsidian 打開的一個筆記資料夾，裡面仍是普通 Markdown（`.md`）檔。本流程由每個人電腦上的 AI 帶著本人完成；管理者這邊不能隔空判斷是否安裝。

## 已知資訊與先決條件

- 管理者 Elio 已建立 [PP 團隊專案](https://drive.google.com/drive/folders/1_OrdKAQBzqSQt9EIaKza9SwzA4GvZ2-J)。交付時尚未分享給兩人，必須再確認最新權限。
- Wilson 使用 Windows；Avril 使用 Mac 為主、另一台公司電腦為輔。成員身分跟人走。
- 兩人需各自能讀私人 GitHub repo，並用各自獲准的 Google 帳號讀寫共享資料夾。由管理者設定權限，安裝器不會代做。

安裝 AI 先詢問新人姓名／唯一稱呼，依 START_HERE 的安全姓名規則確認；Wilson／Avril 只是目前成員，不是可選名單。同名者加區別，已安裝者沿用 config.member。

## A. 先確認有沒有 Obsidian

先問本人是否已安裝、是否正在使用個人 Vault。本人提供的既有資訊不重問。AI 有本機工具時只檢查應用程式是否存在，不掃描筆記內容：

- Windows：從開始功能表／已安裝的應用程式找 Obsidian；可能有每位使用者或自訂位置的安裝，單一路徑找不到不代表未安裝。
- Mac：查看「應用程式」或 Spotlight 的 Obsidian；若安裝於其他位置由本人指定。
- 已安裝：確認可以開啟及版本，保留個人 Vault 和外掛。
- 未安裝：依 [官方下載](https://obsidian.md/download) 和 [安裝說明](https://obsidian.md/help/install) 協助安裝。需要公司 IT 核准時記為待處理，不繞過公司限制。

不要因為管理者電腦有 Obsidian，就回報兩位成員都有。

## B. 兩個空間，避免私人內容進共享區

1. **團隊 Vault**：就是安裝器設定的 shared_root，也就是本機 Google Drive 的「PP 團隊專案」。在 Obsidian 選「Open folder as vault／開啟資料夾為儲存庫」，開啟已存在資料夾；不要再建一個同名副本或巢狀 Vault。
2. **私人工作區**：config 的 private_root，放個人草稿和 AI 設定。需要用 Obsidian 閱讀時，可以另開為私人 Vault，但不能加進團隊 Drive；原本個人 Vault 繼續保留，不搬移。

團隊分類沿用 00／10／20／30／40／80／90／99，詳 TEAM_RULES。兩人不各建不同分類；先以搜尋、標籤和連結導覽，不急著裝外掛。

## C. 每台電腦分開 Obsidian 設定

第一次開啟團隊 Vault 後，先不要設定外掛。到 Settings → Files and Links → Override config folder，改成這台裝置專用名稱，再重新開啟 Obsidian：

| 裝置 | 設定資料夾名稱 |
| --- | --- |
| Wilson 主力 Windows | `.obsidian-wilson-win-main` |
| Avril 主力 Mac | `.obsidian-avril-mac-main` |
| Avril 備用電腦 | `.obsidian-avril-company-secondary` |

新成員用 `.obsidian-<本人簡短代稱>-<裝置代稱>`，先確認不與任何現有裝置重複；此代稱是設定資料夾名稱，不會改變 config.member。

這是官方支援的設定資料夾切換方式；舊設定不會自動搬過去，也不要刪除原 `.obsidian`。同一個人新裝置要用新名稱，不能兩台共用同一設定檔名。[官方說明](https://obsidian.md/help/configuration-folder)

這些設定資料夾仍可能被 Google Drive 同步，**不是私人安全區**；名稱分開只防互相覆蓋，不提供權限隔離。不要在團隊 Vault 的任何外掛設定放金鑰。起步只用內建搜尋、反向連結和大綱；不自動安裝社群外掛或啟用 Obsidian Git。

## D. 實作一次閱讀、修改、分享

1. 把團隊 Vault 的一般檔案設為 Google Drive「可離線使用」，等內容下載；若公司政策不允許，記錄限制並暫不做離線編輯。
2. 使用安裝好的 PRD／MEETING 範本，在私人 drafts/documents 建一份無機密練習筆記。
3. 由本人要求分享後，新增到共享 `80_修改提案/<member>/YYYY-MM-DD_上手練習_<member>.md`；已有檔案就換唯一檔名，不覆寫。
4. 另一人用 Obsidian 打開並回報內容；反向再做一次。不要同時編輯同一 `.md`，這不是 Google Docs 的即時共同編輯。
5. 管理者審閱後，才把正式內容放對應分類。可在 `00_專案說明` 新增專案首頁，連到需求、會議、簡報與文件來源；不把正式任務狀態另建一套表。

Google Drive 是這個 Vault 唯一檔案同步方式，不同時加 iCloud、Obsidian Sync 或 Git 同步同一資料夾。Google Drive 的 Obsidian 同步屬需自行驗證的第三方方案；此版只安排 Windows／Mac，沒有承諾 iPhone 可用。[官方同步限制](https://obsidian.md/help/sync-notes)

## E. 完成驗收並教第一次工作

- 在 Claude Code 私有工作區讀 6 個 PP Skills，先用 pp-start-work 找到剛才的筆記。
- 用 pp-memory-handoff 建立一筆交接草稿並 check，明說尚未送出；不是聊天原文同步。
- 依 pp-sync-check 做雙向隨機檔案驗證，每個方向重複 3 次，記錄送出、收到時間與檔案大小。兩邊時鐘需一致；時間僅作觀測，內容以檔案指紋核對。
- 沒有固定同步秒數承諾；5 分鐘未收到時先查登入、分享、網路、離線和 Drive 錯誤。5 分鐘是團隊排查門檻，不是服務保證。
- 填 ONBOARDING_REPORT。列出已完成、未驗證、卡點；只有本人完成操作才寫完成。
