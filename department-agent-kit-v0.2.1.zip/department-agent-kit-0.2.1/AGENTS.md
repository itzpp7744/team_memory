# PP 安裝包的開發／安裝規則

先讀 START_HERE.md。這是 PP 自有安裝與協作套件，所有成員共用相同版本、資料夾分類及 pp-memory/2 格式。Google Drive 負責共享文件，Neon 服務部署後才負責正式記憶與待辦。

- 設定只寫在本人指定的私有工作區；不改全域 AI 設定、不掃私人聊天、不存明文密鑰。
- 安裝依 plan→install→doctor，預覽和衝突檢查不跳過。已授權且範圍清楚的步驟直接完成；缺真人登入／帳號／路徑時才問缺少的資料。
- 不覆寫既有個人 CLAUDE.md／AGENTS.md、同名不同內容的 Skill、其他人的提案或正式文件。
- Skills 發布來源在 .agent/skills，安裝成專案 .claude/skills 的受管副本；同版本必須相同，不在使用者工作區各改各的。
- schema、規則、範本與工具變更需更新版本並驗證兩人的一致性；共享標記不是權限系統。
- 欄位對照以 team-assets/reference/MEMORY_FORMAT.md 和既有服務驗證程式為準；本機草稿永遠不代表已保存雲端。
- Google Drive 的本機設定、真人同步、雲端記憶與手機使用分開驗收。不要把 Microsoft Graph 文件工具拿去讀 Google Drive。
- 工作文件與私人設定不進 GitHub；repo 只發程式、空白範本與規則。不再散布任何課程原文。

安裝後請切換到私有工作區，讀 .department-agent/WORKSPACE.md。
