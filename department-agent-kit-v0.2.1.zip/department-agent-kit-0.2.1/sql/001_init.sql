-- Apply once to a NEW department database. Existing schema is a hard error.
BEGIN;
CREATE SCHEMA department_agent;
REVOKE ALL ON SCHEMA department_agent FROM PUBLIC;
CREATE TABLE department_agent.members (
  oid text PRIMARY KEY,
  display_name text NOT NULL,
  active boolean NOT NULL DEFAULT true
);
CREATE TABLE department_agent.records (
  id uuid PRIMARY KEY,
  project_id text NOT NULL,
  kind text NOT NULL CHECK (kind IN ('note','task','document')),
  body jsonb NOT NULL,
  version integer NOT NULL DEFAULT 1 CHECK (version > 0),
  created_by text NOT NULL REFERENCES department_agent.members(oid),
  updated_by text NOT NULL REFERENCES department_agent.members(oid),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX records_project_kind ON department_agent.records(project_id,kind,updated_at DESC);
CREATE UNIQUE INDEX documents_cloud_identity ON department_agent.records
  (project_id,(body->>'drive_id'),(body->>'item_id')) WHERE kind = 'document';
CREATE TABLE department_agent.requests (
  actor text NOT NULL REFERENCES department_agent.members(oid),
  project_id text NOT NULL,
  request_id uuid NOT NULL,
  digest text NOT NULL,
  result jsonb,
  PRIMARY KEY(actor,project_id,request_id)
);
CREATE TABLE department_agent.events (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  actor text NOT NULL REFERENCES department_agent.members(oid),
  project_id text NOT NULL,
  action text NOT NULL,
  record_id uuid,
  previous jsonb,
  current jsonb,
  reason text,
  created_at timestamptz NOT NULL DEFAULT now()
);
COMMIT;
