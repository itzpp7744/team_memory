---
name: pp-memory-handoff
description: 將 PP 專案的事實、假設、決策、交接或待辦整理成統一記憶草稿，驗證後依本人授權送到已接通的部門服務。適用「記住這個決策」「存共用記憶」「整理交接」；不整批同步私人對話。
---
# PP 記憶與交接

讀 `.department-agent/config.json`、`.department-agent/reference/TEAM_RULES.md` 和 `.department-agent/reference/MEMORY_FORMAT.md`。後者是欄位與工具對照的唯一說明，不另創記憶格式。

1. 只整理使用者要保存的工作資訊。原話未拍板就 pending；假設保留 hypothesis。來源寫能追查的會議、文件或使用者確認，不編造責任人或期限。
2. 在私有 drafts 建 payload 輸入檔，依範本填完後，用 `.department-agent/tools/memory_draft.py new` 建草稿，再用 `check` 核對。Windows 使用 `py -3`，Mac 使用 `python3`。這些工具不會自動上傳。
3. 沒有服務網址、未登入、服務不可用或專案未核對時，停在本機草稿並明說「未送出」。不使用其他私人 Neon、通用 SQL 工具或共用密碼繞過未部署的服務。
4. 使用者已授權保存且部門服務確實可用時，按照 MEMORY_FORMAT 對照呼叫 save_note／create_task。沿用 request_id，只傳工具接受的欄位；submitted_by 不是授權依據。
5. 成功須有實際 id 與 version。結果不明時保留相同請求，重試不換 ID；更正既有紀錄先讀版本，遇衝突重新比較。

已授權本次保存就不重複詢問同一件事。無關私人內容或擴大分享範圍不包含在該授權內。本機格式驗證成功不等於雲端保存成功。
