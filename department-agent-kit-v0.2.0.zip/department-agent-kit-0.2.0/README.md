# PP 團隊 AI 工作區

版本 **0.2.0**。Wilson 和 Avril 都從 [START_HERE.md](START_HERE.md) 安裝；它會帶領 AI 設定 Google Drive 共享文件、相同資料夾分類、6 個 PP 專用 Skills 與同一記憶草稿格式。

程式與說明的交付位置：[itzpp7744/team_memory](https://github.com/itzpp7744/team_memory)。本包不包含課程文件原文，也不修改兩人的全域 AI 設定。

## 安裝後會有什麼

| 位置 | 內容 |
| --- | --- |
| 私有工作區 | drafts/documents、drafts/memory、temp、專案 Skills 與各台設定 |
| Google Drive 共享區 | 同一套 00／10／20／30／40／80／90／99 分類；兩人自己的提案子目錄 |
| 共用版本標記 | project_id、套件版本、記憶格式、資產指紋；裝錯專案或混版本會停止 |
| 記憶草稿工具 | 檢查欄位、日期、狀態和成員／專案，使用與遠端服務相同的內容驗證函式 |

6 個 Skills：`pp-start-work`、`pp-memory-handoff`、`pp-pm-documents`、`pp-sync-check`。它們會安裝到本人工作區的 `.claude/skills`，內容保持一致；Python 工具只使用標準函式庫，本機安裝不用下載遠端服務依賴。

## 資料的唯一正式位置

文件原稿留 Google Drive；私人初稿留各自電腦；部署後的 Neon 才是正式共用記憶與待辦的資料來源。未接通時只產生待送出草稿，不會用 Google Drive 的另一份表格假裝 Neon 已存在。兩人不各建一個需要互相複製的本機資料庫。

## 哪些還沒上線

本包完成的是本機安裝、格式驗證與同步驗收工具。Google Drive 的真實權限／同步、Windows 實機、Neon 部署、公司登入與手機 Claude 尚待驗收。Google Drive 文件 API、Gmail 收發及 Google Slides 自動產生不在這版已實作能力內。現有遠端記憶服務仍用 Microsoft 身分，不能把它當成 Google 登入服務。

[管理者設定](docs/ADMIN_SETUP.md) · [已知限制](docs/KNOWN_LIMITATIONS.md) · [驗收清單](docs/ACCEPTANCE.md) · [驗證紀錄](docs/VERIFICATION.md)

## 安裝後與團隊擴充

共同入口會接著帶兩人做 Obsidian 與 Vault onboarding；詳 [上手流程](team-assets/reference/ONBOARDING.md)。管理者已建立指定 Drive 資料夾，分享權限仍待處理。

需要新功能或分享自己做的 Skill，走 [團隊改進與發布](team-assets/reference/TEAM_EVOLUTION.md)。新增同仁需要先擴充目前的成員驗證，不能冒用現有名字。[後續模組建議](docs/TEAM_MODULES.md) 區分目前功能與下一階段。
