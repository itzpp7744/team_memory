# PP Team Kit Implementation Plan

> **For agentic workers:** Use subagent-driven-development for implementation and independent spec/quality review. Existing isolated output repository, branch build/initial. User authorized implementation and GitHub publication; no further approval needed for this deliverable.

**Goal:** Deliver a single PP installation entry for Wilson Windows and Avril Mac/secondary Windows, with Google Drive document setup, identical team rules/Skills and validated memory drafts.

**Architecture:** Existing local installer installs release-managed assets into each private workspace, preserving existing personal instructions and unrelated skills. Shared Drive root contains one project/version contract. Neon remains the sole future authoritative memory service; local draft JSON reuses server payload validators and never pretends to have been sent. Existing Entra cloud service remains optional and not deployed; Google cloud document API is not implemented in this release.

**Tech Stack:** Python 3.11+ stdlib installer/drafts, Markdown Skills, JSON contract/schema, existing FastMCP/Postgres service.

## Task 1: Release assets and normative documentation
- [x] Author six original Skills: pp-start-work, pp-memory-handoff, pp-pm-documents, pp-sync-check, pp-onboarding, pp-team-improvement. No course content redistribution.
- [x] Author team-assets/reference/TEAM_RULES.md and MEMORY_FORMAT.md, JSON Schema pp-memory/1, templates shared with existing PM templates.
- [x] Define stable shared directories (existing 00/10/20/30/40/80/90/99), private drafts/memory, drafts/documents, temp and managed configuration. No local DB replication.

## Task 2: Installer and memory drafting tools (test first)
- [x] Extend tests/test_setup_workspace.py: same release assets for two members, project/version mismatch rejected before mutation, modified managed Skill rejected, existing unrelated settings preserved, Google status unverified, no-write plan.
- [x] Install team-assets/reference and schema under .department-agent; Skills from .agent/skills into project .claude/skills (managed identical copies to avoid Windows symlink permissions); templates and tools into .department-agent.
- [x] Add shared 00_專案說明/PP_TEAM_STANDARD.json with project/release/schema/assets digest. Refuse differing project or release before any write; doctor rechecks bytes. No in-place overwrite of prior installation; old workspaces preserved and migration documented.
- [x] Write tests/test_memory_draft.py then scripts/memory_draft.py. new/check use fixed private drafts/memory, strict envelope, canonical UUID, project/member match, allowed payload keys and existing note/task validation. No network, no credentials, no false persisted/confirmed actor. File creation exclusive, path/link checks, no caller-controlled output destination.
- [x] Run new tests RED then all local tests GREEN. Integration exercise two members, replay, tampering, wrong member/project and official task payload compatibility.

## Task 3: One entry, verification, publication
- [x] Rewrite README and START_HERE around Google Drive; move old administrator-specific instructions to explicit Microsoft service guide, no conflicting automatic setup instructions.
- [x] Verify all managed assets exist, Skills validate, document links, no secrets, package integrity; independent spec then quality review.
- [ ] Publish version 0.2.0 archive, checksum, manifest and single root entry to existing private GitHub repository. Retain old archive but mark superseded.
- [ ] Download published package and verify SHA-256. Final distinguish software verification from unperformed live Google/Neon/device deployment.

User scope addition: Obsidian installation check and Vault onboarding; administrator feature requests and member-created contributions; future-member limitations. Implemented in two added Skills, two references, templates and single entry. Publication receipt is kept outside the source archive after remote verification.
