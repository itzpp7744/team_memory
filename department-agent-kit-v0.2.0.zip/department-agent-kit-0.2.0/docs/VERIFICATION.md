# 交付前驗證

版本：0.2.0。日期：2026-10-27。

這份紀錄證明安裝套件通過程式檢查；不代表公司正式環境已接通。

| 項目 | 結果 |
| --- | --- |
| 完整測試 | macOS、Python 3.13.2；76 項通過，沒有跳過 |
| 本機安裝器 | 33 項：重跑、兩人成套安裝、版本／專案不符拒絕、保留個人設定、拒絕連結路徑、檔案校驗 |
| 記憶草稿 | 13 項：欄位、成員、專案、日期、UUID、重複欄位、空白正規化與格式定義一致性 |
| 設定與資料規則 | 12 項：設定驗證與既有服務的資料規則 |
| 文件讀取 | 6 項：既有 Microsoft 文件功能的限制與內容檢查；不代表 Google 文件 API 已實作 |
| MCP 服務 | 5 項：登入要求、工具清單、重試與讀取紀錄 |
| Postgres 整合 | 7 項：獨立本機 PostgreSQL 16、虛構資料、私有連線；未連現有 Neon |
| Python 相容性 | 安裝器與草稿工具共 46 項，在 Python 3.11 與 3.13 通過 |
| 雙人模擬 | 各自安裝後建立並檢查共 4 筆草稿、6 個 Skills 內容一致、雙向測試檔驗證；同一台機器的暫存資料夾，不代表真實 Drive 同步 |
| Skills | 6 個 SKILL.md 通過格式驗證；安裝後的相依檔案均在私有工作區內 |

不需要外部套件即可重跑本機工具測試：

```sh
python3 -m unittest discover -s tests -p test_setup_workspace.py -v
python3 -m unittest discover -s tests -p test_memory_draft.py -v
```

完整測試需安裝 requirements.lock，並把 TEST_DATABASE_URL 環境變數指向可丟棄的專用測試資料庫。測試會建立及刪除自己的 department_agent schema（資料表群組），需要建立測試角色的權限；不可指向正式資料庫。

```sh
python3 -m unittest discover -s tests -v
```

沒有 TEST_DATABASE_URL 時，7 項資料庫測試會跳過，不能把這種結果稱為全部通過且無跳過。

## 尚未實際驗證

- Windows 實機，以及 Wilson／Avril 的 Claude Code 是否載入 Skills。
- 兩台電腦經 Google Drive 的真實雙向同步、分享權限與原生 Docs／Slides 內容讀取。
- GitHub Actions：目前 repo 提供 ZIP，需先將完整原始碼展開為 repo 檔案才能啟用包內工作流程。
- 真實 Neon、Microsoft 公司登入、Docker／主機部署、手機 Claude 連線。
- Google 雲端文件 API 與 Google 登入尚未實作；不得用現有 Microsoft 服務宣稱已支援。

請依 ADMIN_SETUP 與 ACCEPTANCE 完成正式驗收。所有測試身分與憑證都是虛構值，不可複製到正式設定。
