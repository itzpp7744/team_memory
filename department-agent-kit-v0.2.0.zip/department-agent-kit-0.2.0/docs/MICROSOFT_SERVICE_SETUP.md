# 選配：Microsoft 身分的記憶服務部署（既有程式）

> PP 現行文件路線是 Google Drive；本頁的 SharePoint／Graph 步驟只供舊版選配參考，PP 安裝不要執行。僅部署記憶／待辦時，不設定 DEPT_DRIVE_ID 與 DEPT_SHARED_ROOT_ID。Google 登入及 Google Drive 文件 API 尚未實作。

這份給 Elio 或公司 IT 的 AI 執行。兩人的電腦只要做 START_HERE；不要把資料庫密碼或 Entra 應用程式密碼發給 Wilson、Avril。

套件包含可執行程式，但還沒有連入你們的公司或部署到主機。以下是真實資料與授權的設定步驟，不是已完成紀錄。先使用全新測試專案與虛構文件，驗收後再納入公司資料。

## 先準備這張表

可把 `config/team.example.json` 複製成 `config/team.json` 保存非機密的部署資料；後者已排除 Git。這張表是交接參考，不會自動建立資源，也不是服務讀取的設定來源。服務讀取下面列出的環境變數。

| 項目 | 從哪裡取得 |
| --- | --- |
| 專案代號 | 管理者指定，例如 `product-a`，兩人一致 |
| SharePoint 共享資料夾網址 | 公司文件庫建立好後取得，授權兩人的公司帳號 |
| 公司 tenant ID | Entra 公司目錄 ID，固定 UUID |
| 應用程式 client ID | 本服務新建的 Entra 應用程式 ID |
| Wilson／Avril object ID | 各自在公司目錄的物件 ID；不是郵件地址、Claude 帳號或自行填的姓名 |
| drive ID／root item ID | Microsoft Graph 中的文件庫 ID 與共享根資料夾 ID |
| HTTPS 服務網址 | 公司核准的雲端主機與網域，根網址不含 `/mcp` |
| Neon 管理者與應用程式連線 | 全新部門資料庫的兩個角色；密碼不填進這張表 |

不要拿 Elio 個人的 Neon 專案或既有公司資料庫代替空白測試資料庫。建立、遷移及授權前，向擁有者確認實際目標。

## 1. SharePoint 與兩人的資料夾

建立一個共享區，只授權兩人的公司 Microsoft 帳號。兩人各自用 OneDrive「新增捷徑至 OneDrive」或「同步」，確認本機共享區真的存在後才執行安裝器。不要同時設定兩種方法同步同一批內容。

安裝器不操作 OneDrive 登入、不驗證租戶授權，也不會自動搬移現有文件。雙向驗收檔必須在兩台真實電腦執行，不能在一台電腦換名字就宣稱通過。

## 2. Entra 登入設定

Entra 是公司的 Microsoft 身分管理系統；OAuth 是使用者登入並授權工具的流程。本服務使用 FastMCP 現成的 AzureProvider，不自行保存使用者密碼。

在 Microsoft Entra → App registrations 建立新的單一公司應用程式：

1. 名稱 `Department Agent`，帳號類型選單一租戶。
2. Web redirect URI 設成「實際 HTTPS 根網址 + `/auth/callback`」。與 `DEPT_BASE_URL` 完全一致。
3. Expose an API：Application ID URI 使用 `api://` 加 client ID；建立 `mcp-access` scope，管理者同意。scope 是明確命名的存取許可。
4. Manifest 的 `api.requestedAccessTokenVersion` 設為 `2`。
5. 建立 client secret，立即由管理者存到環境變數／部署平台的秘密管理區；設定到期提醒。不要貼到 AI 聊天。
6. 將應用程式限制給指定成員；資料庫的 members 名單仍是每次工具操作的授權依據。
7. 需要文件讀取時，在 API permissions 加 Microsoft Graph **Delegated** `Files.Read.All`，取得公司管理者同意。不要加 Application 權限，也不要加寄信權限。

第一版的 `Files.Read.All` 授權範圍較大：代表程式可代表登入者讀取其有權限的檔案。本服務另強制限定設定的文件庫與共享根目錄，並拒絕外部捷徑；這是程式層限制，不等於租戶授權本身只有一個資料夾。若公司要求授權本身也限制單一站台，需另外驗證 Selected permissions，不能把它當成這版已完成的功能。

不需要讀文件的初次試跑，可暫時不設 `DEPT_DRIVE_ID`、`DEPT_SHARED_ROOT_ID`，也不用同意 Graph 權限。此時服務提供 5 個記憶／待辦工具及一個明示 NOT_CONFIGURED 的文件查詢工具；手機不能讀文件。

## 3. 新的 Neon 資料庫與角色

建立新部門專案或獨立的新資料庫。正式試行前設定備份與還原；不要讓兩人的 AI 使用 Neon 管理 MCP 當日常資料入口。

建立資料庫擁有者與另一個一般登入角色，例如 `department_agent_app`。應用程式角色不能是 schema／資料庫擁有者、管理者或具有建立角色／資料庫權限。

在管理者電腦的 repo 根目錄準備隔離 Python 環境：

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock
```

Windows 對應為 `py -3 -m venv .venv` 及 `.venv\Scripts\python.exe`。依賴只供管理者的服務與測試；兩人的本機資料夾安裝器只用 Python 標準函式庫。

依既有金鑰規則，管理者在自己的 `~/.zshrc` 設定 `DEPT_ADMIN_DATABASE_URL`、`DEPT_PROJECT_ID` 等環境變數並載入。API key、密碼、連線字串不要存 `.env`、JSON、Git 或聊天。Windows 使用管理者核准的環境／秘密管理方式，不把 macOS 檔案照搬過去。雲端使用平台注入環境變數，不把整份個人 shell 設定上傳。

下面以專案代號 `product-a` 示範；先換成核准的實際代號。這些命令會寫入資料庫，必須先確認連線指向全新部門測試資料庫。

```sh
.venv/bin/python scripts/admin_db.py init --confirm-project product-a
.venv/bin/python scripts/admin_db.py grant --confirm-project product-a --app-role department_agent_app
```

`init` 發現 `department_agent` schema 已存在就拒絕，不會刪除重建。`grant` 只授予應用程式操作資料、讀成員及新增稽核事件的權限；不授予更改成員、刪事件或建表權限。

再以真實的 Entra object ID 分別執行 `add-member`。下列尖括號是必須替換的說明，不是有效 ID：

```sh
.venv/bin/python scripts/admin_db.py add-member --confirm-project product-a --name Wilson --oid "<Wilson 的 object ID>"
.venv/bin/python scripts/admin_db.py add-member --confirm-project product-a --name Avril --oid "<Avril 的 object ID>"
```

應用程式執行時只注入 `DEPT_DATABASE_URL`，使用上述受限角色。不要把 `DEPT_ADMIN_DATABASE_URL` 注入正式容器。

## 4. 部署設定

| 環境變數 | 內容 |
| --- | --- |
| `DEPT_DATABASE_URL` | 受限角色的 Neon 連線，包含 `sslmode=require` 或 `verify-full` |
| `DEPT_TENANT_ID`、`DEPT_CLIENT_ID` | 公司與新應用程式的 UUID |
| `DEPT_CLIENT_SECRET` | Entra 應用程式秘密 |
| `DEPT_BASE_URL` | 實際 HTTPS 根網址，不帶 `/mcp`、帳密或查詢參數 |
| `DEPT_PROJECT_ID` | 同一專案代號 |
| `DEPT_JWT_SIGNING_KEY` | 至少 32 個字元的隨機簽章秘密；用來驗證服務簽發的登入憑證 |
| `DEPT_STORAGE_ENCRYPTION_KEY` | Fernet 格式的隨機加密金鑰；用來加密登入狀態 |
| `DEPT_AUTH_STORAGE_PATH` | 私有且持久的儲存目錄；Docker 預設 `/data/auth` |
| `DEPT_DRIVE_ID`、`DEPT_SHARED_ROOT_ID` | 文件庫與共享根目錄 ID，兩個一起設定或一起省略 |
| `DEPT_PUBLIC_HOST` | 使用附帶 Caddy 部署時的網域名稱，不含協定或路徑 |

隨機秘密由管理者在秘密管理器或本機可信工具產生並私下保存；不要請 AI 顯示秘密。JWT 簽章與加密金鑰要跨重啟保留，不能每次隨機重生。

可用任何支援 Docker、HTTPS 和持久磁碟的公司核准主機。附帶 `compose.yaml` 提供單一服務與 Caddy；Caddy 是替服務處理 HTTPS 的入口程式。`DEPT_PUBLIC_HOST` 的網域必須已指向主機，80／443 可供 HTTPS 憑證驗證。記憶服務的 8000 不直接對外公開。

在主機設定好環境變數後：

```sh
docker compose --env-file /dev/null up -d --build
```

這是 Linux／macOS 主機命令；`--env-file /dev/null` 避免偷偷載入 `.env`。若用雲端平台部署，改由平台設定環境變數、HTTPS 與持久磁碟，不需要執行 Compose。

第一版限制 **單一服務副本**，加密登入狀態保存在持久磁碟；不可部署在每次請求都清空磁碟的環境。要多副本需改用共享的加密 token 儲存後再驗收。

啟動命令是 `python -m department_agent.server`。缺少必要變數會停止啟動。`/healthz` 只代表程序就緒，會明示 `external_acceptance=NOT_VERIFIED`，不代表 Neon、公司登入和兩台電腦已通過驗收。

## 5. 兩人的 Claude 接入

把實際根網址加 `/mcp` 交給兩人。Claude 網頁／桌面在 Connectors 新增自訂遠端連接器，各自登入自己的公司 Microsoft 帳號。私人 Claude 的訂閱身分與公司資料授權是兩件事。

Claude Code 可在本機安裝時提供 `--mcp-url`，安裝器會合併該工作區的 `.mcp.json`，不修改全域設定。開啟工作區後按 Claude 提示核准連接器並完成公司登入。若已由 claude.ai connector 繼承同一服務，避免重複配置兩個入口。

如果本機安裝時尚未有網址，安裝器會保存未設定狀態。之後不要用不同參數覆蓋原設定；依 START_HERE 選一個新的私有工作區，沿用同一共享位置與專案代號，帶上網址重新安裝，舊草稿保留原地。也可以先只在 Claude 網頁新增 connector。本版沒有自動升級既有本機設定命令。

## 6. 驗收、停用與限制

依 `docs/ACCEPTANCE.md` 在兩台電腦與兩個真實帳號驗收。沒有做完就不要標「全系統上線」。文件登記需先 `read_document` 取得原檔版本，再 `register_document` 保存同版本摘要。第一版讀取 UTF-8 文字、Markdown、CSV、DOCX、PPTX 的文字；PDF／XLSX／圖片只同步檔案，沒有全文讀取功能。

文件登記固定標為草稿。核准版本由負責人在 `40_已核准交付` 保存獨立版本，並用確認過的決策紀錄指向它；本版沒有自動審批／發布 API。不要把更新時間最新的草稿當已核准版。

讀取記憶／待辦預設各 50 筆、上限各 100 筆；第一版沒有全量歷史搜尋與分頁。重要交接應整理成近期的明確紀錄。文件目錄要手動登記，不會背景掃描所有文件；刪除與撤權的結果在下次文件工具讀取時確認。

停用成員：

```sh
.venv/bin/python scripts/admin_db.py revoke-member --confirm-project product-a --oid "<成員 object ID>"
```

新的工具操作會被拒絕；已在執行中的操作可能完成。另撤銷 SharePoint 分享與 Entra 應用程式存取。已下載的文件、個人 Claude 聊天或已保存摘要不能遠端收回。

## 官方參考（2026-10-27 查核）

- [FastMCP 的 AzureProvider 與 OBO](https://gofastmcp.com/integrations/azure)：OBO 是以登入者身分換取 Graph 存取憑證，不把資料庫密碼交給使用者。
- [Claude 遠端 MCP](https://support.claude.com/en/articles/11175166-get-started-with-custom-connectors-using-remote-mcp)。
- [Claude Code MCP 設定](https://code.claude.com/docs/en/mcp)。
- [Microsoft 文件同步](https://support.microsoft.com/en-us/sharepoint/sync/sync-sharepoint-and-teams-files-with-your-computer)。
- [Graph 以固定 ID 找檔](https://learn.microsoft.com/en-us/graph/onedrive-addressing-driveitems)。
