---
name: pp-onboarding
description: PP 團隊首次安裝後、新裝置或新成員加入時，逐步確認權限、Obsidian 安裝、Vault 設計、文件同步與第一筆記憶草稿。適用「帶我開始使用」「設定 Obsidian」「新人上手」；不把流程完成等同雲端服務已部署。
---
# PP 新人與新裝置上手

先讀 `.department-agent/WORKSPACE.md`、`.department-agent/config.json`、`.department-agent/reference/ONBOARDING.md` 及 `.department-agent/reference/TEAM_RULES.md`。

按照 ONBOARDING 分段執行，每次只處理目前能完成的一步，沿用已知答案。第一步先確認這台電腦是否裝了 Obsidian、有沒有既有 Vault；不讀私人筆記、不先重裝或搬移。無本機工具時請本人檢查，不能把找不到執行檔當作確定未安裝。

管理者已建立指定 Google Drive 資料夾，但交付時尚未分享。本人能開啟才繼續共享路徑步驟；其他本機準備可繼續。不要用假共享資料夾完成驗收。

帶本人在 Obsidian 打開共享資料夾、設定本裝置專用 config 名稱、練習一份提案 Markdown；明確說明本機私有區與共享 Vault 的差別。不得把機密或個人外掛憑證寫進同步的 Obsidian 設定。

依 `.department-agent/templates/ONBOARDING_REPORT.md` 另存本人私有 drafts/documents；逐項記錄實際證據、未做項目和阻擋。同步測試要雙方實作，雲端未接通就保持未接通。不得宣稱這裡的 AI 能遠端查看同事電腦。

若 member 不是目前支援的 Wilson／Avril，回報需要管理者擴充成員版本，不冒用現有名字安裝。
