# PP 團隊安裝入口

版本 **0.2.0**。適用 Wilson（Windows）與 Avril（Mac 為主、公司電腦為輔）。這一份就是兩人的共同入口；成員與實際路徑可不同，專案代號、共同規則、Skills 與記憶格式必須一致。

這是本機安裝與 Google Drive 文件驗收流程。不要因為下載完成、Skill 已出現或草稿通過格式檢查，就回報 Neon／手機 Claude 已接通。

## 給安裝 AI：先取得四個資料

使用者已提供的資料直接沿用，不重問：

1. 本人是 Wilson 還是 Avril。Avril 每台電腦都用 Avril，不把 Windows 電腦當成 Wilson。
2. 共同專案代號，例如 `pp-product`；由管理者確認，兩人相同。
3. 本人私有工作區的絕對路徑：專用新資料夾、在同步區與安裝包目錄之外。
4. Google Drive 共享專案在這台電腦的實際絕對路徑：須先存在，而且是管理者分享的同一雲端專案。

未提供正式部門 MCP 網址時留空。不要從其他個人設定找資料庫密碼、掃描私人聊天或推測帳號。PP Gmail 是 `itzpp7744@gmail.com`，不代表 AI 已獲登入或讀取其內容的權限。

## 1. 準備 Google Drive

先讀 [Google Drive 設定](team-assets/reference/GOOGLE_DRIVE_SETUP.md)。管理者分享專案給兩人各自核准的 Google 帳號，由本人完成登入。Windows 用檔案總管，Mac 用 Finder 找到該共享資料夾；不要照抄他人的磁碟路徑。

若兩人尚未有資料夾存取權，先完成本機工具準備並列出缺少的分享權限，不建立假共享目錄。Google 原生 Docs／Slides 項目不保證有可直接讀取的本機全文。

## 2. 預覽與安裝

在本檔所在的完整安裝包目錄執行。需要 Python 3.11 或以上；不需要安裝伺服器套件。以下路徑和專案名稱只是示例，AI 必須換成剛確認的實際值。

Wilson／Windows PowerShell：

```powershell
py -3 --version
py -3 scripts/setup_workspace.py plan --member Wilson --project pp-product --private-root "C:\PP-Agent\pp-product" --shared-root "G:\我的雲端硬碟\PP 團隊專案"
py -3 scripts/setup_workspace.py install --member Wilson --project pp-product --private-root "C:\PP-Agent\pp-product" --shared-root "G:\我的雲端硬碟\PP 團隊專案"
py -3 scripts/setup_workspace.py doctor --private-root "C:\PP-Agent\pp-product"
```

Avril／macOS：

```sh
python3 --version
python3 scripts/setup_workspace.py plan --member Avril --project pp-product --private-root "/Users/YOUR_NAME/PP-Agent/pp-product" --shared-root "/實際的GoogleDrive位置/PP 團隊專案"
python3 scripts/setup_workspace.py install --member Avril --project pp-product --private-root "/Users/YOUR_NAME/PP-Agent/pp-product" --shared-root "/實際的GoogleDrive位置/PP 團隊專案"
python3 scripts/setup_workspace.py doctor --private-root "/Users/YOUR_NAME/PP-Agent/pp-product"
```

先讀 plan 結果，確認範圍再 install。相同版本／成員／路徑可重跑；同名 Skill、受管檔案或共同專案標記內容不同會拒絕覆寫。已有個人 `CLAUDE.md`／`AGENTS.md` 保留，AI 仍須依輸出的 additional_instruction 讀 `.department-agent/WORKSPACE.md`。

安裝器不修改全域 Skills，不建立跨電腦符號連結。套件的 `.agent/skills` 是發布來源，每台安裝到自己的專案 `.claude/skills`，並比對內容，避免 Windows 建連結權限差異。修改團隊 Skill 應回到套件發新版，不各自在本機改到不同。

若使用舊版 0.1.x 工作區，選新私有位置；保留原草稿與個人規則，不把整份設定搬過來。若共享區有不同版本的 `PP_TEAM_STANDARD.json`，由管理者處理版本遷移，不刪標記或關閉檢查。

## 3. 在正確的工作區開 Claude Code

安裝完成後，把 Claude Code 的工作目錄切到剛建立的**私有工作區**，讀 `.department-agent/WORKSPACE.md`。確認以下 6 個專案 Skills 可見，必要時重新開啟該工作區：

| 指令 | 用途 |
| --- | --- |
| `/pp-start-work` | 開工、接續工作、確認資料位置與可用記憶來源 |
| `/pp-memory-handoff` | 將決策／交接／待辦整理成統一草稿，接通服務後才送出 |
| `/pp-pm-documents` | 依團隊範本起草需求、會議紀錄、簡報需求 |
| `/pp-onboarding` | 初次使用／新裝置：先檢查 Obsidian、設計 Vault、逐項教學驗收 |
| `/pp-team-improvement` | 向管理者提功能需求，或提交自己做好的技能供團隊審閱發布 |
| `/pp-sync-check` | 檢查本機設定、共同版本與雙向文件到達 |

每個 Skill 的 SKILL.md 和相依資料都在工作區內。既有個人規則不會被覆蓋；若它與團隊規則衝突，AI 應指出再處理。手機／網頁 Claude 不會因本機安裝而自動取得這些 Skills 或本機檔案。

## 4. 安裝後接著 onboarding

管理者已建立 [PP 團隊專案](https://drive.google.com/drive/folders/1_OrdKAQBzqSQt9EIaKza9SwzA4GvZ2-J)，交付時尚未分享給 Wilson／Avril。本人確認權限後再繼續，不以資料夾同名判定為同一專案。

不要在安裝成功就結束。執行 `/pp-onboarding`，依 `.department-agent/reference/ONBOARDING.md` 先確認是否裝了 Obsidian、是否有現有個人 Vault，再帶本人設定團隊 Vault、裝置專用設定、練習一份 Markdown 並完成驗收紀錄。本人未安裝時從官方來源協助安裝；保留原筆記，不先搬移。

需要新功能或想分享自己做的 Skill 時，執行 `/pp-team-improvement`，讀 TEAM_EVOLUTION：提案→審閱→發布→每台更新。不用 Drive 同步直接覆寫同事的已安裝技能。新增同仁前須由管理者擴充目前只允許 Wilson／Avril 的成員版本。

## 5. 驗證統一記憶格式

在私有工作區 `.department-agent/templates` 找 `NOTE_PAYLOAD.json` 或 `TASK_PAYLOAD.json`，另存到私有 `drafts`，換成一筆不敏感的測試內容。讀 `.department-agent/reference/MEMORY_FORMAT.md`，使用安裝好的 memory_draft.py 建立並檢查草稿。

預期得到一個 `drafts/memory/<request_id>.json`，狀態仍為未送出。兩人使用相同 `pp-memory/1` 格式；工具從各自設定填入成員與專案，不接受把別人的標籤當成登入身分。

## 6. 雙向交換測試檔

回安裝包目錄，Wilson 執行：

```powershell
py -3 scripts/setup_workspace.py probe-create --private-root "本人私有完整路徑"
```

本人將回傳的 `probe_id`、`sha256` 告訴 Avril。不要人工複製測試檔。Avril 等 Google Drive 顯示同步完成，再執行：

```sh
python3 scripts/setup_workspace.py probe-verify --private-root "/本人私有完整路徑" --probe-id "收到的識別碼" --sha256 "收到的檔案指紋"
```

反向也做一次。Avril 的備用電腦也與 Wilson 做雙向驗收；同一人的兩台電腦不冒充另一位成員。依 [驗收表](docs/ACCEPTANCE.md) 記錄結果。VERIFIED 只表示指定檔案到達且內容一致；程式的 sync_status 保持 UNVERIFIED，因為它無法證明實際傳輸方式。

## 7. 管理者日後接通雲端

管理者從 [ADMIN_SETUP](docs/ADMIN_SETUP.md) 開始。Google Drive 文件同步不需要 Neon 金鑰。現有記憶服務仍使用 Microsoft 公司登入，Google 文件雲端讀取尚未實作。

只有管理者提供正式網址、本人完成授權與服務驗收後，才使用遠端共用記憶。第一次安裝就有網址，可在 plan、install 都加 `--mcp-url "正式 HTTPS 網址"`；已用空網址安裝時，另選新私有根目錄安裝並保留舊草稿，不手改受管 config。網址不是密鑰，不能含帳密或查詢參數。

## 安裝 AI 最後要回報

成員、專案、套件版本、兩個實際路徑；6 個 Skills 的讀取結果；記憶草稿驗證結果；雙向檔案結果；雲端是否接通及缺少什麼。不能用程式測試通過代替真實裝置／登入／同步驗收。
