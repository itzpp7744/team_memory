---
name: pp-sync-check
description: 驗證 PP 工作區版本、Google Drive 雙向檔案到達與本機設定，處理「對方看不到文件」「這台有沒有同步」「安裝驗收」。不代替雲端記憶登入與資料庫測試。
---
# PP 同步驗收

讀 `.department-agent/WORKSPACE.md` 與 `.department-agent/reference/GOOGLE_DRIVE_SETUP.md`。使用安裝套件中的 `scripts/setup_workspace.py`（位置在 WORKSPACE 中），從套件目錄執行；Windows 用 `py -3`、Mac 用 `python3`。

1. 跑 `doctor --private-root "本人完整路徑"`。修改過的受管檔、錯誤專案或版本不一致，保留錯誤並停下，不刪除標記重裝。
2. 確認 Google Drive 電腦版已登入正確授權帳號，且 shared_root 是指定共享資料夾。它是實際雲端同步位置，不是為通過檢查而建立的空資料夾。
3. 本人跑 `probe-create --private-root ...`，請本人交給另一位成員輸出的 probe_id 與 sha256；不要代發訊息或手動搬測試檔。
4. 另一位等 Google Drive 顯示同步完成，跑 `probe-verify --private-root ... --probe-id ... --sha256 ...`；再反向重做。
5. 記錄兩端版本、裝置、時間、專案、指紋與 Google Drive 狀態。`peer_file_status: VERIFIED` 只證明指定檔案到達且相同；`sync_status` 保留 UNVERIFIED 是工具無法辨識傳輸方式，不能改輸出來美化結果。

同一人的第二台電腦仍用同一 member；雙向成員測試與另一位同事做，不改成員冒充。若 Drive 路徑被符號連結防護拒絕，回報實際路徑及錯誤，不擅自關閉防護。文件測試與記憶驗收分開：Google／Neon 服務已部署，Claude／Claude Code 仍須依 ONBOARDING 驗證同一 id／版本的雙向讀寫；未完成就標未驗證。Drive 尚未分享不應阻擋先連記憶，也不能把檔案同步成功當成記憶成功。
