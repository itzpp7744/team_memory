---
name: pp-onboarding
description: PP 團隊首次安裝後、新裝置或新成員加入時，先取得本人姓名與 Google email、核准並連接 Claude／Claude Code 共用記憶，再完成文件同步與 Obsidian。適用「帶我開始使用」「設定 Obsidian」「新人上手」；不把流程完成等同雲端服務已部署。
---
# PP 新人與新裝置上手

先讀 `.department-agent/WORKSPACE.md`、`.department-agent/config.json`、`.department-agent/reference/ONBOARDING.md` 及 `.department-agent/reference/TEAM_RULES.md`。

按照 ONBOARDING 分段執行，每次只處理目前能完成的一步，沿用已知答案。第一步確認本人姓名／唯一稱呼與個人工作 Google email，由管理者加入服務 allowlist（核准名單）；Google 應用程式若為外部 Testing，另需測試使用者資格。先完成 Claude Code 本人帳號登入，確認信任本人選定的專用私有工作區並允許專案 MCP，再用 Google 登入 department-agent；Claude 網頁自訂 connector 連同一正式網址，專案為 pp-product。依 ONBOARDING 做 Claude 寫→Code 讀相同 id／version、Code 改→Claude 讀 version + 1。沒有成功回傳就保持未驗證；這是使用者同意共享的結構化筆記，不是所有聊天自動同步。

若 Claude Code 的允許只對當次有效，或外部 `claude mcp login department-agent` 仍回 `awaiting approval`，留在同一次已允許的對話，輸入 `/mcp` → `department-agent` → `Authenticate`，由本人登入 Google。顯示 `Connected` 後在原對話測 `read_context`，不叫本人反覆重開、不刪設定、不擴大成全域所有伺服器。

網頁依 ONBOARDING 已實測的 Add custom connector 流程，填 PP 共用記憶與正式網址，選 Sign in now 和 Use Claude’s published identity（CIMD）；不填 header 或 client secret。按 Add 是本人確認新資料權限的步驟，未完成不得宣稱網頁連線或雙端驗收通過。

Google／Neon 是優先路線，成員不用 Neon 管理用 MCP 或資料庫密碼；Neon Free 有配額與休眠。管理者已建立指定 Google Drive 資料夾，各成員權限須確認。本人能開啟才繼續共享路徑步驟；Drive 或 Obsidian 未完成不能阻擋記憶驗收。完整安裝沿用已連記憶的私有根目錄，plan／install 都傳正式 --mcp-url；已有正確 .mcp.json 保留，衝突不擅改。不要用假共享資料夾完成驗收。

文件可用後，先確認 Obsidian 是否安裝、有沒有原個人 Vault；保留原筆記，不掃描、搬移或先重裝。帶本人在 Obsidian 打開共享資料夾、設定本裝置專用 config 名稱、練習一份提案 Markdown；明確說明本機私有區與共享 Vault 的差別。不得把機密或個人外掛憑證寫進同步的 Obsidian 設定。

依 `.department-agent/templates/ONBOARDING_REPORT.md` 另存本人私有 drafts/documents；逐項記錄實際證據、未做項目和阻擋。同步測試要雙方實作，雲端未接通就保持未接通。不得宣稱這裡的 AI 能遠端查看同事電腦。

首次安裝前詢問本人姓名／唯一團隊稱呼，不能讓新人冒用 Wilson 或 Avril。同名者由本人選擇附加區別；同一人所有裝置沿用完全相同稱呼。取得稱呼不等於取得 Drive／GitHub／雲端記憶權限。已安裝就沿用 config.member；變更稱呼需保留舊工作區並協調，不能手改設定。
