---
name: pp-team-improvement
description: PP 成員想請管理者新增功能／Skill，或想把自己做好的功能／Skill分享給團隊及未來新人時，整理需求、變更提案與驗收資料。適用「幫我提功能需求」「把我的 Skill 給同事用」「更新團隊安裝包」；不擅自改他人環境或直接發布未審版本。
---
# PP 團隊改進與分享

先讀 `.department-agent/reference/TEAM_EVOLUTION.md`、`.department-agent/reference/TEAM_RULES.md`、`.department-agent/config.json`。確認是「希望管理者開發」還是「已有作品要分享」，沿用使用者已說的答案。

從 `.department-agent/templates/TEAM_CHANGE_REQUEST.md` 起草，寫入本人 drafts/documents。已有作品時，使用者指定的檔案才可讀取；保留個人原稿，在安裝套件之外的獨立測試資料夾準備候選版本。不得直接修改受管 `.claude/skills` 或同事技能，也不能複製整個私人 Skills／Obsidian Vault。

Drive 分享權限與 Google／Neon 記憶登入分開管理。文件尚未分享時，提案留私有工作區，已授權的記憶讀寫可繼續；不把同事的 Google email 或管理者憑證寫進候選套件。

準備輸入輸出範例、相依軟體、所需權限、測試結果、回復方式與檔案清單。使用者要求分享時，僅把已檢查不含秘密的候選檔和提案放到本人共享 `80_修改提案/<member>`。這會經 Drive 分享可讀檔案，但不會自動變成同事已啟用的 Skill。

建立 GitHub Issue（需求單）、Pull Request（變更審查單）或發布版本，必須有對應使用者授權與帳號權限；沒有時保留可交接草稿。只有管理者核准版本並完成 TEAM_EVOLUTION 發布流程後，才引導同事更新。共同版本標記不可由成員自行刪改。

交付時分開列出「已起草」「已分享檔案」「已提交 GitHub」「已發布」「各裝置已更新」；沒有實際回應不可打勾。
