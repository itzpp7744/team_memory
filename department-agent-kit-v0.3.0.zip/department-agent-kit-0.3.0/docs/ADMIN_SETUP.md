# PP 管理者設定入口

0.3.0 優先使用 Google 登入＋Neon 共用記憶。2026-10-28 真人驗收已通過：服務已部署，Google 登入、Claude Code／網頁 Claude 連線與雙端交換已驗證；同一筆記憶由 Code 新增版本 1、網頁更正成版本 2，再由 Code 讀回。每位新成員仍需完成自己的登入與驗收。

## 新成員先開通記憶

1. 取得新人的姓名／唯一團隊稱呼、本人要用的個人工作 Google email；不預設人名，也不要求共用 Google 密碼。
2. 在服務 allowlist（核准成員名單）加入該帳號。若 Google OAuth 應用程式仍為外部 Testing，另把帳號加入 Google 測試使用者名單。OAuth 是本人向 Google 登入並同意授權的流程；有其中一份名單不等於另一份也完成。
3. 提供同一安裝包、專案 `pp-product`、MCP 名稱 `department-agent` 及下列正式網址。由成員依 [START_HERE](../START_HERE.md) 在自己的私有工作區登入，並在 Claude 網頁自訂 connector 使用同一服務。
4. 依 [驗收清單](ACCEPTANCE.md) 完成 Claude 寫→Code 讀同一 `id`／版本，再由 Code 更正→Claude 讀回 `version + 1`。沒有成功回傳就保持未驗證。

```text
https://br-sweet-water-a19q69sy-ppmemory.compute.c-1.ap-southeast-1.aws.neon.tech/mcp
```

Google 只要求 `openid`、`profile`、`email` 基本身分範圍；不讀 Gmail 或 Drive。成員不需要 Neon 管理用 MCP、資料庫密碼或管理者憑證。服務設定與管理指令見 [Neon 服務說明](../neon-service/README.md)，秘密由管理者透過環境提供，不放套件、聊天或設定檔。

共用記憶只保存使用者同意共享的結構化筆記，不是所有聊天自動同步。Neon Free 有配額、休眠及喚醒等待；維持 0 預算不代表有持續可用保證。遇到額度限制先回報管理者，不自行升級或啟用付費服務。

## 文件和 Obsidian 可以後補

管理者已建立 [PP 團隊專案](https://drive.google.com/drive/folders/1_OrdKAQBzqSQt9EIaKza9SwzA4GvZ2-J)，各成員分享權限仍須逐一確認。請分享給各自獲准的 Google 帳號，不開放公開連結；GitHub 私人 repo 讀取權限也分別授予。PP Gmail `itzpp7744@gmail.com` 是團隊聯絡／管理帳號，不代表所有人都該使用同一帳號。

按 [Drive 指南](../team-assets/reference/GOOGLE_DRIVE_SETUP.md) 設定實際共享路徑，再做完整 plan→install→doctor；兩個安裝指令都傳正式 `--mcp-url`，私有根目錄沿用先前的 MCP 工作區。Drive 未分享或 Obsidian 未安裝時，記憶登入與讀寫驗收照常進行。

`PP_TEAM_STANDARD.json` 記錄專案與套件版本；衝突時檢查專案、套件或受管檔案差異，不刪標記讓安裝通過。文件同步、Obsidian 與手機使用要分別驗收。

## 保留 Microsoft 替代路線

既有 Python／Microsoft Entra 服務仍保留，供另有公司身分需求的部署使用，見 [Microsoft 部署說明](MICROSOFT_SERVICE_SETUP.md)。它不是目前新人的 Google 登入路線。

`DEPT_DRIVE_ID`／`DEPT_SHARED_ROOT_ID` 與 Microsoft Graph 權限只屬於原 SharePoint 文件功能，不能填 Google Drive ID。Google 文件 API 仍未實作。

## 升級與撤權

舊版完整工作區保留原草稿與個人設定。0.3.0 使用新私有位置，先連記憶，再以同一位置完整安裝；不支援原地自動升級。若共享區已有不同版本標記，由管理者安排新共享位置或審閱過的遷移，不讓成員手改版本欄位。

移除成員時停用服務資格，並分別處理 Google 測試名單、Drive 分享及 GitHub 權限。撤權後要驗證新請求被拒絕；已下載的文件與已進入私人聊天的內容無法靠雲端撤權收回。
