# 交付前驗證

## 0.3.0 真人連線與保存驗收（2026-10-28）

本次 Claude Code 與網頁 Claude 的真人連線及雙端交換驗收通過（PASS）。以下是同一筆測試記憶的實際結果，不代表所有成員或裝置都已驗收：

| 項目 | 實際結果 |
| --- | --- |
| Claude Code 官方帳號登入 | 成功，使用既有 Pro 訂閱 |
| PP Google 登入 | 本人完成授權，department-agent 顯示 Connected |
| Claude Code 讀取 | `read_context(limit: 5)` 回傳專案 `pp-product`、`notes: []`、`tasks: []`、`source: pp_memory`；這是寫入測試筆記前的結果 |
| Claude Code 寫入 | `save_note` 成功回傳 `id: ea1641a4-9db6-4838-a051-63a2e13b55f7`、`version: 1`；標題為 `PP跨介面驗收2026-10-28 E57A` |
| 相同請求重試 | 同一 request_id 重送 save_note，回傳同一 id 與 version 1，未建立重複紀錄 |
| 過期／錯誤版本更正 | correct_note 使用 expected_version 999，被拒絕並提示目前版本為 1、須重新讀取比較；資料未被更改 |
| Neon 保存 | 管理者使用受限 runtime SQL（服務執行角色的資料庫查詢）只讀上述 id，確認紀錄存在，project 為 pp-product、kind 為 note、status 為 pending |
| Claude 網頁連接器 | 本人完成授權，連接器已 Connected，實際讀寫成功 |
| Code 寫 → 網頁讀 | 網頁讀到 Code 新增的同一筆 `ea1641a4-9db6-4838-a051-63a2e13b55f7`，version 為 1 |
| 網頁更正 | 網頁呼叫 correct_note，使用 expected_version 1，成功回傳同一 id、version 2 |
| 網頁改 → Code 讀 | Code 重新呼叫 read_context，實際工具回應為同一 id、version 2，並讀到下列更正內容；已直接檢視 CLI 詳細工具回應 |
| 雙端交換結果 | PASS：Code v1 → 網頁讀 v1／更新 v2 → Code 讀 v2；不是以畫面顯示 Connected 或本機模擬代替 |

版本 2 的實際內容：

> 測試資料：Claude Code 已寫入，網頁 Claude 已讀取並更新；等待 Claude Code 讀回版本 2。這不是產品決策。

內容中的「等待」是網頁更正當下留下的文字；後續 Code 已實際讀回版本 2。手機、Windows、Drive 分享／同步與 Obsidian 仍未實測，GitHub 發布版本以 repo 根目錄 manifest.json 為準。

Claude Code 版本為 2.1.220。工作區未明確信任時，Use this MCP 可能僅對當次對話生效；即使 settings.local 記錄 enabledMcpjsonServers，外部 `claude mcp login` 仍回 awaiting approval。本次以同一對話的 `/mcp` → `department-agent` → `Authenticate` 完成登入並讀寫成功。這不是要放寬全域權限；新人應只確認本人選定的專用資料夾信任範圍。

網頁設定路徑與 CIMD 選項記在 START_HERE；本次已完成授權與實際工具讀寫，按 Add 前的畫面本身不能當成已連線。上述資料庫查詢只屬管理者驗收，新人成員不需要 SQL、管理用 Neon MCP 或資料庫密碼。測試筆記保留 pending，沒有寫入私人 email、憑證或完整聊天。

## 0.3.0 新人入口更新（2026-10-27）

- 本次重跑 installer 39 項、memory_draft 18 項，共 57 項全部通過，沒有跳過；包含六個 Skills 安裝內容一致、既有 MCP 保留、衝突拒絕及草稿格式。
- 變更限新版入口、相關規則與 Skills、版本，以及安裝器產生的說明文字；沒有修改安裝行為。
- Google／Neon 服務已部署；本節的本機測試不驗證雲端部署。此日尚未驗收真人 Google 登入、Claude／Claude Code 同一筆記憶雙向讀寫、手機及 Drive／Obsidian 實機；2026-10-28 的進展見上方紀錄。
- 以下保留 0.2.1 的歷史測試紀錄；其中「尚未實作」描述的是當時狀態，現況以 START_HERE、ADMIN_SETUP 及 ACCEPTANCE 為準。

## 0.2.1 歷史紀錄

版本：0.2.1。日期：2026-10-27。

這份紀錄證明安裝套件通過程式檢查；不代表公司正式環境已接通。

| 項目 | 結果 |
| --- | --- |
| 完整測試 | macOS、Python 3.13.2；90 項通過，沒有跳過 |
| 本機安裝器 | 39 項：重跑、兩人成套安裝、版本／專案不符拒絕、保留個人設定、拒絕連結路徑、檔案校驗 |
| 記憶草稿 | 18 項：欄位、成員、專案、日期、UUID、重複欄位、空白正規化與格式定義一致性 |
| 管理者工具 | 3 項：任意有效顯示姓名、公司 UUID 必填、非法姓名拒絕；模擬連線，不連正式資料庫 |
| 設定與資料規則 | 12 項：設定驗證與既有服務的資料規則 |
| 文件讀取 | 6 項：既有 Microsoft 文件功能的限制與內容檢查；不代表 Google 文件 API 已實作 |
| MCP 服務 | 5 項：登入要求、工具清單、重試與讀取紀錄 |
| Postgres 整合 | 7 項：獨立本機 PostgreSQL 16、虛構資料、私有連線；未連現有 Neon |
| Python 相容性 | 39 項安裝器測試在 Python 3.11 與 3.13 通過；18 項草稿測試在 Python 3.13 通過 |
| 雙人模擬 | Wilson／Avril／中文姓名新人成員各自安裝，建立並檢查共 6 筆草稿、6 個 Skills，加入新人共同標記不變，雙向測試檔驗證；同一台機器的暫存資料夾，不代表真實 Drive 同步 |
| Skills | 6 個 SKILL.md 通過格式驗證；安裝後的相依檔案均在私有工作區內 |

不需要外部套件即可重跑本機工具測試：

```sh
python3 -m unittest discover -s tests -p test_setup_workspace.py -v
python3 -m unittest discover -s tests -p test_memory_draft.py -v
```

完整測試需安裝 requirements.lock，並把 TEST_DATABASE_URL 環境變數指向可丟棄的專用測試資料庫。測試會建立及刪除自己的 department_agent schema（資料表群組），需要建立測試角色的權限；不可指向正式資料庫。

```sh
python3 -m unittest discover -s tests -v
```

沒有 TEST_DATABASE_URL 時，7 項資料庫測試會跳過，不能把這種結果稱為全部通過且無跳過。

## 尚未實際驗證

- Windows 實機，以及 Wilson／Avril 的 Claude Code 是否載入 Skills。
- 兩台電腦經 Google Drive 的真實雙向同步、分享權限與原生 Docs／Slides 內容讀取。
- GitHub Actions：目前 repo 提供 ZIP，需先將完整原始碼展開為 repo 檔案才能啟用包內工作流程。
- 真實 Neon、Microsoft 公司登入、Docker／主機部署、手機 Claude 連線。
- Google 雲端文件 API 與 Google 登入尚未實作；不得用現有 Microsoft 服務宣稱已支援。

請依 ADMIN_SETUP 與 ACCEPTANCE 完成正式驗收。所有測試身分與憑證都是虛構值，不可複製到正式設定。
