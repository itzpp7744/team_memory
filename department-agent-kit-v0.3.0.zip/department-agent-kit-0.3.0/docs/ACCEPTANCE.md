# PP 團隊驗收紀錄

每項記錄版本、裝置、成員、時間與實際結果。未操作就保留未驗證；服務已部署不等於真人登入和讀寫已通過。先做記憶，再補文件和 Obsidian；後兩者受阻不影響前者。

## 先驗收 Google／Neon 共用記憶

| 完成 | 情境 | 必須看到的證據 |
| --- | --- | --- |
| [ ] | 新人資料與核准 | 本人姓名／唯一稱呼、個人工作 Google email、管理者服務 allowlist 核准；若 Google 仍為外部 Testing，另有測試使用者資格 |
| [ ] | Claude Code 登入 | 在本人指定的私有工作區使用 department-agent 正式網址、project scope；本人先完成 Claude 訂閱登入、專用工作區信任與專案 MCP 允許；若只允許當次，於同一對話 /mcp → department-agent → Authenticate，完成 Google 授權並讀回 pp-product |
| [ ] | Claude 登入 | 自訂 connector 使用同一網址、Sign in now 與 Claude published identity（CIMD）；本人確認權限並按 Add、完成 Google 授權，服務專案為 pp-product |
| [ ] | Claude 寫→Code 讀 | 本人同意共享一筆帶獨特識別文字的測試筆記；Claude 保存回傳 id／version，Code 讀到相同 id、版本與內容 |
| [ ] | Code 改→Claude 讀 | Code 先讀目前版本再更正；Claude 讀到同一 id、更正內容及原 version + 1 |
| [ ] | 身分隔離 | 不同成員各自登入；未登入、未核准或已停用成員的請求被拒絕 |
| [ ] | 重試 | 相同 request_id 與內容重送不重複；同 ID 不同內容被拒絕 |
| [ ] | 同時修改 | 舊 expected_version 被拒絕，重新讀取、比較後才改 |
| [ ] | 撤權 | 已停用成員的新請求被拒絕；Drive、GitHub 權限另處理 |
| [ ] | 手機 | 實際手機客戶端使用同一服務讀到測試筆記；不能拿網頁成功代替 |

只要一端沒有實際成功回傳，就不能勾雙向驗收完成。筆記須清楚標為測試；不把測試資料當作正式工作決策。email、路徑等個人資料留必要的私有驗收紀錄，不貼公開 repo。

## 文件準備好，再驗完整工作區

| 完成 | 情境 | 必須看到的證據 |
| --- | --- | --- |
| [ ] | Windows 安裝 | plan→install→doctor；兩個安裝指令都有正式 --mcp-url，private-root 沿用已連記憶的位置，私有與共享根目錄分開 |
| [ ] | Mac 安裝 | 同版本、同 project_id、同共享標記；6 個 Skills 內容相同 |
| [ ] | 同人的新裝置 | 沿用本人稱呼，各自設定實際路徑，不複製另一台 config |
| [ ] | 設定保護 | 已有正確 .mcp.json 保留，其他 MCP／個人規則／舊草稿未覆寫；同名不同設定拒絕安裝 |
| [ ] | Skill 載入 | 在私有工作區可呼叫 6 個 pp-* 指令，引用的規則／範本存在 |
| [ ] | 記憶草稿 | 各自建 note／task 並 check 通過；本機仍回報 NOT_SENT，遠端成功另記 id／version |
| [ ] | 錯誤格式 | 假設標 confirmed、亂填日期、其他成員／專案草稿被拒絕 |
| [ ] | 版本保護 | 可丟棄測試工作區的 Skill 被改後 doctor 拒絕；不可刪共享標記繞過 |
| [ ] | 成員 A → B | probe 經 Drive 到達，ID 與 SHA-256 檔案指紋一致，兩端同步狀態有紀錄，未人工複製 |
| [ ] | 成員 B → A | 反向同樣成功；同一人的第二台電腦不冒充另一成員 |
| [ ] | PM 文件 | 初稿留私有 drafts/documents，經本人要求才新增提案，正式原稿保留 |
| [ ] | Google 原生文件 | 用實際授權工具或本人提供的匯出檔讀全文，不能只讀捷徑 |

Google 文件 API 尚未實作。程式單元測試、虛構資料與本機資料庫測試，不是上述外部驗收證據。

## Obsidian 與新人上手

各裝置填 ONBOARDING_REPORT，記錄 Obsidian 版本、正確團隊 Vault、原個人 Vault 保留、獨立設定資料夾及本人提案 Markdown 讀寫。每個方向同步 3 次，記錄大小和實際耗時，不承諾固定秒數。Drive 網址能開但沒有本機內容，不能勾檔案驗收通過。

新人使用任意有效姓名，AI 要先問本人稱呼與 Google email，不要求改版或冒用既有成員。自己的提案區建立後，既有資料保留、共同標記不因新增姓名改變。大小寫／Unicode 拼寫衝突必須拒絕，不能混入別人的資料夾。新增姓名不會取得雲端權限。

團隊新功能用 TEAM_CHANGE_REQUEST 提案；分享草稿、發布版本與各成員更新是不同狀態，逐項記錄。
