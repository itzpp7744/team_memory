# PP Google 登入與 Neon 共用記憶 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 讓經管理者核准的 Google 帳號透過 Claude／Claude Code 讀寫同一份 PP 記憶，維持 Neon Free，不啟用付費服務。

**Architecture:** 保留現有 Python 服務及安裝器，新增 `neon-service/` Node.js 24 部署版本。使用 Better Auth 的 Google 登入與 MCP OAuth，Neon Postgres 保存登入狀態、成員權限、記憶、重試紀錄及稽核資料；Neon Functions 提供 HTTPS。服務每次操作查核成員，安裝包不帶密鑰。

**Tech Stack:** Node.js 24、TypeScript、Better Auth 1.7.14、@better-auth/mcp 1.7.14、@better-auth/cimd 1.7.14、MCP SDK 2.4.0、pg 8.23.1、Neon Functions。

## 已確認範圍

- Neon organization `org-wild-mode-10463711`，project `dawn-credit-94264560`，production `br-sweet-water-a19q69sy`。
- Console 已確認 Free plan、Singapore（Functions 支援地區）；仍須 CLI 部門登入及方案驗證。
- 第一位測試成員為使用者本次提供的 Gmail，從部署環境或管理指令加入，不把私人信箱寫死進公開程式。
- 其餘成員在 onboarding 時提供各自的 Google 帳號，須經管理者核准。不得自由加入團隊。
- 只使用 Google openid/email/profile，不讀 Gmail 或 Drive。Drive 與 GitHub 權限分開管理。
- 不修改個人 Neon 專案，不啟用 AI Gateway、不升級方案、不綁付款。

## Task 1：可測試的 Node 共用記憶服務

**Files:** 新增 `neon-service/package.json`, `tsconfig.json`, `src/{config,auth,app,memory-store,memory-validation,index,local}.ts`, `scripts/{migrate,member}.ts`, `sql/001_memory.sql`, `test/*.test.ts`, `neon.ts`, `README.md`。只增補根目錄 `.gitignore` 的 Node 輸出忽略規則。

- [ ] 先寫並執行失敗測試，再實作。最低拒絕測試：無登入、未核准、已停用、Google email 未驗證、錯誤 token issuer/audience、錯誤版本、同一 request_id 不同內容、跨專案讀寫。
- [ ] 保留既有 `pp-memory/2` 工具介面：`read_context`, `save_note`, `create_task`, `update_task`, `correct_note`；參照 Python logic/store 的驗證與交易行為，source/status/assignee/due_date 不任意改名。
- [ ] 每次記憶讀寫都在交易內查核 active 成員。成員綁定經 Google 驗證的穩定 subject／Better Auth user ID，不信任工具參數中的 email 或 submitted_by。允許名單只由管理指令維護。
- [ ] 參數化 SQL、每專案隔離、版本樂觀鎖、request_id 重試去重、不可由 app 刪改的 audit。管理 DB 與 runtime DB 角色分開；遷移不在 HTTP startup 執行。
- [ ] Better Auth + JWT + MCP/CIMD 採正式套件 API；提供登入、同意畫面與 discovery。驗證 callback 目的地，保留 OAuth query；不關閉 CSRF、state、nonce、PKCE 或 audience 檢查。只用 Google 登入，不提供密碼／匿名捷徑。
- [ ] 不跨使用者共用具身分的 MCP server／transport。限制請求大小，錯誤訊息不洩漏 SQL、憑證或 token。
- [ ] 使用真實本機 Postgres 驗證成員停用、並發衝突、重試與 audit；HTTP 測試確認未授權回 401 並提供 discovery。

驗收指令：

```sh
cd neon-service
npm ci
npm run build
npm test
```

測試必須包含下列語意（依實際匯出 API 編寫，不以 mock 成功取代整合驗證）：

```ts
assert.equal((await app.fetch(new Request(`${base}/mcp`, {method: 'POST'}))).status, 401);
await assert.rejects(() => store.read_context(disabledMember));
assert.equal((await store.create(member, 'note', body, requestId)).id,
             (await store.create(member, 'note', body, requestId)).id);
await assert.rejects(() => store.update(member, id, 'note', staleVersion, changes, newId, reason));
```

## Task 2：獨立規格審查與品質審查

- [ ] 規格 reviewer 檢查 Task 1 所有要求、現有 pp-memory 相容性、無其他檔案被改寫。
- [ ] 修正後，再由品質 reviewer 檢查 Google 身分綁定、OAuth／MCP、併發 SQL、錯誤遮罩、部署 secrets 與最低權限。
- [ ] 通過後記錄實際 build／test 輸出，不以先前 Python 的 90 個測試代替新服務驗收。

## Task 3：免費雲端部署與真人驗收

- [ ] 使用 PP 專用 CLI profile；若目前憑證失敗，請使用者登入，不建立替代 project。
- [ ] 確認 Free plan 和 Singapore 後，只配置 Functions + Postgres。先讀取 schema 清單，選用全新 schema，不覆蓋既有資料。
- [ ] Google OAuth app 僅要求基本身分；需要真人登入、同意或建立 credential 時，在確定的頁面交接使用者，密鑰不貼聊天。
- [ ] 先完成本機測試與 deploy plan，再執行遷移及部署。DB runtime 使用限制角色，secret 僅透過環境送到 Functions，輸出遮罩。
- [ ] 對已部署 URL 測試 discovery、401、Google 真人登入、核准 Gmail 寫入／讀回、重試、版本衝突、停權；分別在 Claude 與 Claude Code 讀取同一筆測試記憶。
- [ ] 更新安裝說明與交付狀態，明確區分通過、未驗證與真人操作。只有全部必要情境通過才宣告服務完成。
