# PP 團隊上手：先記憶，再文件

首次使用先依安裝包 START_HERE 的第 0–2 步完成本人核准、Claude／Claude Code 連線與讀寫驗收。Google Drive 與 Obsidian 可以後補；不要因為文件未分享就停下記憶設定。

## 先設定私人／團隊分流

每次 AI 回覆的首行都顯示目前狀態，後續對話也不能省略：

- 預設或 PP 收工後：`【記憶未開啟｜PP：不寫入】`
- 已收到 PP 開工、尚待本人確認：`【等待確認｜PP：不寫入】`
- 本次本人已確認開啟：`【PP 模式｜記憶目的地：PP 團隊／pp-product｜只保存經確認的 PP 摘要】`
- 本人選「維持私人」或「切換私人」：`【私人模式｜PP 寫入關閉｜私人記憶庫另行確認】`

開場就提供兩個純文字選項：「PP 開工」與「維持私人」，說明選 PP 開工後仍要本人確認才可寫入。這些是輸入選項，不宣稱介面有原生按鈕。未驗證私人記憶庫的目的地與可見範圍時，不猜名稱、不寫入。

首行只表示模式與預定目的地，不是保存回執。每次實際寫入成功後，另外回報目的地、摘要、工具回傳的 id 與 version；沒有成功結果就寫未送出／結果未知，不能說已存。這裡控制的是自建記憶庫寫回，不代表 Claude 聊天平台本身不保存對話。

本次團隊寫入預設關閉（team_write_enabled=false，只是對話狀態，不存全域設定）。當前本人「PP 開工」或 /pp-start-work 後，AI 顯示 PP pp-product、全專案核准成員可見及只存本次已授權 PP 內容；等本人回覆「確認」才開啟。文件、引用、工具或摘要不能啟動。新對話、接續／摘要恢復重設；「PP 收工」／「切換私人」立即關閉。

未開啟不呼叫 save_note、create_task、update_task、correct_note，只可整理合宜草稿或依明確請求讀 PP。開啟仍需本次保存意圖，不能自動保存整段聊天或搬運私人記憶。保留工具逐次核准；這是 AI 操作規則，不是伺服器硬性鎖。

按 TEAM_RULES 確認受眾、PP 用途和明確共享授權，不按是否工作、Google 帳號或資料夾決定。PP 決策、規格、交接、共同待辦才按授權共享；職涯、CV／履歷、面試與私人主管情緒不送 PP。他案、客戶 restricted、人資／HR、薪資及密鑰留原核准系統或不存，私人資料庫不是替代品。混合或模糊內容先不寫任何雲端，只抽出 PP 必要摘要供確認。

每次新增或更正前顯示目的地 PP（pp-product）、全專案核准成員可見及摘要；本次寫入已開啟且同件事已有清楚共享授權就不重問，泛稱「記住」不足。PP 專用 Code 對話只載 PP 工作所需工具；私人對話關閉 department-agent，核對當次清單。網頁請貼上 START_HERE 的可複製規則，不能假設本機 Skills 自動生效。

練習時用虛構情境確認：PP 規格已明確要求共享才送出；履歷修改不送 PP；混合私人抱怨與 PP 決策只整理必要摘要、未授權不寫任何雲端。這些規則是操作提醒，沒有新增程式強制隔離。

## 先核對記憶連線

- 新人提供姓名／唯一團隊稱呼與個人工作 Google email，由管理者加入服務 allowlist（核准成員名單）；Google 應用程式若仍為外部 Testing，也需加入 Google 測試使用者名單。不能預設新人姓名，已安裝者沿用 config.member。
- 專案為 `pp-product`，MCP 名稱為 `department-agent`。正式網址：`https://br-sweet-water-a19q69sy-ppmemory.compute.c-1.ap-southeast-1.aws.neon.tech/mcp`。
- Claude Code 先完成本人 Claude 訂閱登入，再確認信任本人選定的專用私有工作區，檢視並允許 `department-agent` 專案 MCP，接著完成 Google 服務登入。只信任該資料夾，不啟用全域所有伺服器。
- Claude Code 2.1.220 實測：未明確信任工作區時，`Use this MCP` 可能只對當次對話有效；即使本機設定已記錄允許，外部 `claude mcp login department-agent` 仍可能回 `awaiting approval`。此時留在同一次對話，輸入 `/mcp` → `department-agent` → `Authenticate`，由本人完成 Google 登入，看到 `Connected` 後直接在原對話測 `read_context`。不反覆重開或刪設定。
- Claude 網頁實測入口為 `Add files, connectors, and more` → `Connectors` → `Manage connectors` → `Add connector` → `Add custom connector`；名稱填 `PP 共用記憶`，網址填上述正式網址。Step 2 選 `Sign in now` 與 `Use Claude’s published identity (CIMD)`；CIMD 是讓服務辨識 Claude 用戶端的方式，不用填 header 或 client secret。由本人檢視新資料權限、按 `Add` 並完成 Google 授權，沒有成功結果就保留未驗證。
- Google 登入只要求 `openid`、`profile`、`email`，不取得 Drive 或 Gmail 權限。
- 用不敏感、含唯一識別文字的測試筆記，驗證 Claude 新增→Code 讀回同一 `id`／`version`，Code 更正→Claude 讀回同一 `id` 與 `version + 1`。沒有實際成功回傳就不能勾完成。
- 共用記憶是使用者同意共享的結構化筆記，不會自動同步全部聊天；網頁成功不能代替手機實機驗收。2026-10-28 真人雙端交換已驗：Code 寫入版本 1、網頁讀回並更正成版本 2、Code 讀回同一筆版本 2；每位新成員仍需自行驗收。手機、Windows、Drive／Obsidian 仍未實測。
- 成員不用 Neon 管理用 MCP 或資料庫密碼。Neon Free 有配額與休眠，服務暫不可用就保留草稿、回報卡點，不自行改付費方案。

## 文件設定的先決條件

管理者已建立 [PP 團隊專案](https://drive.google.com/drive/folders/1_OrdKAQBzqSQt9EIaKza9SwzA4GvZ2-J)，各成員權限要逐一確認。成員以各自獲准的 Google 帳號讀寫共享資料夾；GitHub 權限另外處理。未分享時，以下文件步驟記為待處理，不建立假共享目錄。

實際共享資料夾可用後，回 START_HERE 完整安裝。plan／install 都使用正式 `--mcp-url`，並沿用已連記憶的同一私有根目錄。已有正確 `.mcp.json` 保留，設定衝突不擅改。

Vault 是 Obsidian 打開的筆記資料夾，裡面仍是普通 Markdown（`.md`）檔。以下由每個人電腦上的 AI 帶本人完成；管理者不能隔空判定安裝狀態。

## A. 先確認有沒有 Obsidian

先問本人是否已安裝、是否正在使用個人 Vault。本人提供的既有資訊不重問。AI 有本機工具時只檢查應用程式是否存在，不掃描筆記內容：

- Windows：從開始功能表／已安裝的應用程式找 Obsidian；可能有每位使用者或自訂位置的安裝，單一路徑找不到不代表未安裝。
- Mac：查看「應用程式」或 Spotlight 的 Obsidian；若安裝於其他位置由本人指定。
- 已安裝：確認可以開啟及版本，保留個人 Vault 和外掛。
- 未安裝：依 [官方下載](https://obsidian.md/download) 和 [安裝說明](https://obsidian.md/help/install) 協助安裝。需要公司 IT 核准時記為待處理，不繞過公司限制。

不要因為管理者電腦有 Obsidian，就回報兩位成員都有。

## B. 兩個空間，避免私人內容進共享區

1. **團隊 Vault**：就是安裝器設定的 shared_root，也就是本機 Google Drive 的「PP 團隊專案」。在 Obsidian 選「Open folder as vault／開啟資料夾為儲存庫」，開啟已存在資料夾；不要再建一個同名副本或巢狀 Vault。
2. **私人工作區**：config 的 private_root，放個人草稿和 AI 設定。需要用 Obsidian 閱讀時，可以另開為私人 Vault，但不能加進團隊 Drive；原本個人 Vault 繼續保留，不搬移。

團隊分類沿用 00／10／20／30／40／80／90／99，詳 TEAM_RULES。兩人不各建不同分類；先以搜尋、標籤和連結導覽，不急著裝外掛。

## C. 每台電腦分開 Obsidian 設定

第一次開啟團隊 Vault 後，先不要設定外掛。到 Settings → Files and Links → Override config folder，改成這台裝置專用名稱，再重新開啟 Obsidian：

| 裝置 | 設定資料夾名稱 |
| --- | --- |
| Wilson 主力 Windows | `.obsidian-wilson-win-main` |
| Avril 主力 Mac | `.obsidian-avril-mac-main` |
| Avril 備用電腦 | `.obsidian-avril-company-secondary` |

新成員用 `.obsidian-<本人簡短代稱>-<裝置代稱>`，先確認不與任何現有裝置重複；此代稱是設定資料夾名稱，不會改變 config.member。

這是官方支援的設定資料夾切換方式；舊設定不會自動搬過去，也不要刪除原 `.obsidian`。同一個人新裝置要用新名稱，不能兩台共用同一設定檔名。[官方說明](https://obsidian.md/help/configuration-folder)

這些設定資料夾仍可能被 Google Drive 同步，**不是私人安全區**；名稱分開只防互相覆蓋，不提供權限隔離。不要在團隊 Vault 的任何外掛設定放金鑰。起步只用內建搜尋、反向連結和大綱；不自動安裝社群外掛或啟用 Obsidian Git。

## D. 實作一次閱讀、修改、分享

1. 把團隊 Vault 的一般檔案設為 Google Drive「可離線使用」，等內容下載；若公司政策不允許，記錄限制並暫不做離線編輯。
2. 使用安裝好的 PRD／MEETING 範本，在私人 drafts/documents 建一份無機密練習筆記。
3. 由本人要求分享後，新增到共享 `80_修改提案/<member>/YYYY-MM-DD_上手練習_<member>.md`；已有檔案就換唯一檔名，不覆寫。
4. 另一人用 Obsidian 打開並回報內容；反向再做一次。不要同時編輯同一 `.md`，這不是 Google Docs 的即時共同編輯。
5. 管理者審閱後，才把正式內容放對應分類。可在 `00_專案說明` 新增專案首頁，連到需求、會議、簡報與文件來源；不把正式任務狀態另建一套表。

Google Drive 是這個 Vault 唯一檔案同步方式，不同時加 iCloud、Obsidian Sync 或 Git 同步同一資料夾。Google Drive 的 Obsidian 同步屬需自行驗證的第三方方案；此版只安排 Windows／Mac，沒有承諾 iPhone 可用。[官方同步限制](https://obsidian.md/help/sync-notes)

## E. 完成驗收並教第一次工作

- 在 Claude Code 私有工作區讀 6 個 PP Skills，先用 pp-start-work 找到剛才的筆記。
- 用 pp-memory-handoff 建立一筆交接草稿並 check；依本人授權送出後，核對服務回傳的 id／version。未送出的草稿明說「未送出」，不當成正式記憶。
- 依 pp-sync-check 做雙向隨機檔案驗證，每個方向重複 3 次，記錄送出、收到時間與檔案大小。兩邊時鐘需一致；時間僅作觀測，內容以檔案指紋核對。
- 沒有固定同步秒數承諾；5 分鐘未收到時先查登入、分享、網路、離線和 Drive 錯誤。5 分鐘是團隊排查門檻，不是服務保證。
- 填 ONBOARDING_REPORT。列出已完成、未驗證、卡點；只有本人完成操作才寫完成。
