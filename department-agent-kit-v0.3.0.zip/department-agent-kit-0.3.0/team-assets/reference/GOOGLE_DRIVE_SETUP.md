# Google Drive 文件同步

PP 團隊 Gmail：`itzpp7744@gmail.com`。僅憑這個信箱，無法判定帳號的 Workspace 方案或共用雲端硬碟資格；本包不登入或檢查這個帳號。

管理者已建立 [PP 團隊專案](https://drive.google.com/drive/folders/1_OrdKAQBzqSQt9EIaKza9SwzA4GvZ2-J)，交付時尚未分享給兩人。以下分享步驟仍須完成。

## 管理者先準備

由管理者建立／指定一個 Google Drive 專案資料夾，記錄連結與共同專案代號，再分享給 Wilson、Avril 各自獲准使用的 Google 帳號。只有指定成員能存取，避免開放「知道連結的任何人」。這一步須由具權限者實際完成，本機安裝器不會替人分享或設定權限。

如果確認 Workspace 有共用雲端硬碟且管理者允許，優先用團隊持有的文件空間；否則使用 PP 帳號的共享資料夾。個人雲端硬碟的共享資料夾不等於團隊持有的共用雲端硬碟，檔案所有權仍須管理者另行核對。

兩人不用共用 PP 密碼。Claude 帳號負責使用 AI；個人 Google 帳號可用於記憶服務登入，但服務 allowlist 與 Drive 文件分享是兩份不同權限。記憶登入只要求基本身分，不會取得 Drive 或 Gmail 讀取權限。先依 START_HERE 連共用記憶，本頁的文件設定可以稍後完成。

## 每台電腦的步驟

1. 由本人從 [Google 官方安裝說明](https://support.google.com/drive/answer/10838124?hl=zh-Hant) 安裝 Google Drive 電腦版；公司若限制安裝，交由 IT 處理。已有程式就沿用。
2. 本人登入獲授權的 Google 帳號，確認能開啟管理者分享的同一專案。必要時從網頁「與我共用」對專案資料夾新增捷徑至「我的雲端硬碟」，再在電腦版找到它；[官方捷徑說明](https://support.google.com/drive/answer/2375057?hl=zh-Hant)。
3. 在檔案總管或 Finder 複製實際資料夾路徑。不要預設 Windows 的磁碟代號或 Mac 的 CloudStorage 路徑，也不要建立假的普通資料夾來通過安裝。
4. 確認目標可讀寫，Google Drive 同步狀態正常。對會離線使用的一般文件，依電腦版提供的選項準備離線可用；不把檔名可見視為內容已下載。
5. 回套件的 START_HERE 執行 plan、install、doctor，將實際路徑傳給 `--shared-root`。私有工作區與套件解壓位置都放在共享區之外。
6. 兩人按驗收說明互換測試檔，確認 Windows→Mac 及 Mac→Windows 兩個方向。第二台 Avril 電腦也沿用 Avril 成員身分，和 Wilson 互測。

安裝器拒絕共享根目錄及受管檔案中的符號連結／junction（指向另一個位置的檔案系統連結）。Google Drive 的捷徑在各作業系統上的呈現需實機驗證；被拒絕時保留錯誤並停止，不改程式關閉防護，也不複製一份文件冒充同步。

## 文件讀取與衝突

Google Docs／Sheets／Slides 在電腦版會開啟瀏覽器，不保證是可直接解析的本機內容。AI 需要已獲授權且可用的文件工具，或本人提供匯出檔；沒有時要明說未讀全文。

一般本機文件同步會有延遲。AI 修改先放本人成員的修改提案區，同一原稿錯開編輯；衝突時保留兩份並由負責人比較。Google 原生文件可使用網頁共同編輯與版本紀錄。同步不是備份，管理者仍需另訂備份／還原方式。

本包只整合 Drive 本機路徑、規則與同步驗收。沒有自動建立 Google Cloud 應用程式、Google Drive API 文件索引、手機 Claude 文件讀取或 Gmail 收發；也不把舊版 Microsoft 文件工具當成 Google 工具。
