# PP 上手驗收紀錄

- 成員／裝置：
- 日期／套件版本／共同專案：
- 私有路徑／共享路徑（留本機，不貼公開 repo）：

| 項目 | 狀態：完成／未驗證／受阻 | 證據或卡點 |
| --- | --- | --- |
| 本人姓名／稱呼與個人工作 Google email 已確認，服務 allowlist 已核准 | | |
| Google 外部 Testing 測試使用者已加入（非 Testing 可記不適用） | | |
| Claude Code 本人訂閱登入、專用工作區信任與 department-agent 允許；必要時同一對話 /mcp → Authenticate | | |
| Claude Code Connected 後實際讀回 pp-product；寫入成功的 id／version 另記 | | |
| Claude 自訂 connector 用同一網址、Sign in now／CIMD；本人確認權限按 Add 並完成 Google 授權 | | |
| Claude 寫→Code 讀：同一測試筆記 id、version、內容與 pp-product | | |
| Code 改→Claude 讀：同一 id、正確更正內容與 version + 1 | | |
| 手機實機讀取（獨立驗收） | 未驗證 | |
| 自己的 Google 帳號可讀寫指定資料夾（可稍後處理） | | |
| 私人 GitHub repo 可讀 | | |
| Google Drive 電腦版已登入且無錯誤 | | |
| Obsidian 已安裝並可開啟；記錄版本 | | |
| 原個人 Vault 保留；團隊 Vault 路徑正確 | | |
| 本裝置專用 Obsidian 設定資料夾 | | |
| 一般 Vault 檔案可離線使用 | | |
| doctor 與 6 個 Skills 可讀 | | |
| 自己提案區新增 Markdown 並由對方讀到 | | |
| 雙向同步各 3 次，記錄大小及耗時 | | |
| 記憶草稿 new／check 通過，仍未送出 | | |
| 完整安裝沿用同一 private-root，plan／install 均傳正式 --mcp-url，原 .mcp.json 保留 | | |

共用記憶只保存本人同意共享的結構化筆記，不會自動同步全部聊天。Drive／Obsidian 待處理不會使已完成的記憶驗收失效。

未完成事項與負責人：

下一次工作：使用 pp-start-work；要提需求或分享技能用 pp-team-improvement。
