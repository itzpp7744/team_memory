#!/usr/bin/env python3
"""Prepare separate private/shared workspaces. No network or provider API calls."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import secrets
import sys
import tempfile
import unicodedata
from urllib.parse import urlsplit
import uuid

REPOSITORY = Path(__file__).resolve().parents[1]
SHARED_DIRS = (
    '00_專案說明', '10_需求與研究', '20_會議紀錄', '30_簡報',
    '40_已核准交付', '80_修改提案',
    '90_封存', '99_同步驗收',
)
PRIVATE_DIRS = ('drafts', 'drafts/memory', 'drafts/documents', 'temp', '.department-agent')
KIT_VERSION = (REPOSITORY / 'VERSION').read_text(encoding='utf-8').strip()
SKILLS = ('pp-start-work', 'pp-memory-handoff', 'pp-pm-documents', 'pp-sync-check',
          'pp-onboarding', 'pp-team-improvement')
CONFIG_KEYS = {'version', 'member', 'project_id', 'private_root', 'shared_root', 'mcp_url'}
INSTRUCTION = '開始工作前，請讀取本私有工作區的 .department-agent/WORKSPACE.md，並遵守其中的資料範圍與交付規則。'


class WorkspaceError(ValueError):
    pass


def validate_member(value: str) -> str:
    """A portable local folder label, never an authenticated identity."""
    if (not isinstance(value, str) or not 1 <= len(value) <= 80
            or unicodedata.normalize('NFC', value) != value
            or not value[0].isalnum() or not value[-1].isalnum()
            or any(not (character.isalnum() or character in ' _-') for character in value)
            or re.fullmatch(r'(?:con|prn|aux|nul|com[1-9¹²³]|lpt[1-9¹²³])', value, re.IGNORECASE)):
        raise WorkspaceError('姓名須為 1–80 字的標準 Unicode 文字，首尾為字母或數字，中間只可加空白、底線或連字號；不可使用 Windows 保留名稱。請使用本人確認的完整姓名，不自動裁切空白或改寫。')
    return value


def same_member_label(left: str, right: str) -> bool:
    """Conservative portable comparison, including Windows uppercase aliases."""
    left = unicodedata.normalize('NFC', left)
    right = unicodedata.normalize('NFC', right)
    return left.casefold() == right.casefold() or left.upper() == right.upper()


def check_member_collision(proposals: Path, member: str) -> None:
    if not proposals.exists():
        return
    for existing in proposals.iterdir():
        # macOS can return canonically decomposed filenames. Normalize only for
        # filesystem comparison; user-entered labels remain exact NFC strings.
        name = unicodedata.normalize('NFC', existing.name)
        if same_member_label(name, member) and name != member:
            raise WorkspaceError('姓名與既有提案資料夾只有大小寫差異；拒絕寫入。若為同一人，請沿用完全相同姓名；若為不同人，請在姓名加上可區分文字。')


def within(path: Path, parent: Path) -> bool:
    return path == parent or parent in path.parents


def root_path(value: str) -> Path:
    if not isinstance(value, str) or not value or any(ord(c) < 32 for c in value):
        raise WorkspaceError('工作區路徑無效。')
    path = Path(value).expanduser()
    if not path.is_absolute():
        raise WorkspaceError('請提供絕對路徑。')
    # Inspect the spelling supplied by the user before resolve() erases aliases.
    for part in [*reversed(path.parents), path]:
        try:
            metadata = part.lstat()
        except FileNotFoundError:
            continue
        linked = part.is_symlink() or getattr(metadata, 'st_reparse_tag', 0) == 0xA0000003
        if linked:
            # macOS exposes these two OS-managed aliases; all user aliases fail.
            allowed = {'/var': '/private/var', '/tmp': '/private/tmp'}
            system_alias = (sys.platform == 'darwin' and str(part) in allowed
                            and part.is_symlink() and str(part.resolve()) == allowed[str(part)])
            if not system_alias:
                raise WorkspaceError(f'工作區根目錄或上層路徑不可包含符號連結／junction：{part}')
    path = path.resolve()
    if path == Path(path.anchor) or path == Path.home().resolve():
        raise WorkspaceError('不可使用磁碟根目錄或整個家目錄。請選擇專案專用資料夾。')
    if within(path, REPOSITORY) or within(REPOSITORY, path):
        raise WorkspaceError('工作區必須與工具儲存庫分開。')
    if path.exists() and not path.is_dir():
        raise WorkspaceError(f'工作區路徑不是資料夾：{path}')
    for ancestor in path.parents:
        if ancestor.exists() and not ancestor.is_dir():
            raise WorkspaceError(f'上層路徑不是資料夾：{ancestor}')
    return path


def validate_url(value: str | None) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or any(c.isspace() or ord(c) < 32 for c in value) or '\\' in value:
        raise WorkspaceError('MCP 網址不可含空白或反斜線。')
    try:
        url = urlsplit(value)
        host = (url.hostname or '').lower().rstrip('.')
        port = url.port
    except ValueError as exc:
        raise WorkspaceError('MCP 網址或連接埠無效。') from exc
    if url.scheme != 'https' or not host or url.username is not None or url.password is not None or '?' in value or '#' in value:
        raise WorkspaceError('MCP 必須使用 HTTPS，且不可含帳密、查詢參數或片段。')
    if port == 0 or host == 'localhost' or host.endswith('.localhost'):
        raise WorkspaceError('MCP 必須使用遠端網域，不可使用 localhost。')
    try:
        ipaddress.ip_address(host)
    except ValueError:
        pass
    else:
        raise WorkspaceError('MCP 網址不可使用 IP 位址。')
    if not re.fullmatch(r'[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?', host) or '.' not in host or not re.search(r'[a-z]', host.split('.')[-1]):
        raise WorkspaceError('MCP 網址必須使用有效的遠端網域。')
    for label in host.split('.'):
        if not label or len(label) > 63 or label.startswith('-') or label.endswith('-'):
            raise WorkspaceError('MCP 網域格式無效。')
    return value


def check_tree(path: Path) -> None:
    """Do not follow symlinks or Windows junctions in any owned subtree."""
    if path.is_symlink() or (hasattr(path, 'is_junction') and path.is_junction()):
        raise WorkspaceError(f'拒絕符號連結或 junction：{path}')
    try:
        metadata = path.lstat()
    except FileNotFoundError:
        return
    # Path.is_junction was added in Python 3.12. Inspect the Windows mount-point
    # reparse tag directly as well, so Python 3.11 rejects junctions too.
    if getattr(metadata, 'st_reparse_tag', 0) == 0xA0000003:
        raise WorkspaceError(f'拒絕 Windows junction：{path}')
    if path.exists() and path.is_dir():
        for child in path.iterdir():
            check_tree(child)


def check_directory(path: Path) -> None:
    check_tree(path)
    if path.exists() and not path.is_dir():
        raise WorkspaceError(f'預定資料夾已被檔案占用：{path}')


def read_bytes(path: Path) -> bytes:
    check_tree(path)
    if not path.is_file():
        raise WorkspaceError(f'找不到一般檔案：{path}')
    if path.stat().st_size > 1024 * 1024:
        raise WorkspaceError(f'設定或驗收檔超過 1 MiB：{path}')
    return path.read_bytes()


def read_json(path: Path) -> dict:
    try:
        data = json.loads(read_bytes(path).decode('utf-8'))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise WorkspaceError(f'不是有效的 UTF-8 JSON：{path}') from exc
    if not isinstance(data, dict):
        raise WorkspaceError(f'JSON 最外層必須是物件：{path}')
    return data


def encoded(data: dict) -> bytes:
    return (json.dumps(data, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def release_assets() -> dict[str, bytes]:
    """An explicit allowlist: never copy user data or global AI configuration."""
    sources = {
        f'.claude/skills/{name}/SKILL.md': REPOSITORY / f'.agent/skills/{name}/SKILL.md'
        for name in SKILLS
    }
    reference = REPOSITORY / 'team-assets/reference'
    check_tree(reference)
    for name in ('TEAM_RULES.md', 'MEMORY_FORMAT.md', 'GOOGLE_DRIVE_SETUP.md',
                 'ONBOARDING.md', 'TEAM_EVOLUTION.md'):
        sources[f'.department-agent/reference/{name}'] = reference / name
    sources['.department-agent/memory-draft.schema.json'] = REPOSITORY / 'team-assets/memory-draft.schema.json'
    templates = REPOSITORY / 'templates'
    check_tree(templates)
    for source in sorted(templates.iterdir()):
        if source.is_file() and source.suffix in ('.md', '.json'):
            sources[f'.department-agent/templates/{source.name}'] = source
    sources['.department-agent/tools/memory_draft.py'] = REPOSITORY / 'scripts/memory_draft.py'
    sources['.department-agent/tools/logic.py'] = REPOSITORY / 'department_agent/logic.py'
    return {name: read_bytes(source) for name, source in sources.items()}


def standard_bytes(project: str, assets: dict[str, bytes]) -> bytes:
    fingerprints = {name: hashlib.sha256(data).hexdigest() for name, data in sorted(assets.items())}
    digest = hashlib.sha256(json.dumps(fingerprints, sort_keys=True, separators=(',', ':')).encode('utf-8')).hexdigest()
    return encoded(dict(project_id=project, kit_version=KIT_VERSION,
                        memory_schema='pp-memory/2', assets_sha256=digest))


def workspace_text(config: dict) -> bytes:
    return f'''# 私有工作區規則

成員：{config['member']}
專案：{config['project_id']}
私有根目錄：{config['private_root']}
共享根目錄：{config['shared_root']}
安裝套件根目錄（installer_root）：{REPOSITORY}

- 草稿、暫存與尚未確認的內容留在私有根目錄的 drafts／temp。
- 開始工作必讀 .department-agent/reference/TEAM_RULES.md；記憶格式依 .department-agent/reference/MEMORY_FORMAT.md 與 memory-draft.schema.json。
- 本機專案 Skills 在 .claude/skills/，包含 pp-start-work、pp-memory-handoff、pp-pm-documents、pp-sync-check、pp-onboarding、pp-team-improvement。Claude Code 可載入專案 Skills；其他 AI 客戶端須明確讀取對應 SKILL.md，不假設已自動載入。
- 首次安裝後執行 .claude/skills/pp-onboarding/SKILL.md，依 .department-agent/reference/ONBOARDING.md 先確認 Google 核准與 Claude／Claude Code 共用記憶讀寫，再補 Google Drive 和 Obsidian 團隊 Vault（共用筆記資料夾）；文件未分享不阻擋記憶驗收。安裝器不會自動安裝 Obsidian，也不會替本人登入或授權；本機 READY 不代表雲端服務已部署或真人登入與雙向讀寫已通過。
- 新需求、自建 Skill 或團隊規則的改動，執行 .claude/skills/pp-team-improvement/SKILL.md，依 .department-agent/reference/TEAM_EVOLUTION.md 提出、審閱與發布；本機提案不代表團隊已採用，不直接修改受管 Skill 或正式共用規則。
- 文件範本在 .department-agent/templates；文件草稿放 drafts/documents。記憶與待辦先用 .department-agent/tools/memory_draft.py 建立 drafts/memory 內的 pp-memory/2 JSON，狀態永遠是 NOT_SENT，不代表已寫入雲端。
- 本機 member／submitted_by 只是檔案標籤，不是身分驗證。不得依這個標籤授予雲端權限。
- 每台裝置沿用本人完全相同的姓名與大小寫；不同人同名時，請先加上可區分文字，避免共用同一份提案資料夾。
- 安裝器留在原工具儲存庫；plan、install、doctor 與同步 probe 仍使用該處 scripts/setup_workspace.py。
- 要給同事審閱的 AI 修改提案，只能寫入共享根目錄的 80_修改提案/{config['member']}。
- 不得覆寫已核准的原稿、同事的提案或 40_已核准交付；正式交付由負責人審閱後移入。
- 不把金鑰、密碼、憑證、私有設定或個人歷史對話放入共享資料夾或上傳雲端。
- 本機檔案可讀寫，只代表本機正常。Google Drive 是否同步、另一位成員是否收到，必須另做雙向驗收。
- MCP 是 AI 連接外部工具的介面；設定了網址不等於登入成功或雲端可用。必須在使用者自己的 AI 客戶端登入並驗收。
- 同步驗收檔僅證明指定檔案出現在對方位置；不能證明一定經過 Google Drive，也不能證明雲端 AI 已接通。
- WORKSPACE.md 與 config.json 由安裝器管理；設定不同時不要自行覆寫，改用新的私有工作區。
'''.encode('utf-8')


def prepare(member: str, project: str, private_value: str, shared_value: str, mcp_url: str | None) -> dict:
    validate_member(member)
    if not isinstance(project, str) or not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', project) or len(project) > 80:
        raise WorkspaceError('專案代號須為小寫英數與連字號，最多 80 字元。')
    private, shared = root_path(private_value), root_path(shared_value)
    if within(private, shared) or within(shared, private):
        raise WorkspaceError('私有與共享根目錄不可相同，也不可互相包含。')
    if not shared.is_dir():
        raise WorkspaceError('共享根目錄必須先存在，請選擇自己已同步的 Google Drive 專案資料夾。')
    config = dict(version=2, member=member, project_id=project, private_root=str(private), shared_root=str(shared), mcp_url=validate_url(mcp_url))
    dirs = [private / name for name in PRIVATE_DIRS] + [shared / name for name in SHARED_DIRS]
    dirs.append(shared / '80_修改提案' / member)
    # Check proposal parent too: traversing it first would otherwise hide a link.
    for path in [shared / '80_修改提案'] + dirs:
        check_directory(path)
    check_member_collision(shared / '80_修改提案', member)
    config_path = private / '.department-agent' / 'config.json'
    workspace_path = private / '.department-agent' / 'WORKSPACE.md'
    files = {config_path: encoded(config), workspace_path: workspace_text(config)}
    check_tree(config_path)
    existing_install = config_path.exists()
    if existing_install and read_json(config_path) != config:
        raise WorkspaceError('既有設定或版本與本次不同；拒絕升級覆寫，請保留原資料並改用新的私有工作區。')
    assets = release_assets()
    for name in SKILLS:
        skill_root = private / '.claude/skills' / name
        check_tree(skill_root)
        if not existing_install and skill_root.exists():
            raise WorkspaceError(f'既有同名 Skill 不能被接管：{name}。請使用新的私有工作區。')
        if skill_root.exists():
            allowed = {skill_root / 'SKILL.md'}
            if any(path not in allowed for path in skill_root.rglob('*')):
                raise WorkspaceError(f'受管 Skill 含非發行版內容：{name}。')
    for relative, data in assets.items():
        files[private / relative] = data
    files[shared / '00_專案說明/PP_TEAM_STANDARD.json'] = standard_bytes(project, assets)
    # Include every generated parent before writes, including the .claude path.
    for file_path in files:
        for parent in reversed(file_path.parents):
            if parent not in (private, shared) and (within(parent, private) or within(parent, shared)) and parent not in dirs:
                dirs.append(parent)
    for path in dirs:
        check_directory(path)
    for path, expected in files.items():
        check_tree(path)
        if path.exists():
            if path == config_path:
                if read_json(path) != config:
                    raise WorkspaceError('既有設定與本次不同；拒絕覆寫，請改用新的私有工作區。')
            elif read_bytes(path) != expected:
                raise WorkspaceError(f'受管檔案或 PP 專案標準不同；拒絕覆寫：{path}')
    preserved = []
    for name in ('AGENTS.md', 'CLAUDE.md'):
        path = private / name
        check_tree(path)
        if path.exists():
            if not path.is_file():
                raise WorkspaceError(f'{name} 已被資料夾占用。')
            preserved.append(name)
        else:
            files[path] = (INSTRUCTION + '\n').encode('utf-8')
    mcp_path = private / '.mcp.json'
    check_tree(mcp_path)
    mcp_before = None
    mcp_after = None
    if mcp_path.exists() and not mcp_path.is_file():
        raise WorkspaceError('.mcp.json 已被資料夾占用。')
    if mcp_url is not None:
        mcp_before = read_bytes(mcp_path) if mcp_path.exists() else None
        data = read_json(mcp_path) if mcp_before is not None else {}
        servers = data.setdefault('mcpServers', {})
        if not isinstance(servers, dict):
            raise WorkspaceError('既有 mcpServers 不是物件，拒絕修改。')
        expected = {'type': 'http', 'url': mcp_url}
        if 'department-agent' in servers and servers['department-agent'] != expected:
            raise WorkspaceError('既有 department-agent MCP 名稱衝突，拒絕覆寫。')
        if 'department-agent' not in servers:
            servers['department-agent'] = expected
            mcp_after = encoded(data)
    managed_files = set(files) - {private / 'AGENTS.md', private / 'CLAUDE.md'}
    return dict(config=config, dirs=dirs, files=files, managed_files=managed_files, preserved=preserved, mcp_path=mcp_path, mcp_before=mcp_before, mcp_after=mcp_after)


def status(prepared: dict, action: str) -> dict:
    config = prepared['config']
    return dict(
        action=action,
        local_status='PLANNED' if action == 'plan' else 'READY',
        sync_status='UNVERIFIED',
        cloud_status='UNVERIFIED' if config['mcp_url'] else 'NOT_CONFIGURED',
        private_root=config['private_root'], shared_root=config['shared_root'],
        planned_directories=[str(path) for path in prepared['dirs'] if not path.exists()],
        planned_files=[str(path) for path in prepared['files'] if not path.exists()] + ([str(prepared['mcp_path'])] if prepared['mcp_after'] is not None else []),
        member=config['member'], project_id=config['project_id'],
        preserved_instruction_files=prepared['preserved'], additional_instruction=INSTRUCTION,
        remaining=['雙方仍須完成兩個方向的檔案驗收，並確認 Google Drive 用戶端同步狀態。',
                   '仍須在 AI 客戶端完成 MCP 登入、專案權限與讀寫驗收。' if config['mcp_url'] else '尚未設定雲端 MCP 網址；雲端連線未完成。'],
        note='本工具只準備本機資料夾與設定，不會登入、上傳個人歷史或呼叫外部服務。',
    )


def exclusive_write(path: Path, data: bytes) -> None:
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    descriptor = os.open(path, flags, 0o600)
    with os.fdopen(descriptor, 'wb') as stream:
        stream.write(data)


def install(prepared: dict) -> dict:
    # A saved plan can be stale. Repeat full validation before the first mutation.
    desired = prepared['config']
    prepared = prepare(desired['member'], desired['project_id'], desired['private_root'],
                       desired['shared_root'], desired['mcp_url'])
    for directory in prepared['dirs']:
        directory.mkdir(parents=True, exist_ok=True)
    for path, data in prepared['files'].items():
        check_tree(path)
        if not path.exists():
            try:
                exclusive_write(path, data)
            except FileExistsError:
                # Another installer may have won the create. Never assume its
                # contents match ours merely because the file now exists.
                pass
        if path in prepared['managed_files']:
            matches = (read_json(path) == desired if path.name == 'config.json'
                       else read_bytes(path) == data)
            if not matches:
                raise WorkspaceError(f'受管檔案在安裝時出現不同內容；拒絕回報完成：{path}')
        else:
            check_tree(path)
            if not path.is_file():
                raise WorkspaceError(f'指示檔已被其他路徑占用：{path}')
            if read_bytes(path) != data and path.name not in prepared['preserved']:
                prepared['preserved'].append(path.name)
    if prepared['mcp_after'] is not None:
        path = prepared['mcp_path']
        before = prepared['mcp_before']
        if before is None:
            exclusive_write(path, prepared['mcp_after'])
        else:
            if read_bytes(path) != before:
                raise WorkspaceError('MCP 設定在檢查後已變更；停止，請重新執行。')
            descriptor, temporary = tempfile.mkstemp(prefix='.mcp-merge-', dir=path.parent)
            try:
                with os.fdopen(descriptor, 'wb') as stream:
                    stream.write(prepared['mcp_after'])
                os.replace(temporary, path)
            finally:
                if os.path.exists(temporary):
                    os.unlink(temporary)
    actual = inspect_workspace(desired['private_root'])
    if actual['config'] != desired:
        raise WorkspaceError('安裝後讀回的設定與要求不同；拒絕回報 READY。')
    return status(prepared, 'install')


def inspect_workspace(private_value: str, error_context: dict | None = None) -> dict:
    private = root_path(private_value)
    check_tree(private / '.department-agent')
    config = read_json(private / '.department-agent' / 'config.json')
    if error_context is not None:
        error_context['cloud_status'] = 'UNVERIFIED' if config.get('mcp_url') else 'NOT_CONFIGURED'
    if set(config) != CONFIG_KEYS or type(config.get('version')) is not int or config.get('version') != 2:
        raise WorkspaceError('設定欄位或版本不符；請保留原資料並建立新的私有工作區。')
    if config['private_root'] != str(private):
        raise WorkspaceError('設定的私有根目錄與目前位置不符。')
    prepared = prepare(config['member'], config['project_id'], config['private_root'], config['shared_root'], config['mcp_url'])
    for directory in prepared['dirs']:
        if not directory.is_dir():
            raise WorkspaceError(f'缺少資料夾：{directory}')
    for path in prepared['files']:
        if not path.is_file():
            raise WorkspaceError(f'缺少檔案：{path}')
    if prepared['mcp_after'] is not None:
        raise WorkspaceError('尚未建立符合設定的 MCP 項目。')
    return prepared


def create_probe(prepared: dict) -> dict:
    config = prepared['config']
    probe_id = str(uuid.uuid4())
    data = dict(version=1, probe_id=probe_id, member=config['member'], project_id=config['project_id'], nonce=secrets.token_hex(32), created_at=datetime.now(timezone.utc).isoformat())
    contents = encoded(data)
    path = Path(config['shared_root']) / '99_同步驗收' / (probe_id + '.json')
    exclusive_write(path, contents)
    result = status(prepared, 'probe-create')
    result.update(probe_id=probe_id, sha256=hashlib.sha256(contents).hexdigest(), probe_path=str(path), note='請將 probe_id 與 sha256 告訴另一位成員，請對方在自己的共享位置執行 probe-verify。')
    return result


def verify_probe(prepared: dict, probe_id: str, digest: str) -> dict:
    try:
        valid_id = str(uuid.UUID(probe_id))
    except ValueError as exc:
        raise WorkspaceError('驗收檔 ID 必須是 UUID。') from exc
    if valid_id != probe_id or not re.fullmatch(r'[0-9a-fA-F]{64}', digest):
        raise WorkspaceError('驗收檔 ID 或 SHA-256 格式無效。')
    config = prepared['config']
    path = Path(config['shared_root']) / '99_同步驗收' / (probe_id + '.json')
    contents = read_bytes(path)
    if not secrets.compare_digest(hashlib.sha256(contents).hexdigest(), digest.lower()):
        raise WorkspaceError('SHA-256 不符：檔案內容與發送方不同。')
    try:
        data = json.loads(contents.decode('utf-8'))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise WorkspaceError('驗收檔不是有效的 UTF-8 JSON。') from exc
    if not isinstance(data, dict):
        raise WorkspaceError('驗收檔最外層必須是 JSON 物件。')
    if data.get('version') != 1 or data.get('probe_id') != probe_id or data.get('project_id') != config['project_id']:
        raise WorkspaceError('驗收檔格式、ID 或專案不符。')
    sender = validate_member(data.get('member'))
    if same_member_label(sender, config['member']):
        raise WorkspaceError('必須驗證另一位成員建立的檔案，不能驗證自己的檔案。')
    if not isinstance(data.get('nonce'), str) or not re.fullmatch(r'[0-9a-f]{64}', data['nonce']):
        raise WorkspaceError('驗收檔缺少有效隨機識別碼。')
    result = status(prepared, 'probe-verify')
    result.update(probe_id=probe_id, peer_file_status='VERIFIED', sender=data['member'], note='指定的另一位成員檔案已出現在此位置，內容雜湊一致。這無法證明 Google Drive 傳輸、雙向同步或雲端 AI 連線。')
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description='部門 AI 工作區：本機安裝與雙人檔案驗收（不連外）')
    commands = parser.add_subparsers(dest='command', required=True)
    for command in ('plan', 'install', 'doctor', 'probe-create', 'probe-verify'):
        sub = commands.add_parser(command)
        sub.add_argument('--private-root', required=True)
        if command in ('plan', 'install'):
            sub.add_argument('--member', required=True, help='本人確認的姓名；跨裝置沿用相同拼寫與大小寫')
            sub.add_argument('--project', required=True)
            sub.add_argument('--shared-root', required=True)
            sub.add_argument('--mcp-url')
        elif command == 'probe-verify':
            sub.add_argument('--probe-id', required=True)
            sub.add_argument('--sha256', required=True)
    args = parser.parse_args()
    error_context = {'cloud_status': 'UNVERIFIED' if getattr(args, 'mcp_url', None) else 'NOT_CONFIGURED'}
    try:
        if sys.version_info < (3, 11):
            raise WorkspaceError('需要 Python 3.11 或更新版本。')
        if args.command in ('plan', 'install'):
            prepared = prepare(args.member, args.project, args.private_root, args.shared_root, args.mcp_url)
            result = status(prepared, 'plan') if args.command == 'plan' else install(prepared)
        else:
            prepared = inspect_workspace(args.private_root, error_context)
            if args.command == 'doctor':
                result = status(prepared, 'doctor')
            elif args.command == 'probe-create':
                result = create_probe(prepared)
            else:
                result = verify_probe(prepared, args.probe_id, args.sha256)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (WorkspaceError, OSError, ValueError, TypeError, RecursionError) as exc:
        print(json.dumps(dict(status='ERROR', message=str(exc), sync_status='UNVERIFIED', cloud_status=error_context['cloud_status']), ensure_ascii=False, indent=2))
        return 2


if __name__ == '__main__':
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    raise SystemExit(main())
