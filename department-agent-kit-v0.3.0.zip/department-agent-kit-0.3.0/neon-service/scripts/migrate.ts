import { readFile } from "node:fs/promises";
import { pathToFileURL } from "node:url";
import pg, { type Pool } from "pg";
import { getMigrations } from "better-auth/db/migration";
import { authOptions } from "../src/auth.ts";
import { loadConfig, type Config } from "../src/config.ts";
import { MemoryStore } from "../src/memory-store.ts";
export async function migrate(admin: Pool, config: Config): Promise<void> {
  const existing = await admin.query(
    "SELECT nspname FROM pg_namespace WHERE nspname=ANY($1::text[])",
    [["pp_memory", "pp_auth"]],
  );
  if (existing.rowCount)
    throw new Error(
      "pp_memory 或 pp_auth 已存在；停止以保護既有資料，請先檢查遷移狀態",
    );
  await admin.query(
    await readFile(new URL("../sql/001_memory.sql", import.meta.url), "utf8"),
  );
  const plan = await getMigrations(
    authOptions(config, admin, new MemoryStore(admin, config.projectId)),
  );
  await plan.runMigrations();
  await admin.query(`
  REVOKE ALL ON SCHEMA pp_auth FROM PUBLIC;
  GRANT USAGE ON SCHEMA pp_auth TO pp_auth_runtime,pp_memory_runtime;
  GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA pp_auth TO pp_auth_runtime;
  GRANT USAGE ON ALL SEQUENCES IN SCHEMA pp_auth TO pp_auth_runtime;
  GRANT SELECT(id,email,"emailVerified") ON pp_auth."user" TO pp_memory_runtime;
  GRANT SELECT("userId","providerId") ON pp_auth.account TO pp_memory_runtime;
 `);
}
if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(process.argv[1]).href
) {
  const dsn = process.env.PP_ADMIN_DATABASE_URL;
  if (!dsn) throw new Error("缺少 PP_ADMIN_DATABASE_URL");
  const admin = new pg.Pool({ connectionString: dsn, max: 1 });
  try {
    await migrate(admin, loadConfig());
    console.log(
      "PP 記憶及登入資料表初始化完成。接著建立受限登入角色並加入成員。",
    );
  } catch {
    console.error(
      "初始化失敗，請檢查權限及 schema 是否已存在；不要刪除既有資料重試。",
    );
    process.exitCode = 1;
  } finally {
    await admin.end();
  }
}
