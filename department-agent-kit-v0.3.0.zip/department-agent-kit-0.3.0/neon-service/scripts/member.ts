import { randomUUID } from "node:crypto";
import { parseArgs } from "node:util";
import { pathToFileURL } from "node:url";
import pg, { type Pool } from "pg";
import { text, InputError } from "../src/memory-validation.ts";
export async function setMember(
  admin: Pool,
  input: { email: string; name: string; project: string; active: boolean },
): Promise<string> {
  const email = text(input.email, "信箱", 320).toLowerCase(),
    name = text(input.name, "名稱", 200),
    project = text(input.project, "專案", 100);
  if (
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ||
    !/^[-_a-zA-Z0-9]+$/.test(project) ||
    typeof input.active !== "boolean"
  )
    throw new InputError("成員資料格式錯誤");
  const client = await admin.connect();
  try {
    await client.query("BEGIN");
    const row = (
      await client.query(
        "INSERT INTO pp_memory.members(id,email,display_name,active) VALUES($1,$2,$3,$4) ON CONFLICT(email) DO UPDATE SET display_name=EXCLUDED.display_name,active=EXCLUDED.active RETURNING id",
        [randomUUID(), email, name, input.active],
      )
    ).rows[0];
    await client.query(
      "INSERT INTO pp_memory.project_members(project_id,member_id) VALUES($1,$2) ON CONFLICT DO NOTHING",
      [project, row.id],
    );
    await client.query("COMMIT");
    return row.id;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}
if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(process.argv[1]).href
) {
  const { values } = parseArgs({
    options: {
      email: { type: "string" },
      name: { type: "string" },
      project: { type: "string" },
      disable: { type: "boolean", default: false },
    },
  });
  if (!values.email || !values.name || !values.project)
    throw new Error(
      "使用 --email 信箱 --name 名稱 --project 專案；停用加 --disable",
    );
  const dsn = process.env.PP_ADMIN_DATABASE_URL;
  if (!dsn) throw new Error("缺少 PP_ADMIN_DATABASE_URL");
  const pool = new pg.Pool({ connectionString: dsn, max: 1 });
  try {
    const id = await setMember(pool, {
      email: values.email,
      name: values.name,
      project: values.project,
      active: !values.disable,
    });
    console.log(JSON.stringify({ id, active: !values.disable }));
  } catch {
    console.error("成員設定失敗，請檢查管理角色權限與輸入。");
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
}
