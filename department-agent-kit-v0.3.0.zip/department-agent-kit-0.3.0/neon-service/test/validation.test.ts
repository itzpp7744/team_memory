import test from "node:test";
import assert from "node:assert/strict";
import {
  validateNote,
  validateTask,
  applyChange,
  requestDigest,
  safeReturnURL,
} from "../src/memory-validation.ts";
test("note keeps pp-memory/2 fields and prohibits confirmed hypotheses", () => {
  assert.deepEqual(
    validateNote({
      title: " 決策 ",
      content: "內容",
      category: "decision",
      status: "confirmed",
      source: "會議",
    }),
    {
      title: "決策",
      content: "內容",
      category: "decision",
      status: "confirmed",
      source: "會議",
    },
  );
  assert.throws(() =>
    validateNote({
      title: "猜想",
      content: "內容",
      category: "hypothesis",
      status: "confirmed",
      source: "會議",
    }),
  );
  assert.throws(() =>
    validateNote({
      title: "猜想",
      content: "內容",
      category: "fact",
      status: "pending",
      source: "會議",
      actor: "other",
    }),
  );
});
test("task validates real calendar dates and starts open", () => {
  assert.equal(
    validateTask({
      title: "工作",
      completion: "驗收",
      assignee: null,
      due_date: "2028-02-29",
    }).status,
    "open",
  );
  assert.throws(() =>
    validateTask({ title: "工作", completion: "驗收", due_date: "2027-02-29" }),
  );
});
test("changes require the read version and reject server-managed fields", () => {
  const body = validateTask({ title: "工作", completion: "驗收" });
  assert.throws(
    () => applyChange(body, 2, 1, { status: "done" }, "task"),
    /版本/,
  );
  assert.throws(() => applyChange(body, 1, 1, { updated_by: "other" }, "task"));
  assert.equal(
    applyChange(body, 1, 1, { status: "done" }, "task").status,
    "done",
  );
});
test("request digest is canonical and includes operation", () => {
  assert.equal(
    requestDigest("save_note", { a: 1, b: 2 }),
    requestDigest("save_note", { b: 2, a: 1 }),
  );
  assert.notEqual(
    requestDigest("save_note", { a: 1 }),
    requestDigest("create_task", { a: 1 }),
  );
});
test("return URL accepts only same-origin authorization continuation", () => {
  assert.equal(
    safeReturnURL(
      "/api/auth/oauth2/authorize?client_id=x",
      "https://memory.example.test",
    ),
    "/api/auth/oauth2/authorize?client_id=x",
  );
  for (const value of [
    "https://evil.test",
    "//evil.test",
    "/sign-in",
    "/api/auth/oauth2/authorize/../sign-out",
    "/api/auth/oauth2/authorize#evil",
  ])
    assert.throws(() => safeReturnURL(value, "https://memory.example.test"));
});
