import { testDatabaseURL } from "./database.ts";
import test, { before, after } from "node:test";
import assert from "node:assert/strict";
import { createServer } from "node:http";
import { createHash, createHmac, randomUUID } from "node:crypto";
import { readFile } from "node:fs/promises";
import pg from "pg";
import { getMigrations } from "better-auth/db/migration";
import { signJWT } from "better-auth/plugins/jwt";
import { authOptions, createAuth, type Auth } from "../src/auth.ts";
import { createApp } from "../src/app.ts";
import { MemoryStore } from "../src/memory-store.ts";
import type { Config } from "../src/config.ts";
const dsn = testDatabaseURL();
const admin = new pg.Pool({ connectionString: dsn });
const authPool = new pg.Pool({
  connectionString: dsn,
  options: "-c role=pp_auth_runtime",
});
const memoryPool = new pg.Pool({
  connectionString: dsn,
  options: "-c role=pp_memory_runtime",
});
const config: Config = {
  origin: "http://127.0.0.1:55440",
  resource: "http://127.0.0.1:55440/mcp",
  projectId: "project-a",
  memoryDatabaseURL: "unused",
  authDatabaseURL: "unused",
  secret: "test-only-secret-with-at-least-thirty-two-characters",
  googleClientId: "example-test.apps.googleusercontent.com",
  googleClientSecret: "example-test-only",
  maxBodyBytes: 65536,
};
const store = new MemoryStore(memoryPool, config.projectId);
let auth: Auth;
let app: ReturnType<typeof createApp>;
let server: ReturnType<typeof createServer>;
let cookie: string;
let accessToken: string;
const request = (path: string, init: RequestInit = {}) =>
  app.fetch(new Request(config.origin + path, init));
before(async () => {
  await admin.query(
    "DROP SCHEMA IF EXISTS pp_memory CASCADE; DROP SCHEMA IF EXISTS pp_auth CASCADE",
  );
  await admin.query(
    await readFile(new URL("../sql/001_memory.sql", import.meta.url), "utf8"),
  );
  const plan = await getMigrations(
    authOptions(config, admin, new MemoryStore(admin, config.projectId)),
  );
  await plan.runMigrations();
  await admin.query(
    'REVOKE ALL ON SCHEMA pp_auth FROM PUBLIC; GRANT USAGE ON SCHEMA pp_auth TO pp_auth_runtime,pp_memory_runtime; GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA pp_auth TO pp_auth_runtime; GRANT USAGE ON ALL SEQUENCES IN SCHEMA pp_auth TO pp_auth_runtime; GRANT SELECT(id,email,"emailVerified") ON pp_auth."user" TO pp_memory_runtime; GRANT SELECT("userId","providerId") ON pp_auth.account TO pp_memory_runtime',
  );
  await admin.query(
    "INSERT INTO pp_memory.members(id,email,display_name) VALUES('member-a','a@example.test','A'); INSERT INTO pp_memory.project_members VALUES('project-a','member-a')",
  );
  auth = createAuth(config, authPool, store);
  app = createApp(config, auth, store);
  server = createServer(async (req, res) => {
    try {
      const chunks = [];
      for await (const chunk of req) chunks.push(chunk);
      const response = await app.fetch(
        new Request(config.origin + req.url, {
          method: req.method,
          headers: req.headers as HeadersInit,
          body: ["GET", "HEAD"].includes(req.method!)
            ? undefined
            : Buffer.concat(chunks),
        }),
      );
      res.writeHead(response.status, Object.fromEntries(response.headers));
      res.end(Buffer.from(await response.arrayBuffer()));
    } catch {
      res.writeHead(500);
      res.end();
    }
  });
  await new Promise<void>((resolve) =>
    server.listen(55440, "127.0.0.1", resolve),
  );
});
after(async () => {
  if (server) await new Promise<void>((r) => server.close(() => r()));
  await Promise.all([admin.end(), authPool.end(), memoryPool.end()]);
});
test("anonymous MCP gets OAuth challenge; health reveals no secrets", async () => {
  const response = await request("/mcp", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "tools/list" }),
  });
  assert.equal(response.status, 401);
  assert.match(
    response.headers.get("www-authenticate")!,
    /oauth-protected-resource/,
  );
  assert.equal((await request("/healthz")).status, 200);
});
test("discovery advertises correct issuer, resource, PKCE and DCR compatibility", async () => {
  const meta = await (
    await request("/.well-known/oauth-authorization-server/api/auth")
  ).json();
  assert.equal(meta.issuer, config.origin + "/api/auth");
  assert.ok(meta.registration_endpoint);
  assert.ok(meta.code_challenge_methods_supported.includes("S256"));
  const resource = await (
    await request("/.well-known/oauth-protected-resource/mcp")
  ).json();
  assert.equal(resource.resource, config.resource);
});
test("login/consent reject hostile return URLs, modified signatures, CSRF, and oversized bodies", async () => {
  assert.equal(
    (await request("/sign-in?returnURL=https%3A%2F%2Fevil.example.test"))
      .status,
    400,
  );
  assert.equal((await request("/consent?client_id=x&sig=fake")).status, 400);
  assert.equal(
    (
      await request("/sign-in", {
        method: "POST",
        headers: {
          origin: "https://evil.example.test",
          "content-type": "application/x-www-form-urlencoded",
        },
        body: "",
      })
    ).status,
    403,
  );
  assert.equal(
    (await request("/mcp", { method: "POST", body: "x".repeat(65537) })).status,
    413,
  );
  assert.equal((await request("/api/auth/token")).status, 404);
});
test("public social login cannot request extra Google scopes or override parameters", async () => {
  for (const path of [
    "/api/auth/sign-in/social",
    "/api/auth/sign-in/social/",
    "/api/auth/%73ign-in/social",
    "/api/auth/sign-in%2Fsocial",
  ]) {
    const response = await request(path, {
      method: "POST",
      headers: { origin: config.origin, "content-type": "application/json" },
      body: JSON.stringify({
        provider: "google",
        callbackURL: config.origin + "/",
        scopes: ["https://www.googleapis.com/auth/gmail.readonly"],
        disableRedirect: true,
      }),
    });
    assert.equal(response.status, 404);
    assert.equal(response.headers.get("location"), null);
  }
});
test("Google form returns a same-origin result page with fixed basic scopes", async () => {
  const loginPage = await request("/sign-in");
  assert.equal(loginPage.headers.get("referrer-policy"), "same-origin");
  const response = await request("/sign-in", {
    method: "POST",
    headers: {
      origin: config.origin,
      "content-type": "application/x-www-form-urlencoded",
    },
    body: "oauth_query=",
  });
  assert.equal(response.status, 200);
  assert.equal(response.headers.get("location"), null);
  assert.match(
    response.headers.get("content-security-policy")!,
    /form-action 'self'/,
  );
  assert.ok(response.headers.getSetCookie().length);
  const html = await response.text();
  const target = new URL(
    html.match(/id="continue" href="([^"]+)"/)![1].replaceAll("&amp;", "&"),
  );
  assert.equal(target.origin, "https://accounts.google.com");
  assert.deepEqual(
    new Set(target.searchParams.get("scope")!.split(" ")),
    new Set(["openid", "profile", "email"]),
  );
  assert.equal(
    (
      await request("/sign-in", {
        method: "POST",
        headers: {
          origin: config.origin,
          "content-type": "application/x-www-form-urlencoded",
        },
        body: "oauth_query=&scopes=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fgmail.readonly",
      })
    ).status,
    400,
  );
});
test("Google account creation rejects outsiders and unverified email", async () => {
  const ctx = await auth.$context;
  await assert.rejects(
    ctx.internalAdapter.createUser(
      { name: "Outsider", email: "outsider@example.test", emailVerified: true },
      { method: "oauth", oauth: { providerId: "google", profile: {} } },
    ),
  );
  await assert.rejects(
    ctx.internalAdapter.createUser(
      { name: "Unverified", email: "a@example.test", emailVerified: false },
      { method: "oauth", oauth: { providerId: "google", profile: {} } },
    ),
  );
  const user = await ctx.internalAdapter.createUser(
    { name: "A", email: "a@example.test", emailVerified: true },
    { method: "oauth", oauth: { providerId: "google", profile: {} } },
  );
  await ctx.internalAdapter.createAccount({
    userId: user.id,
    providerId: "google",
    accountId: "google-subject-a",
  });
  const session = await ctx.internalAdapter.createSession(user.id);
  const signature = createHmac("sha256", config.secret)
    .update(session.token)
    .digest("base64");
  cookie =
    "better-auth.session_token=" +
    encodeURIComponent(session.token + "." + signature);
  assert.equal(
    (await auth.api.getSession({ headers: new Headers({ cookie }) }))?.user.id,
    user.id,
  );
});
test("real OAuth PKCE and consent issue a resource-bound token for legacy MCP", async () => {
  const registered = await (
    await request("/api/auth/oauth2/register", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        client_name: "Test Claude",
        redirect_uris: ["http://127.0.0.1:55441/callback"],
        token_endpoint_auth_method: "none",
        grant_types: ["authorization_code", "refresh_token"],
        response_types: ["code"],
      }),
    })
  ).json();
  assert.ok(registered.client_id, JSON.stringify(registered));
  const verifier = "a".repeat(64),
    challenge = createHash("sha256").update(verifier).digest("base64url");
  const params = new URLSearchParams({
    client_id: registered.client_id,
    redirect_uri: "http://127.0.0.1:55441/callback",
    response_type: "code",
    scope: "openid profile email offline_access mcp:tools",
    resource: config.resource,
    code_challenge: challenge,
    code_challenge_method: "S256",
    state: "test-state",
  });
  const started = await request("/api/auth/oauth2/authorize?" + params, {
    headers: { cookie },
  });
  assert.equal(started.status, 302);
  const consentURL = new URL(started.headers.get("location")!, config.origin);
  assert.equal(consentURL.pathname, "/consent");
  const consentPage = await request(consentURL.pathname + consentURL.search, {
    headers: { cookie },
  });
  assert.equal(consentPage.status, 200);
  assert.match(await consentPage.text(), /Test Claude/);
  const consent = await request("/consent", {
    method: "POST",
    headers: {
      cookie,
      origin: config.origin,
      "content-type": "application/x-www-form-urlencoded",
    },
    body: new URLSearchParams({
      oauth_query: consentURL.search.slice(1),
      accept: "true",
    }).toString(),
  });
  assert.equal(consent.status, 200);
  assert.equal(consent.headers.get("location"), null);
  assert.match(
    consent.headers.get("content-security-policy")!,
    /form-action 'self'/,
  );
  const consentResult = await consent.text();
  const callback = new URL(
    consentResult
      .match(/id="continue" href="([^"]+)"/)![1]
      .replaceAll("&amp;", "&"),
  );
  assert.equal(callback.searchParams.get("state"), "test-state");
  const token = await (
    await request("/api/auth/oauth2/token", {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        grant_type: "authorization_code",
        client_id: registered.client_id,
        code: callback.searchParams.get("code")!,
        redirect_uri: "http://127.0.0.1:55441/callback",
        code_verifier: verifier,
        resource: config.resource,
      }),
    })
  ).json();
  assert.ok(token.access_token, JSON.stringify(token));
  accessToken = token.access_token;
  const init = await request("/mcp", {
    method: "POST",
    headers: {
      authorization: "Bearer " + accessToken,
      "content-type": "application/json",
      accept: "application/json, text/event-stream",
    },
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: 1,
      method: "initialize",
      params: {
        protocolVersion: "2025-11-25",
        capabilities: {},
        clientInfo: { name: "test", version: "1" },
      },
    }),
  });
  assert.equal(init.status, 200);
  assert.match(await init.text(), /PP Memory/);
  const listed = await request("/mcp", {
    method: "POST",
    headers: {
      authorization: "Bearer " + accessToken,
      "content-type": "application/json",
      accept: "application/json, text/event-stream",
      "mcp-protocol-version": "2025-11-25",
    },
    body: JSON.stringify({ jsonrpc: "2.0", id: 4, method: "tools/list" }),
  });
  assert.equal(listed.status, 200);
  const listingText = await listed.text();
  const dataLine = listingText
    .split("\n")
    .find((line) => line.startsWith("data: "));
  const listing = JSON.parse(dataLine ? dataLine.slice(6) : listingText);
  const listedTools = listing.result.tools as {
    name: string;
    description: string;
  }[];
  assert.deepEqual(
    listedTools.map((tool) => tool.name).sort(),
    [
      "read_context",
      "save_note",
      "create_task",
      "update_task",
      "correct_note",
    ].sort(),
  );
  for (const tool of listedTools) {
    assert.match(
      tool.description,
      /PP 團隊共用、核准成員可見；不是個人記憶/,
      tool.name,
    );
    if (tool.name !== "read_context") {
      assert.match(tool.description, /PP 用途.*明確共享授權/, tool.name);
      assert.match(tool.description, /目的地.*可見範圍.*摘要/, tool.name);
      assert.match(tool.description, /私人.*混入/, tool.name);
      assert.match(
        tool.description,
        /當前真人.*PP 開工.*確認.*不得寫/,
        tool.name,
      );
    }
  }
});
test("token signature, audience, expiry and scope are enforced", async () => {
  const user = (await auth.api.getSession({
    headers: new Headers({ cookie }),
  }))!.user;
  const send = (token: string) =>
    request("/mcp", {
      method: "POST",
      headers: {
        authorization: "Bearer " + token,
        "content-type": "application/json",
      },
      body: JSON.stringify({ jsonrpc: "2.0", id: 3, method: "tools/list" }),
    });
  assert.equal((await send(accessToken.slice(0, -8) + "invalidx")).status, 401);
  const base = JSON.parse(
    Buffer.from(accessToken.split(".")[1], "base64url").toString(),
  );
  const signingContext = { context: await auth.$context } as Parameters<
    typeof signJWT
  >[0];
  const signed = (change: Record<string, unknown>) =>
    signJWT(signingContext, {
      options: {},
      payload: { ...base, ...change },
      header: { typ: "at+jwt" },
    });
  assert.equal(
    (await send(await signed({ aud: "https://wrong.example.test/mcp" })))
      .status,
    401,
  );
  assert.equal((await send(await signed({ exp: 1 }))).status, 401);
  assert.equal((await send(await signed({ scope: "openid" }))).status, 403);
});
test("authenticated tool rejects forged actor and revoked membership; unexpected errors stay masked", async () => {
  const call = (args: Record<string, unknown>) =>
    request("/mcp", {
      method: "POST",
      headers: {
        authorization: "Bearer " + accessToken,
        "content-type": "application/json",
        accept: "application/json, text/event-stream",
        "mcp-protocol-version": "2025-11-25",
      },
      body: JSON.stringify({
        jsonrpc: "2.0",
        id: 2,
        method: "tools/call",
        params: { name: "save_note", arguments: args },
      }),
    });
  const body = {
    title: "MCP紀錄",
    content: "內容",
    category: "fact",
    status: "pending",
    source: "測試",
    request_id: randomUUID(),
  };
  const forged = await call({ ...body, actor: "member-b" });
  assert.match(await forged.text(), /error|isError/);
  const valid = await call(body);
  assert.equal(valid.status, 200);
  assert.match(await valid.text(), /member-a/);
  await admin.query(
    "ALTER TABLE pp_memory.records RENAME TO records_temporarily_unavailable",
  );
  try {
    const failed = await call({ ...body, request_id: randomUUID() });
    const message = await failed.text();
    assert.match(message, /未確認保存成功/);
    assert.doesNotMatch(message, /records|SELECT|INSERT|password|postgresql/);
  } finally {
    await admin.query(
      "ALTER TABLE pp_memory.records_temporarily_unavailable RENAME TO records",
    );
  }
  await admin.query(
    "UPDATE pp_memory.members SET active=false WHERE id='member-a'",
  );
  assert.equal((await call(body)).status, 403);
});
