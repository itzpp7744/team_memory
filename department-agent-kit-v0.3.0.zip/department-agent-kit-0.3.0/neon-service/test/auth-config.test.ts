import test from "node:test";
import assert from "node:assert/strict";
import pg from "pg";
import { authOptions } from "../src/auth.ts";
import { MemoryStore } from "../src/memory-store.ts";
import type { Config } from "../src/config.ts";
export const config: Config = {
  origin: "http://127.0.0.1:55440",
  resource: "http://127.0.0.1:55440/mcp",
  projectId: "project-a",
  memoryDatabaseURL: "unused",
  authDatabaseURL: "unused",
  secret: "test-only-secret-with-at-least-thirty-two-characters",
  googleClientId: "example-test.apps.googleusercontent.com",
  googleClientSecret: "example-test-only",
  maxBodyBytes: 65536,
};
test("OAuth configuration limits Google scopes, disables account mutation, and keeps durable auth state", async () => {
  const pool = new pg.Pool();
  const options = authOptions(
    config,
    pool,
    new MemoryStore(pool, config.projectId),
  );
  assert.deepEqual(options.socialProviders?.google?.scope, [
    "openid",
    "profile",
    "email",
  ]);
  assert.equal(options.socialProviders?.google?.includeGrantedScopes, false);
  assert.equal(options.account?.accountLinking?.enabled, false);
  assert.ok(options.disabledPaths?.includes("/token"));
  assert.ok(options.disabledPaths?.includes("/change-email"));
  assert.deepEqual(
    options.plugins?.map((x) => x.id),
    ["jwt", "oauth-provider", "cimd"],
  );
  await pool.end();
});
