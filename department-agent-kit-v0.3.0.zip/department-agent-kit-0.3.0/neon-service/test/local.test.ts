import test from "node:test";
import assert from "node:assert/strict";
import { serveLocal } from "../src/local.ts";
test("local HTTP adapter preserves methods, cookies and rejects oversized requests", async () => {
  const server = await serveLocal(
    {
      fetch: async (request: Request) =>
        new Response(await request.text(), {
          headers: { "set-cookie": "one=1; HttpOnly" },
        }),
    },
    "http://127.0.0.1:55442",
    55442,
    32,
  );
  try {
    const valid = await fetch("http://127.0.0.1:55442/test", {
      method: "POST",
      body: "hello",
    });
    assert.equal(await valid.text(), "hello");
    assert.match(valid.headers.get("set-cookie")!, /one=1/);
    const large = await fetch("http://127.0.0.1:55442/test", {
      method: "POST",
      body: "x".repeat(33),
    });
    assert.equal(large.status, 413);
  } finally {
    await new Promise<void>((r) => server.close(() => r()));
  }
});
