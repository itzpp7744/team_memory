import test from "node:test";
import assert from "node:assert/strict";
import { loadConfig } from "../src/config.ts";
const env = {
  PP_BASE_URL: "https://memory.example.test",
  PP_PROJECT_ID: "example-project",
  PP_MEMORY_DATABASE_URL:
    "postgresql://memory_role@db.example.test/db?sslmode=verify-full",
  PP_AUTH_DATABASE_URL:
    "postgresql://auth_role@db.example.test/db?sslmode=verify-full",
  BETTER_AUTH_SECRET: "x".repeat(40),
  GOOGLE_CLIENT_ID: "example-test.apps.googleusercontent.com",
  GOOGLE_CLIENT_SECRET: "example-test-only",
};
test("configuration fails closed and requires isolated runtime roles", () => {
  assert.equal(loadConfig(env).resource, "https://memory.example.test/mcp");
  for (const key of Object.keys(env)) {
    assert.throws(() => loadConfig({ ...env, [key]: "" }));
  }
  assert.throws(() =>
    loadConfig({ ...env, PP_BASE_URL: "http://memory.example.test" }),
  );
  assert.throws(() =>
    loadConfig({ ...env, PP_AUTH_DATABASE_URL: env.PP_MEMORY_DATABASE_URL }),
  );
  assert.throws(() => loadConfig({ ...env, BETTER_AUTH_SECRET: "weak" }));
});
test("remote Postgres connections must verify the server certificate", () => {
  assert.throws(() =>
    loadConfig({
      ...env,
      PP_MEMORY_DATABASE_URL: env.PP_MEMORY_DATABASE_URL.replace(
        "verify-full",
        "require",
      ),
    }),
  );
  assert.throws(() =>
    loadConfig({
      ...env,
      PP_AUTH_DATABASE_URL: "postgresql://auth_role@db.example.test/db",
    }),
  );
});
