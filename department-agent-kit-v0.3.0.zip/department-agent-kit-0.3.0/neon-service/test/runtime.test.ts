import { testDatabaseURL } from "./database.ts";
import test, { before, after } from "node:test";
import assert from "node:assert/strict";
import pg from "pg";
import { assertRuntimePrivileges } from "../src/config.ts";
const dsn = testDatabaseURL();
const owner = new pg.Pool({ connectionString: dsn }),
  memory = new pg.Pool({
    connectionString: dsn,
    options: "-c role=pp_memory_runtime",
  }),
  auth = new pg.Pool({
    connectionString: dsn,
    options: "-c role=pp_auth_runtime",
  });
after(async () => {
  await Promise.all([owner.end(), memory.end(), auth.end()]);
});
test("runtime privilege check rejects an owner connection and accepts restricted pools", async () => {
  await assert.rejects(assertRuntimePrivileges(owner, auth), /權限/);
  await assert.rejects(assertRuntimePrivileges(memory, owner), /權限/);
  await assertRuntimePrivileges(memory, auth);
});
test("runtime privilege check rejects accidental allowlist insertion grants", async () => {
  await owner.query("GRANT INSERT ON pp_memory.members TO pp_memory_runtime");
  try {
    await assert.rejects(assertRuntimePrivileges(memory, auth), /權限/);
  } finally {
    await owner.query(
      "REVOKE INSERT ON pp_memory.members FROM pp_memory_runtime",
    );
  }
});
