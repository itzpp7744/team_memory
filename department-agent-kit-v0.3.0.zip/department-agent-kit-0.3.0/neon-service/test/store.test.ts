import { testDatabaseURL } from "./database.ts";
import test, { before, after } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { readFile } from "node:fs/promises";
import pg from "pg";
import { MemoryStore } from "../src/memory-store.ts";
import { validateNote, validateTask } from "../src/memory-validation.ts";
const dsn = testDatabaseURL();
const admin = new pg.Pool({ connectionString: dsn });
const runtime = new pg.Pool({
  connectionString: dsn,
  options: "-c role=pp_memory_runtime",
});
const store = new MemoryStore(runtime, "project-a");
const note = () =>
  validateNote({
    title: "決策",
    content: "內容",
    category: "decision",
    status: "confirmed",
    source: "會議",
  });
before(async () => {
  await admin.query(
    "DROP SCHEMA IF EXISTS pp_memory CASCADE; DROP SCHEMA IF EXISTS pp_auth CASCADE",
  );
  await admin.query(
    'CREATE SCHEMA pp_auth; CREATE TABLE pp_auth."user"(id text PRIMARY KEY,email text,"emailVerified" boolean); CREATE TABLE pp_auth.account(id text PRIMARY KEY,"userId" text,"providerId" text)',
  );
  await admin.query(
    await readFile(new URL("../sql/001_memory.sql", import.meta.url), "utf8"),
  );
  await admin.query(
    'GRANT USAGE ON SCHEMA pp_auth TO pp_memory_runtime; GRANT SELECT(id,email,"emailVerified") ON pp_auth."user" TO pp_memory_runtime; GRANT SELECT("userId","providerId") ON pp_auth.account TO pp_memory_runtime',
  );
  await admin.query(
    "INSERT INTO pp_auth.\"user\" VALUES ('user-a','a@example.test',true),('user-b','b@example.test',true),('user-unverified','u@example.test',false)",
  );
  await admin.query(
    "INSERT INTO pp_auth.account VALUES ('account-a','user-a','google'),('account-b','user-b','google'),('account-u','user-unverified','google')",
  );
  await admin.query(
    "INSERT INTO pp_memory.members(id,email,display_name) VALUES ('member-a','a@example.test','A'),('member-b','b@example.test','B'),('member-u','u@example.test','U')",
  );
  await admin.query(
    "INSERT INTO pp_memory.project_members VALUES ('project-a','member-a'),('project-b','member-b')",
  );
});
after(async () => {
  await runtime.end();
  await admin.end();
});
test("verified Google identity binds only to active pre-created member and project", async () => {
  assert.equal(await store.bindIdentity("user-a"), "member-a");
  await assert.rejects(store.bindIdentity("user-unverified"));
  await assert.rejects(store.bindIdentity("unknown"));
  await assert.rejects(store.bindIdentity("user-b"));
});
test("parallel retries create once and changed payload conflicts", async () => {
  const id = randomUUID();
  const results = await Promise.all(
    Array.from({ length: 8 }, () => store.create("user-a", "note", note(), id)),
  );
  assert.equal(new Set(results.map((x) => x.id)).size, 1);
  assert.equal(
    Number(
      (
        await admin.query(
          "SELECT count(*) FROM pp_memory.events WHERE action='create_note'",
        )
      ).rows[0].count,
    ),
    1,
  );
  await assert.rejects(
    store.create("user-a", "note", { ...note(), title: "變更" }, id),
    /不同內容/,
  );
});
test("version conflicts preserve previous record and append audit for successful edit", async () => {
  const item = await store.create(
    "user-a",
    "task",
    validateTask({ title: "工作", completion: "通過" }),
    randomUUID(),
  );
  const updated = await store.update(
    "user-a",
    item.id,
    "task",
    1,
    { status: "done" },
    randomUUID(),
    "完成",
  );
  assert.equal(updated.version, 2);
  await assert.rejects(
    store.update(
      "user-a",
      item.id,
      "task",
      1,
      { status: "doing" },
      randomUUID(),
      "舊版本",
    ),
    /版本/,
  );
  const audit = (
    await admin.query(
      "SELECT previous,current,reason FROM pp_memory.events WHERE record_id=$1 AND action=$2",
      [item.id, "update_task"],
    )
  ).rows;
  assert.equal(audit.length, 1);
  assert.equal(audit[0].previous.version, 1);
  assert.equal(audit[0].current.version, 2);
});
test("project membership prevents read and edits in a different project", async () => {
  const other = new MemoryStore(runtime, "project-b");
  await other.bindIdentity("user-b");
  await assert.rejects(other.readContext("user-a"));
  const item = await store.create("user-a", "note", note(), randomUUID());
  await assert.rejects(
    other.update(
      "user-b",
      item.id,
      "note",
      1,
      { title: "窺探" },
      randomUUID(),
      "錯誤專案",
    ),
  );
  assert.equal((await other.readContext("user-b")).notes.length, 0);
});
test("deactivation revokes existing identity, including cached write retries", async () => {
  const id = randomUUID();
  await store.create("user-a", "note", note(), id);
  await admin.query(
    "UPDATE pp_memory.members SET active=false WHERE id='member-a'",
  );
  await assert.rejects(store.readContext("user-a"));
  await assert.rejects(store.create("user-a", "note", note(), id));
  await admin.query(
    "UPDATE pp_memory.members SET active=true WHERE id='member-a'",
  );
});
test("runtime cannot change allowlist, erase audit, or create schema objects", async () => {
  for (const sql of [
    "UPDATE pp_memory.members SET active=true",
    "DELETE FROM pp_memory.events",
    "UPDATE pp_memory.events SET reason='hidden'",
    "CREATE TABLE pp_memory.evil(id int)",
    "DELETE FROM pp_memory.identity_bindings",
  ]) {
    await assert.rejects(runtime.query(sql), /permission denied/);
  }
});
