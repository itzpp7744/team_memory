import { testDatabaseURL } from "./database.ts";
import test, { before, after } from "node:test";
import assert from "node:assert/strict";
import pg from "pg";
import { migrate } from "../scripts/migrate.ts";
import { setMember } from "../scripts/member.ts";
import type { Config } from "../src/config.ts";
const dsn = testDatabaseURL();
const admin = new pg.Pool({ connectionString: dsn });
const config: Config = {
  origin: "http://127.0.0.1:55440",
  resource: "http://127.0.0.1:55440/mcp",
  projectId: "project-a",
  memoryDatabaseURL: "unused",
  authDatabaseURL: "unused",
  secret: "test-only-secret-with-at-least-thirty-two-characters",
  googleClientId: "example-test.apps.googleusercontent.com",
  googleClientSecret: "example-test-only",
  maxBodyBytes: 65536,
};
before(async () => {
  await admin.query(
    "DROP SCHEMA IF EXISTS pp_memory CASCADE; DROP SCHEMA IF EXISTS pp_auth CASCADE",
  );
});
after(async () => {
  await admin.end();
});
test("one-time administrator migration creates isolated schemas and fails on repeat", async () => {
  await migrate(admin, config);
  const tables = await admin.query(
    "SELECT table_schema,table_name FROM information_schema.tables WHERE table_schema IN ('pp_memory','pp_auth')",
  );
  assert.ok(
    tables.rows.some(
      (x) => x.table_schema === "pp_auth" && x.table_name === "oauthClient",
    ),
  );
  assert.ok(
    tables.rows.some(
      (x) => x.table_schema === "pp_memory" && x.table_name === "events",
    ),
  );
  await assert.rejects(migrate(admin, config), /存在/);
});
test("administrator adds, grants project and disables member with parameterized values", async () => {
  const id = await setMember(admin, {
    email: "USER@EXAMPLE.TEST",
    name: "Member ' ; --",
    project: "project-a",
    active: true,
  });
  assert.ok(id);
  await setMember(admin, {
    email: "user@example.test",
    name: "Member",
    project: "project-a",
    active: false,
  });
  const row = (
    await admin.query("SELECT * FROM pp_memory.members WHERE id=$1", [id])
  ).rows[0];
  assert.equal(row.email, "user@example.test");
  assert.equal(row.active, false);
  assert.equal(
    (
      await admin.query(
        "SELECT 1 FROM pp_memory.project_members WHERE member_id=$1 AND project_id=$2",
        [id, "project-a"],
      )
    ).rowCount,
    1,
  );
});
