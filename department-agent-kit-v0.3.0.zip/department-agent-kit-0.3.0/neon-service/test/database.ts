export function testDatabaseURL(): string {
  const value = process.env.PP_TEST_DATABASE_URL;
  if (!value)
    throw new Error("PP_TEST_DATABASE_URL 必須指向獨立本機 *_test 資料庫");
  const url = new URL(value.replace("@/", "@localhost/")),
    localHost = ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname),
    localSocket =
      !url.hostname &&
      (url.searchParams.get("host") ?? "").startsWith("/private/tmp/");
  if ((!localHost && !localSocket) || !/^\/[a-z0-9_]+_test$/.test(url.pathname))
    throw new Error(
      "測試會重建 pp_memory/pp_auth；只允許獨立本機 *_test 資料庫",
    );
  return value;
}
