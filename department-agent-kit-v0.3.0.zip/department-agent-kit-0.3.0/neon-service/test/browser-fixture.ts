// Local synthetic UI fixture only. Never imported by src/index.ts or deployed.
import { createHash, createHmac } from "node:crypto";
import pg from "pg";
import { testDatabaseURL } from "./database.ts";
import { migrate } from "../scripts/migrate.ts";
import { setMember } from "../scripts/member.ts";
import { createAuth } from "../src/auth.ts";
import { createApp } from "../src/app.ts";
import { MemoryStore } from "../src/memory-store.ts";
import { serveLocal } from "../src/local.ts";
import type { Config } from "../src/config.ts";
const dsn = testDatabaseURL();
const admin = new pg.Pool({ connectionString: dsn });
const authPool = new pg.Pool({
  connectionString: dsn,
  options: "-c role=pp_auth_runtime",
});
const memoryPool = new pg.Pool({
  connectionString: dsn,
  options: "-c role=pp_memory_runtime",
});
const config: Config = {
  origin: "http://127.0.0.1:55445",
  resource: "http://127.0.0.1:55445/mcp",
  projectId: "browser-test",
  memoryDatabaseURL: "unused",
  authDatabaseURL: "unused",
  secret: "synthetic-browser-test-secret-at-least-32-characters",
  googleClientId: "example-test.apps.googleusercontent.com",
  googleClientSecret: "example-test-only",
  maxBodyBytes: 65536,
};
await admin.query(
  "DROP SCHEMA IF EXISTS pp_memory CASCADE; DROP SCHEMA IF EXISTS pp_auth CASCADE",
);
await migrate(admin, config);
await setMember(admin, {
  email: "browser@example.test",
  name: "Browser fixture",
  project: config.projectId,
  active: true,
});
const store = new MemoryStore(memoryPool, config.projectId);
const auth = createAuth(config, authPool, store),
  app = createApp(config, auth, store),
  ctx = await auth.$context;
const user = await ctx.internalAdapter.createUser(
  {
    name: "Browser fixture",
    email: "browser@example.test",
    emailVerified: true,
  },
  { method: "oauth", oauth: { providerId: "google", profile: {} } },
);
await ctx.internalAdapter.createAccount({
  userId: user.id,
  providerId: "google",
  accountId: "synthetic-browser-google-subject",
});
const session = await ctx.internalAdapter.createSession(user.id);
const signature = createHmac("sha256", config.secret)
  .update(session.token)
  .digest("base64");
const cookie =
  "better-auth.session_token=" +
  encodeURIComponent(session.token + "." + signature) +
  "; HttpOnly; SameSite=Lax; Path=/";
const client = await (
  await app.fetch(
    new Request(config.origin + "/api/auth/oauth2/register", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        client_name: "Browser Test Client",
        redirect_uris: ["http://127.0.0.1:55446/callback"],
        token_endpoint_auth_method: "none",
        grant_types: ["authorization_code"],
        response_types: ["code"],
      }),
    }),
  )
).json();
const params = new URLSearchParams({
  client_id: client.client_id,
  redirect_uri: "http://127.0.0.1:55446/callback",
  response_type: "code",
  scope: "openid profile email mcp:tools",
  resource: config.resource,
  code_challenge: createHash("sha256")
    .update("b".repeat(64))
    .digest("base64url"),
  code_challenge_method: "S256",
  state: "browser-state",
});
const primary = await serveLocal(
  {
    fetch: async (request) => {
      return new URL(request.url).pathname === "/test-start"
        ? new Response(null, {
            status: 302,
            headers: {
              location: config.origin + "/api/auth/oauth2/authorize?" + params,
              "set-cookie": cookie,
            },
          })
        : app.fetch(request);
    },
  },
  config.origin,
  55445,
  config.maxBodyBytes,
);
const callback = await serveLocal(
  {
    fetch: async (request) => {
      const url = new URL(request.url);
      return new Response(
        url.pathname === "/callback" &&
          Boolean(url.searchParams.get("code")) &&
          url.searchParams.get("state") === "browser-state"
          ? "Browser callback received successfully"
          : "Invalid callback",
        { headers: { "content-type": "text/plain; charset=utf-8" } },
      );
    },
  },
  "http://127.0.0.1:55446",
  55446,
  65536,
);
console.log(
  "Synthetic browser fixture ready: http://127.0.0.1:55445/sign-in and /test-start",
);
const stop = async () => {
  await Promise.all([
    new Promise<void>((r) => primary.close(() => r())),
    new Promise<void>((r) => callback.close(() => r())),
  ]);
  await Promise.all([admin.end(), authPool.end(), memoryPool.end()]);
  process.exit(0);
};
process.on("SIGINT", stop);
process.on("SIGTERM", stop);
