# PP 共用記憶：Google 登入與 Neon 服務

這個 Node.js 24 服務讓團隊用 Google 帳號登入，透過 MCP（讓 Claude 等應用程式呼叫工具的連線規格）共用專案記憶與待辦。既有 Python 服務、安裝器及 `pp-memory/2` 本機草稿格式保留。

**正式交付要以本人登入後的遠端讀寫驗收為準。** 程式建置成功、健康檢查回 200，或本機測試通過，都不代表 Google 登入及 Claude 已接通。此資料夾本身不會替安裝器自動建立 Claude 連線。

## 這個版本做什麼

流程是「管理者加入信箱及專案 → 本人用 Google 登入 → 服務綁定已驗證帳號 → 本人同意應用程式連線 → 工具每次讀寫重新查權限 → 寫入記憶與操作紀錄」。

Google 只要求 `openid`、`profile`、`email`，用來確認帳號、姓名、頭像與信箱。不要求 Google Drive 或 Gmail 權限，也不提供文件讀取工具。公開的 `/api/auth/sign-in/social` 已停用，登入只能由本站表單以固定參數啟動，不能自行加上額外 Google 權限。

| 工具           | 參數及行為                                                                        |
| -------------- | --------------------------------------------------------------------------------- |
| `read_context` | `limit=50`；每類最多 100 筆，回傳目前專案的記憶與待辦                             |
| `save_note`    | `title, content, category, source, request_id, status='pending'`                  |
| `create_task`  | `title, completion, request_id, assignee=null, due_date=null`；狀態從 `open` 開始 |
| `update_task`  | `record_id, expected_version, changes, reason, request_id`                        |
| `correct_note` | 同上；可將 `status` 改為 `void` 作廢，舊內容留在操作紀錄                          |

草稿送出時只傳 `payload` 與原來的 `request_id`。`submitted_by` 是本機顯示名稱，不能拿來證明身分；工具也不接受 `actor`、`email` 或 `project_id` 覆蓋登入者與部署設定。

`request_id` 是一次操作的 UUID（不容易重複的識別碼）。同一操作重試要沿用；同一編號改內容會被拒絕。多個重試同時到達也只寫一筆。`expected_version` 是你讀到的版本，版本過期就拒絕更新，避免蓋掉別人的修改。成功回傳的 `id` 和 `version` 才是保存證明。

## 執行環境與設定

使用 Node.js 24。所有秘密透過環境變數傳入，不建立 `.env`。依使用者慣例，長期秘密放在 `~/.zshrc` 的專案專用變數，再由部署程序映射；不要貼進程式、設定檔、網址或操作紀錄。

| 變數                     | 用途                                                              |
| ------------------------ | ----------------------------------------------------------------- |
| `PP_BASE_URL`            | 服務的 HTTPS 網站位址，不含路徑；本機可用 `http://127.0.0.1:8080` |
| `PP_PROJECT_ID`          | 這個服務所屬的專案代號                                            |
| `PP_MEMORY_DATABASE_URL` | 記憶資料的受限資料庫連線                                          |
| `PP_AUTH_DATABASE_URL`   | 登入資料的另一個受限資料庫連線，帳號必須與記憶角色不同            |
| `BETTER_AUTH_SECRET`     | 至少 32 字元的隨機秘密；用來保護登入狀態與授權資料                |
| `GOOGLE_CLIENT_ID`       | Google OAuth 網頁應用程式的用戶端 ID                              |
| `GOOGLE_CLIENT_SECRET`   | 上述用戶端的秘密                                                  |
| `PP_ADMIN_DATABASE_URL`  | 只給初始化與成員管理腳本；不可部署到服務                          |
| `PP_TEST_DATABASE_URL`   | 只給測試，限本機、資料庫名稱以 `_test` 結尾                       |
| `PORT`                   | 本機啟動的連接埠，預設 `8080`                                     |

遠端資料庫連線必須帶 `sslmode=verify-full`，確實核對伺服器憑證。不要改成 `require` 或停用憑證驗證。

Google Cloud 的 OAuth 用戶端類型選「網頁應用程式」，重新導向網址填：

```text
https://你的服務網站/api/auth/callback/google
```

Google OAuth 是「讓 Google 證明這是誰」的授權流程。Google 專案若仍在測試模式，還需要在 Google Cloud 加入測試使用者；這與本服務的成員允許名單是兩個不同設定。

## 管理者初始化

先進入這個資料夾，再安裝已鎖定的依賴：

```sh
npm ci
npm run build
npm run migrate
```

`.npmrc` 關閉自動補入框架用的 peer dependencies（選配整合套件）；本服務直接使用的套件已列在 `package.json`，版本由 `package-lock.json` 固定。

`migrate` 使用 `PP_ADMIN_DATABASE_URL`，只建立新的 `pp_memory` 與 `pp_auth` schema。Schema 是資料庫內分開存放資料表的命名空間。已有任一名稱就停止，避免覆蓋舊資料；不會碰 `department_agent`、`neon_auth` 或 `public` 裡的資料表。服務啟動時不執行 migration（資料表結構調整）。

如果初始化中途失敗，先查明哪個步驟完成，再由管理者修復；不要刪除已有資料來讓腳本重跑。登入資料表由鎖定版本的 Better Auth 官方 migration API 建立。

腳本會建立兩個 `NOLOGIN` 群組角色，也就是只能分配權限、不能直接登入的資料庫角色：

- `pp_memory_runtime`：可讀成員名單與身分綁定、寫記憶及請求結果、只新增操作紀錄。
- `pp_auth_runtime`：可維護 `pp_auth` 的登入與授權資料，不能修改記憶資料。

管理者另外建立兩個獨立的登入角色，分別加入上述群組，再將連線字串放入對應環境變數。不要沿用 owner、管理者角色或繼承 `neon_superuser`。服務啟動時會檢查過大的權限；發現可以改成員名單、清除操作紀錄或建立正式資料表，就拒絕啟動。

加入成員與專案：

```sh
npm run member -- --email member@example.test --name '成員名稱' --project example-project
```

停用成員：

```sh
npm run member -- --email member@example.test --name '成員名稱' --project example-project --disable
```

`example.test` 是示範信箱，不會新增正式成員。停用會影響這位成員的所有專案；重新執行不帶 `--disable` 的指令才會恢復。單一專案撤權由管理者刪除對應 `pp_memory.project_members` 關係，不刪記憶或操作紀錄。

第一次登入會把 Better Auth 的使用者 ID 綁到預先核准的信箱。服務會同時確認信箱已驗證、帳號來源是 Google、成員有效且有該專案權限。身分綁定只允許新增，不能用另一個新帳號直接搶回既有綁定；帳號搬遷需由管理者另行處理。

## 本機啟動與測試

載入環境變數後：

```sh
npm run dev
```

本機入口只監聽 `127.0.0.1`。`PP_BASE_URL` 的連接埠要與 `PORT` 相同。

測試會重建指定測試資料庫的 `pp_memory`、`pp_auth`，只可用獨立的本機資料庫。先由管理者建立名稱以 `_test` 結尾的資料庫，再設定 `PP_TEST_DATABASE_URL`。測試會建立角色，測試連線需有管理權限；它不會被服務使用。

```sh
npm run build
npm test
```

測試包含輸入驗證、真實 PostgreSQL 交易與權限、8 個同時重試、版本衝突、專案隔離、停用後撤權、OAuth PKCE／同意頁／token 交換、token 的簽章與服務範圍驗證，以及 MCP 工具呼叫。整合測試使用 `55440`、`55442` 本機連接埠。

PKCE 是授權流程中的一次性配對證明，讓攔到授權碼的人無法直接換取登入憑證。測試中的 Google 身分由本機假資料建立，**沒有連到真人 Google 帳號**；正式 Google 回呼仍須真人登入驗收。

## Neon Functions 部署

`neon.ts` 的 function slug 固定為 `ppmemory`，入口為 `src/index.ts`。Slug 是 Neon 用來識別這個服務的短名稱，部署後不要任意更換。

`neon.ts` 從目前程序的環境變數取得設定，不讀取 `.env`。其中 `DATABASE_URL` 與 `DATABASE_URL_UNPOOLED` 都明確覆蓋為 `PP_MEMORY_DATABASE_URL`，避免 Neon 自動注入的 owner 連線留在正式執行環境。若使用單一 function 部署指令而沒有套用 `neon.ts`，也必須明確傳入這兩項覆蓋，且不可上傳 `PP_ADMIN_DATABASE_URL`。

部署程序須避免 CLI 自動把雲端秘密拉回 `.env`。先在測試環境完成初始化與角色驗證，再部署到已確認的專案、分支與 Free 方案。此服務不會自動建立付費方案、開啟永不休眠或更動其他 Neon 服務。

## Claude 連線與正式驗收

Claude 的遠端 MCP 網址是：

```text
https://你的服務網站/mcp
```

服務使用 Better Auth 的 JWT、MCP、CIMD 官方外掛。JWT 是帶簽章且會到期的登入憑證；CIMD 是讓應用程式以公開網址提供自己資料的客戶端識別方式。服務也開啟 DCR（讓較舊的應用程式登記回呼網址），相容舊版 Claude 連線流程；這不會讓人自行加入成員名單。

MCP 2026 協定與 2025 協定都採無狀態處理：每個 HTTP 請求建立自己的 server／transport，不在不同人的請求間共用身分。`GET /mcp`、`DELETE /mcp` 回 405；使用 POST。舊式獨立 SSE 網址不在支援範圍。

正式交付前要完成：

1. 本人從 Claude 開始連線，按「使用 Google 登入」後，再點「前往 Google 登入」。用允許名單中的帳號登入，確認應用程式名稱與權限後同意，再點「返回應用程式」。
2. 呼叫 `read_context` 確認 `project_id` 正確。
3. 新增一筆測試記憶，取得實際 `id`、`version`；另一位獲授權成員能讀到同一筆。
4. 重送原 `request_id` 不會多一筆；更正要帶版本與理由。
5. 管理者停用測試成員後，既有登入憑證也不能再讀寫。
6. 安裝器完成時就能使用這個已驗收的連線；只產生本機草稿不算完成。

`/healthz` 只表示程序可以回應，固定回傳 `external_acceptance: NOT_VERIFIED`，不拿它冒充真人驗收紀錄。

## 保護與限制

- SQL 的使用者資料全部透過參數傳入。成員、身分、版本與時間由服務決定。
- 每次讀寫與重試都重新檢查有效成員及專案權限。成功新增、更新與讀取均新增 audit（操作紀錄）；runtime 不能刪改它。
- 外部請求最多 128 KiB；資料庫查詢限時 15 秒、等鎖最多 10 秒，連線池每類最多 3 條。
- 同意頁會檢查簽章與有效時間，表單檢查來源網站；Google 登入交由 Better Auth 驗證 OAuth state。表單只送往本站；成功後先顯示本站結果頁，再由使用者點連結前往 Google 或已登記的應用程式回呼。`Referrer-Policy: same-origin` 保留同源表單的來源資訊，跨站連結不傳送來源網址。
- MCP 憑證會驗證簽章、發行者、到期時間、audience（憑證限用的服務）及 `mcp:tools` 權限。綁定 DPoP 的憑證仍交給官方外掛驗證，不自行略過。
- 未預期錯誤只回固定訊息，不把 SQL、連線字串或秘密送給客戶端。
- Neon 原生網址是公開入口；未授權請求會被拒絕，但仍會抵達服務、占用執行次數。應用程式驗證不等於流量防護。此版本沒有另接付費防護服務。
- 此版本未加入自動刪除授權資料或備份排程。部署管理者需另外管理備份、保留時間與配額。

## 官方參考

- [Better Auth MCP](https://better-auth.com/docs/plugins/mcp)
- [Better Auth OAuth Provider](https://better-auth.com/docs/plugins/oauth-provider)
- [Neon Functions 環境變數](https://neon.com/docs/compute/functions/environment-variables)

## 本機瀏覽器回歸

設定獨立本機 `PP_TEST_DATABASE_URL` 後，執行 `node test/browser-fixture.ts`。它只使用假帳號與假 Google client，會重建測試資料庫，不能與 `npm test` 同時執行；不會讀取正式 Google 憑證，也不在部署入口中。

- 開啟 `http://127.0.0.1:55445/sign-in`，點登入按鈕後應看到本站的「前往 Google 登入」連結；點連結會到 Google，假 client 預期顯示 `invalid_client`。這只驗證瀏覽器導向，沒有完成真人登入。
- 開啟 `http://127.0.0.1:55445/test-start`，假帳號同意後應看到本站的「返回應用程式」連結；點連結會前往另一個 origin（連接埠 `55446`），顯示 `Browser callback received successfully`。
- 這兩步已用 Chrome 實際點擊驗證；沒有放寬 `form-action 'self'` 或允許 `Origin: null`。
