import pg from "pg";
import { attachDatabasePool } from "@neon/functions";
import { assertRuntimePrivileges, loadConfig } from "./config.ts";
import { createAuth } from "./auth.ts";
import { createApp } from "./app.ts";
import { MemoryStore } from "./memory-store.ts";
export const config = loadConfig();
const poolOptions = {
  max: 3,
  connectionTimeoutMillis: 10_000,
  idleTimeoutMillis: 30_000,
  statement_timeout: 15_000,
};
const memoryPool = new pg.Pool({
  ...poolOptions,
  connectionString: config.memoryDatabaseURL,
});
const authPool = new pg.Pool({
  ...poolOptions,
  connectionString: config.authDatabaseURL,
});
attachDatabasePool(memoryPool);
attachDatabasePool(authPool);
await assertRuntimePrivileges(memoryPool, authPool);
const store = new MemoryStore(memoryPool, config.projectId);
const auth = createAuth(config, authPool, store);
export default createApp(config, auth, store);
