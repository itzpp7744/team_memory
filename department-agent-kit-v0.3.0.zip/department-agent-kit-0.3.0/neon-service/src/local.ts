import { createServer, type Server } from "node:http";
import { pathToFileURL } from "node:url";
export async function serveLocal(
  app: { fetch: (request: Request) => Promise<Response> },
  origin: string,
  port: number,
  maxBodyBytes: number,
): Promise<Server> {
  const server = createServer(async (req, res) => {
    try {
      const chunks: Buffer[] = [];
      let size = 0;
      for await (const chunk of req) {
        size += chunk.length;
        if (size > maxBodyBytes) {
          res.writeHead(413);
          res.end("Request too large");
          req.resume();
          return;
        }
        chunks.push(chunk);
      }
      const request = new Request(origin + (req.url ?? "/"), {
        method: req.method,
        headers: req.headers as HeadersInit,
        body: ["GET", "HEAD"].includes(req.method ?? "GET")
          ? undefined
          : Buffer.concat(chunks),
      });
      const response = await app.fetch(request);
      res.statusCode = response.status;
      for (const [key, value] of response.headers)
        if (key !== "set-cookie") res.setHeader(key, value);
      if (response.headers.getSetCookie().length)
        res.setHeader("set-cookie", response.headers.getSetCookie());
      if (response.body) {
        for await (const chunk of response.body) res.write(chunk);
      }
      res.end();
    } catch {
      if (!res.headersSent) res.writeHead(500);
      res.end("Request failed");
    }
  });
  server.requestTimeout = 30_000;
  server.headersTimeout = 10_000;
  await new Promise<void>((resolve, reject) => {
    server.once("error", reject);
    server.listen(port, "127.0.0.1", () => {
      server.off("error", reject);
      resolve();
    });
  });
  return server;
}
if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(process.argv[1]).href
) {
  const { default: app, config } = await import("./index.ts");
  const port = Number(process.env.PORT ?? 8080);
  if (!Number.isSafeInteger(port) || port < 1 || port > 65535)
    throw new Error("PORT 必須是有效的連接埠");
  await serveLocal(app, config.origin, port, config.maxBodyBytes);
  console.log(`PP Memory listening on http://127.0.0.1:${port}`);
}
