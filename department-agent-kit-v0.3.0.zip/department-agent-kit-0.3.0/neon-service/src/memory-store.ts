import { randomUUID } from "node:crypto";
import type { Pool, PoolClient } from "pg";
import {
  applyChange,
  Conflict,
  Forbidden,
  InputError,
  requestDigest,
  text,
  uuid,
  validateNote,
  validateTask,
  type Body,
  type Kind,
} from "./memory-validation.ts";
export interface MemoryRecord {
  id: string;
  project_id: string;
  kind: Kind;
  version: number;
  body: Body;
  created_by: string;
  updated_by: string;
  updated_at: string;
}
function output(row: Record<string, any>): MemoryRecord {
  return {
    id: row.id,
    project_id: row.project_id,
    kind: row.kind,
    version: row.version,
    body: row.body,
    created_by: row.created_by,
    updated_by: row.updated_by,
    updated_at: row.updated_at.toISOString(),
  };
}
export class MemoryStore {
  readonly pool: Pool;
  readonly projectId: string;
  constructor(pool: Pool, projectId: string) {
    this.pool = pool;
    this.projectId = text(projectId, "專案代號", 200);
  }
  private async transaction<T>(
    operation: (client: PoolClient) => Promise<T>,
  ): Promise<T> {
    const client = await this.pool.connect();
    try {
      await client.query("BEGIN");
      await client.query(
        "SET LOCAL statement_timeout='15s'; SET LOCAL lock_timeout='10s'",
      );
      const result = await operation(client);
      await client.query("COMMIT");
      return result;
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    } finally {
      client.release();
    }
  }
  async allowedEmail(email: string): Promise<boolean> {
    const result = await this.pool.query(
      "SELECT 1 FROM pp_memory.members m JOIN pp_memory.project_members p ON p.member_id=m.id WHERE m.email=$1 AND m.active AND p.project_id=$2",
      [email.toLowerCase(), this.projectId],
    );
    return result.rowCount === 1;
  }
  private async member(client: PoolClient, userId: string): Promise<string> {
    const result = await client.query(
      'SELECT m.id FROM pp_memory.members m JOIN pp_memory.project_members p ON p.member_id=m.id JOIN pp_memory.identity_bindings b ON b.member_id=m.id JOIN pp_auth."user" u ON u.id=b.auth_user_id WHERE b.auth_user_id=$1 AND m.active AND p.project_id=$2 AND u."emailVerified"=true AND lower(u.email)=m.email AND EXISTS(SELECT 1 FROM pp_auth.account a WHERE a."userId"=u.id AND a."providerId"=$3)',
      [userId, this.projectId, "google"],
    );
    if (result.rows.length !== 1)
      throw new Forbidden("此 Google 身分未獲專案授權或已停用");
    return result.rows[0].id;
  }
  async bindIdentity(userId: string): Promise<string> {
    return this.transaction(async (client) => {
      const eligible = await client.query(
        'SELECT m.id FROM pp_memory.members m JOIN pp_memory.project_members p ON p.member_id=m.id JOIN pp_auth."user" u ON lower(u.email)=m.email WHERE u.id=$1 AND u."emailVerified"=true AND m.active AND p.project_id=$2 AND EXISTS(SELECT 1 FROM pp_auth.account a WHERE a."userId"=u.id AND a."providerId"=$3)',
        [userId, this.projectId, "google"],
      );
      if (eligible.rows.length !== 1)
        throw new Forbidden("此 Google 身分未獲專案授權或已停用");
      await client.query(
        "INSERT INTO pp_memory.identity_bindings(auth_user_id,member_id) VALUES($1,$2) ON CONFLICT DO NOTHING",
        [userId, eligible.rows[0].id],
      );
      return this.member(client, userId);
    });
  }
  async authorize(userId: string): Promise<string> {
    return this.transaction((client) => this.member(client, userId));
  }
  private async event(
    client: PoolClient,
    actor: string,
    action: string,
    recordId: string | null = null,
    previous: MemoryRecord | null = null,
    current: MemoryRecord | null = null,
    reason: string | null = null,
  ) {
    await client.query(
      "INSERT INTO pp_memory.events(actor,project_id,action,record_id,previous,current,reason) VALUES($1,$2,$3,$4,$5,$6,$7)",
      [actor, this.projectId, action, recordId, previous, current, reason],
    );
  }
  private async request(
    client: PoolClient,
    actor: string,
    key: string,
    digest: string,
  ): Promise<MemoryRecord | null> {
    await client.query(
      "INSERT INTO pp_memory.requests(actor,project_id,request_id,digest) VALUES($1,$2,$3,$4) ON CONFLICT DO NOTHING",
      [actor, this.projectId, key, digest],
    );
    const row = (
      await client.query(
        "SELECT digest,result FROM pp_memory.requests WHERE actor=$1 AND project_id=$2 AND request_id=$3 FOR UPDATE",
        [actor, this.projectId, key],
      )
    ).rows[0];
    if (row.digest !== digest)
      throw new Conflict("同一請求編號已用於不同內容，請使用新編號");
    return row.result;
  }
  private async finish(
    client: PoolClient,
    actor: string,
    key: string,
    result: MemoryRecord,
  ): Promise<MemoryRecord> {
    await client.query(
      "UPDATE pp_memory.requests SET result=$1 WHERE actor=$2 AND project_id=$3 AND request_id=$4",
      [result, actor, this.projectId, key],
    );
    return result;
  }
  async create(
    userId: string,
    kind: Kind,
    payload: Body,
    requestId: string,
  ): Promise<MemoryRecord> {
    if (kind !== "note" && kind !== "task")
      throw new InputError("資料類型錯誤");
    // Task creation accepts the internal validated open status, never other states.
    const body =
      kind === "note"
        ? validateNote(payload)
        : validateTask(
            Object.fromEntries(
              Object.entries(payload).filter(([key]) => key !== "status"),
            ),
          );
    if (
      kind === "task" &&
      payload.status !== undefined &&
      payload.status !== "open"
    )
      throw new InputError("新待辦必須從 open 開始");
    const key = uuid(requestId),
      digest = requestDigest("create_" + kind, body);
    return this.transaction(async (client) => {
      const actor = await this.member(client, userId),
        cached = await this.request(client, actor, key, digest);
      if (cached) return cached;
      const row = (
        await client.query(
          "INSERT INTO pp_memory.records(id,project_id,kind,body,created_by,updated_by) VALUES($1,$2,$3,$4,$5,$5) RETURNING *",
          [randomUUID(), this.projectId, kind, body, actor],
        )
      ).rows[0];
      const result = output(row);
      await this.event(
        client,
        actor,
        "create_" + kind,
        result.id,
        null,
        result,
      );
      return this.finish(client, actor, key, result);
    });
  }
  async update(
    userId: string,
    recordId: string,
    kind: Kind,
    expectedVersion: number,
    changes: Body,
    requestId: string,
    reason: string,
  ): Promise<MemoryRecord> {
    const id = uuid(recordId),
      key = uuid(requestId),
      why = text(reason, "更正／更新理由", 2000);
    const digest = requestDigest("update_" + kind, {
      id,
      expected_version: expectedVersion,
      changes,
      reason: why,
    });
    return this.transaction(async (client) => {
      const actor = await this.member(client, userId),
        cached = await this.request(client, actor, key, digest);
      if (cached) return cached;
      const old = (
        await client.query(
          "SELECT * FROM pp_memory.records WHERE id=$1 AND project_id=$2 AND kind=$3 FOR UPDATE",
          [id, this.projectId, kind],
        )
      ).rows[0];
      if (!old) throw new InputError("找不到這個專案中的紀錄");
      const body = applyChange(
        old.body,
        old.version,
        expectedVersion,
        changes,
        kind,
      );
      const row = (
        await client.query(
          "UPDATE pp_memory.records SET body=$1,version=version+1,updated_by=$2,updated_at=now() WHERE id=$3 AND project_id=$4 RETURNING *",
          [body, actor, id, this.projectId],
        )
      ).rows[0];
      const result = output(row);
      await this.event(
        client,
        actor,
        "update_" + kind,
        id,
        output(old),
        result,
        why,
      );
      return this.finish(client, actor, key, result);
    });
  }
  async readContext(
    userId: string,
    limit = 50,
  ): Promise<{
    project_id: string;
    limit_per_kind: number;
    notes: MemoryRecord[];
    tasks: MemoryRecord[];
    source: string;
  }> {
    if (!Number.isSafeInteger(limit)) throw new InputError("筆數必須是整數");
    limit = Math.max(1, Math.min(limit, 100));
    return this.transaction(async (client) => {
      const actor = await this.member(client, userId);
      const result = {
        project_id: this.projectId,
        limit_per_kind: limit,
        notes: [] as MemoryRecord[],
        tasks: [] as MemoryRecord[],
        source: "pp_memory",
      };
      for (const kind of ["note", "task"] as const) {
        const rows = await client.query(
          "SELECT * FROM pp_memory.records WHERE project_id=$1 AND kind=$2 ORDER BY updated_at DESC,id LIMIT $3",
          [this.projectId, kind, limit],
        );
        result[kind === "note" ? "notes" : "tasks"] = rows.rows.map(output);
      }
      await this.event(client, actor, "read_context");
      return result;
    });
  }
}
