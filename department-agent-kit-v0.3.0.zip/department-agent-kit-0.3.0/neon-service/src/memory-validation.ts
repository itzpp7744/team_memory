import { createHash } from "node:crypto";
export class InputError extends Error {}
export class Conflict extends InputError {}
export class Forbidden extends Error {}
export type Body = Record<string, unknown>;
export type Kind = "note" | "task";
export function text(value: unknown, field: string, limit = 20000): string {
  if (
    typeof value !== "string" ||
    !value.trim() ||
    Array.from(value).length > limit
  )
    throw new InputError(`${field} 必須有內容，且不超過 ${limit} 字元`);
  return value.trim();
}
function fields(value: Body, allowed: string[]) {
  if (
    !value ||
    typeof value !== "object" ||
    Array.isArray(value) ||
    Object.keys(value).some((k) => !allowed.includes(k))
  )
    throw new InputError("不允許的欄位");
}
export function validateNote(value: Body): Body {
  fields(value, ["title", "content", "category", "status", "source"]);
  const { category, status = "pending" } = value;
  if (!["fact", "hypothesis", "decision", "handoff"].includes(String(category)))
    throw new InputError("紀錄種類錯誤");
  if (
    !["pending", "confirmed", "void"].includes(String(status)) ||
    (category === "hypothesis" && status === "confirmed")
  )
    throw new InputError("假設不能標為已確認");
  return {
    title: text(value.title, "標題", 200),
    content: text(value.content, "內容"),
    category,
    status,
    source: text(value.source, "來源", 2000),
  };
}
export function validateTask(value: Body): Body {
  fields(value, ["title", "completion", "assignee", "due_date"]);
  const due_date = value.due_date ?? null;
  if (
    due_date !== null &&
    (typeof due_date !== "string" ||
      !/^\d{4}-\d{2}-\d{2}$/.test(due_date) ||
      due_date.startsWith("0000") ||
      Number.isNaN(Date.parse(due_date)) ||
      new Date(due_date).toISOString().slice(0, 10) !== due_date)
  )
    throw new InputError("日期使用有效的 YYYY-MM-DD");
  return {
    title: text(value.title, "標題", 200),
    completion: text(value.completion, "完成條件", 2000),
    assignee:
      value.assignee == null ? null : text(value.assignee, "負責人", 200),
    due_date,
    status: "open",
  };
}
export function applyChange(
  body: Body,
  version: number,
  expected: number,
  changes: Body,
  kind: Kind,
): Body {
  if (!Number.isSafeInteger(expected) || expected < 1)
    throw new InputError("必須提供讀取時的版本");
  if (version !== expected)
    throw new Conflict(`資料已被更新；目前版本 ${version}，請重新讀取後比較`);
  fields(
    changes,
    kind === "note"
      ? ["title", "content", "category", "status", "source"]
      : ["title", "completion", "assignee", "due_date", "status"],
  );
  if (!Object.keys(changes).length) throw new InputError("必須提供更新欄位");
  const merged = { ...body, ...changes };
  if (kind === "note") return validateNote(merged);
  const { status, ...task } = merged;
  if (!["open", "doing", "done", "cancelled"].includes(String(status)))
    throw new InputError("待辦狀態錯誤");
  return { ...validateTask(task), status };
}
function canonical(value: unknown): string {
  if (Array.isArray(value)) return "[" + value.map(canonical).join(",") + "]";
  if (value && typeof value === "object")
    return (
      "{" +
      Object.keys(value)
        .sort()
        .map((k) => JSON.stringify(k) + ":" + canonical((value as Body)[k]))
        .join(",") +
      "}"
    );
  return JSON.stringify(value);
}
export function requestDigest(operation: string, payload: Body): string {
  return createHash("sha256")
    .update(canonical([operation, payload]))
    .digest("hex");
}
export function uuid(value: unknown): string {
  if (
    typeof value !== "string" ||
    !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(
      value,
    )
  )
    throw new InputError("請求與紀錄編號必須是 UUID");
  return value.toLowerCase();
}
export function safeReturnURL(value: string, origin: string): string {
  const url = new URL(value, origin);
  if (
    url.origin !== origin ||
    url.pathname !== "/api/auth/oauth2/authorize" ||
    url.hash ||
    url.username ||
    url.password ||
    value.includes("\\")
  )
    throw new InputError("登入返回位置不合法");
  return url.pathname + url.search;
}
