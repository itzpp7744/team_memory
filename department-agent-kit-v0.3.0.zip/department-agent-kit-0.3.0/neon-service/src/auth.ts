import { betterAuth, type BetterAuthOptions } from "better-auth";
import { APIError } from "better-auth/api";
import { jwt } from "better-auth/plugins";
import { mcp } from "@better-auth/mcp";
import { cimd } from "@better-auth/cimd";
import { fetchClientMetadataResource } from "@better-auth/cimd/node";
import { PostgresDialect } from "kysely";
import type { Pool } from "pg";
import type { Config } from "./config.ts";
import type { MemoryStore } from "./memory-store.ts";
export function authOptions(config: Config, pool: Pool, store: MemoryStore) {
  return {
    appName: "PP 共用記憶",
    baseURL: config.origin,
    basePath: "/api/auth",
    secret: config.secret,
    database: {
      dialect: new PostgresDialect({ pool }),
      type: "postgres",
      schemaName: "pp_auth",
      transaction: true,
    },
    trustedOrigins: [config.origin],
    emailAndPassword: { enabled: false },
    socialProviders: {
      google: {
        clientId: config.googleClientId,
        clientSecret: config.googleClientSecret,
        scope: ["openid", "profile", "email"],
        disableDefaultScope: true,
        includeGrantedScopes: false,
        accessType: "online",
        prompt: "select_account",
      },
    },
    account: { accountLinking: { enabled: false }, encryptOAuthTokens: true },
    session: {
      expiresIn: 60 * 60 * 8,
      updateAge: 60 * 60,
      cookieCache: { enabled: false },
    },
    disabledPaths: [
      "/token",
      "/sign-up/email",
      "/sign-in/email",
      // Only our fixed-parameter /sign-in form can start Google login.
      "/sign-in/social",
      "/update-user",
      "/change-email",
      "/link-social",
      "/unlink-account",
      "/delete-user",
    ],
    rateLimit: { enabled: true, storage: "database", window: 60, max: 60 },
    advanced: {
      useSecureCookies: config.origin.startsWith("https:"),
      defaultCookieAttributes: { httpOnly: true, sameSite: "lax" },
    },
    logger: {
      level: "error",
      log: () => console.error("authentication_operation_failed"),
    },
    databaseHooks: {
      user: {
        create: {
          before: async (user) => {
            if (!user.emailVerified || !(await store.allowedEmail(user.email)))
              throw new APIError("FORBIDDEN", {
                message: "此 Google 帳號未獲專案授權",
              });
            return { data: user };
          },
        },
      },
      session: {
        create: {
          before: async (session) => {
            try {
              await store.bindIdentity(session.userId);
            } catch {
              throw new APIError("FORBIDDEN", {
                message: "此 Google 帳號未獲專案授權或已停用",
              });
            }
            return { data: session };
          },
        },
      },
    },
    plugins: [
      jwt(),
      mcp({
        loginPage: "/sign-in",
        consentPage: "/consent",
        resource: config.resource,
        scopes: ["openid", "profile", "email", "offline_access", "mcp:tools"],
        accessTokenExpiresIn: 600,
        allowDynamicClientRegistration: true,
        allowUnauthenticatedClientRegistration: true,
        clientRegistrationDefaultApplicationType: "infer",
        clientRegistrationRequirePKCE: true,
        clientPrivileges: async () => false,
      }),
      cimd({ fetchClientMetadataResource, metadataProfile: "mcp-2026-07-28" }),
    ],
  } satisfies BetterAuthOptions;
}
export function createAuth(config: Config, pool: Pool, store: MemoryStore) {
  return betterAuth(authOptions(config, pool, store));
}
export type Auth = ReturnType<typeof createAuth>;
