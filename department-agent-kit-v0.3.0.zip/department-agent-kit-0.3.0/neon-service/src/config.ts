export interface Config {
  origin: string;
  resource: string;
  projectId: string;
  memoryDatabaseURL: string;
  authDatabaseURL: string;
  secret: string;
  googleClientId: string;
  googleClientSecret: string;
  maxBodyBytes: number;
}
export function loadConfig(env: NodeJS.ProcessEnv = process.env): Config {
  const required = (key: string) => {
    const value = env[key]?.trim();
    if (!value || value.startsWith("${"))
      throw new Error(`缺少環境變數 ${key}`);
    return value;
  };
  const base = new URL(required("PP_BASE_URL"));
  if (
    base.username ||
    base.password ||
    base.search ||
    base.hash ||
    base.pathname !== "/" ||
    (base.protocol !== "https:" &&
      !(
        base.protocol === "http:" &&
        ["localhost", "127.0.0.1", "[::1]"].includes(base.hostname)
      ))
  )
    throw new Error("PP_BASE_URL 必須是 HTTPS 網站 origin；僅本機可使用 HTTP");
  const memoryDatabaseURL = required("PP_MEMORY_DATABASE_URL"),
    authDatabaseURL = required("PP_AUTH_DATABASE_URL");
  const dbs = [new URL(memoryDatabaseURL), new URL(authDatabaseURL)];
  if (
    dbs.some((db) => !["postgres:", "postgresql:"].includes(db.protocol)) ||
    dbs[0].username === dbs[1].username
  )
    throw new Error("記憶與登入資料庫必須使用兩個不同的受限角色");
  for (const db of dbs) {
    const local =
      ["localhost", "127.0.0.1", "[::1]"].includes(db.hostname) ||
      (!db.hostname && (db.searchParams.get("host") ?? "").startsWith("/"));
    if (
      !local &&
      (db.searchParams.get("sslmode") !== "verify-full" ||
        db.searchParams.get("ssl") === "false")
    )
      throw new Error("遠端資料庫必須使用 sslmode=verify-full 驗證伺服器憑證");
  }
  const secret = required("BETTER_AUTH_SECRET");
  if (secret.length < 32)
    throw new Error("BETTER_AUTH_SECRET 至少需要 32 字元");
  const projectId = required("PP_PROJECT_ID");
  if (!/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,99}$/.test(projectId))
    throw new Error("PP_PROJECT_ID 格式錯誤");
  return {
    origin: base.origin,
    resource: base.origin + "/mcp",
    projectId,
    memoryDatabaseURL,
    authDatabaseURL,
    secret,
    googleClientId: required("GOOGLE_CLIENT_ID"),
    googleClientSecret: required("GOOGLE_CLIENT_SECRET"),
    maxBodyBytes: 131072,
  };
}
export async function assertRuntimePrivileges(
  memory: import("pg").Pool,
  auth: import("pg").Pool,
): Promise<void> {
  for (const [pool, isMemory] of [
    [memory, true],
    [auth, false],
  ] as const) {
    const elevated = (
      await pool.query(
        "SELECT rolsuper OR rolcreaterole OR rolcreatedb AS elevated FROM pg_roles WHERE rolname=current_user",
      )
    ).rows[0]?.elevated;
    const schema = (
      await pool.query(
        "SELECT has_schema_privilege(current_user,'pp_memory','CREATE') OR has_schema_privilege(current_user,'pp_auth','CREATE') OR has_schema_privilege(current_user,'public','CREATE') OR has_database_privilege(current_user,current_database(),'CREATE') AS elevated",
      )
    ).rows[0]?.elevated;
    const forbidden = isMemory
      ? [
          "pp_memory.members",
          "pp_memory.project_members",
          "pp_memory.identity_bindings",
          "pp_memory.events",
        ]
      : [
          "pp_memory.members",
          "pp_memory.records",
          "pp_memory.requests",
          "pp_memory.events",
        ];
    const rows = await pool.query(
      "SELECT c.relname FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE (n.nspname||'.'||c.relname)=ANY($1::text[]) AND (has_table_privilege(current_user,c.oid,'UPDATE,DELETE,TRUNCATE') OR has_any_column_privilege(current_user,c.oid,'UPDATE'))",
      [forbidden],
    );
    const insertForbidden = isMemory
      ? ["pp_memory.members", "pp_memory.project_members"]
      : forbidden;
    const inserts = await pool.query(
      "SELECT c.relname FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE (n.nspname||'.'||c.relname)=ANY($1::text[]) AND has_any_column_privilege(current_user,c.oid,'INSERT')",
      [insertForbidden],
    );
    if (elevated || schema || rows.rowCount || inserts.rowCount)
      throw new Error("資料庫 runtime 權限過高；請使用獨立受限角色");
  }
}
