import { defineConfig } from "@neon/config/v1";
function required(name: string): string {
  const value = process.env[name];
  if (!value || value.startsWith("${"))
    throw new Error(`Missing deployment environment: ${name}`);
  return value;
}
export default defineConfig({
  functions: {
    ppmemory: {
      name: "PP Team Memory",
      source: "src/index.ts",
      env: {
        PP_BASE_URL: required("PP_BASE_URL"),
        PP_PROJECT_ID: required("PP_PROJECT_ID"),
        PP_MEMORY_DATABASE_URL: required("PP_MEMORY_DATABASE_URL"),
        PP_AUTH_DATABASE_URL: required("PP_AUTH_DATABASE_URL"),
        // Override both injected owner credentials; the function must never receive them.
        DATABASE_URL: required("PP_MEMORY_DATABASE_URL"),
        DATABASE_URL_UNPOOLED: required("PP_MEMORY_DATABASE_URL"),
        BETTER_AUTH_SECRET: required("BETTER_AUTH_SECRET"),
        GOOGLE_CLIENT_ID: required("GOOGLE_CLIENT_ID"),
        GOOGLE_CLIENT_SECRET: required("GOOGLE_CLIENT_SECRET"),
      },
    },
  },
});
