-- Administrator-only, one-time migration. Existing schema is intentionally an error.
BEGIN;
DO $$ BEGIN
 IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname='pp_memory_runtime') THEN CREATE ROLE pp_memory_runtime NOLOGIN; END IF;
 IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname='pp_auth_runtime') THEN CREATE ROLE pp_auth_runtime NOLOGIN; END IF;
END $$;
CREATE SCHEMA pp_memory;
REVOKE ALL ON SCHEMA pp_memory FROM PUBLIC;
CREATE TABLE pp_memory.members (
 id text PRIMARY KEY,
 email text NOT NULL UNIQUE CHECK (email=lower(email) AND email=trim(email)),
 display_name text NOT NULL,
 active boolean NOT NULL DEFAULT true
);
CREATE TABLE pp_memory.project_members (
 project_id text NOT NULL,
 member_id text NOT NULL REFERENCES pp_memory.members(id),
 PRIMARY KEY(project_id,member_id)
);
CREATE TABLE pp_memory.identity_bindings (
 auth_user_id text PRIMARY KEY,
 member_id text NOT NULL UNIQUE REFERENCES pp_memory.members(id),
 bound_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE pp_memory.records (
 id uuid PRIMARY KEY,
 project_id text NOT NULL,
 kind text NOT NULL CHECK (kind IN ('note','task')),
 body jsonb NOT NULL,
 version integer NOT NULL DEFAULT 1 CHECK(version>0),
 created_by text NOT NULL REFERENCES pp_memory.members(id),
 updated_by text NOT NULL REFERENCES pp_memory.members(id),
 updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX records_project_kind ON pp_memory.records(project_id,kind,updated_at DESC);
CREATE TABLE pp_memory.requests (
 actor text NOT NULL REFERENCES pp_memory.members(id),
 project_id text NOT NULL,
 request_id uuid NOT NULL,
 digest text NOT NULL,
 result jsonb,
 PRIMARY KEY(actor,project_id,request_id)
);
CREATE TABLE pp_memory.events (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 actor text NOT NULL REFERENCES pp_memory.members(id),
 project_id text NOT NULL,
 action text NOT NULL,
 record_id uuid,
 previous jsonb,
 current jsonb,
 reason text,
 created_at timestamptz NOT NULL DEFAULT now()
);
GRANT USAGE ON SCHEMA pp_memory TO pp_memory_runtime;
GRANT SELECT ON pp_memory.members,pp_memory.project_members,pp_memory.identity_bindings TO pp_memory_runtime;
GRANT INSERT ON pp_memory.identity_bindings TO pp_memory_runtime;
GRANT SELECT,INSERT,UPDATE ON pp_memory.records,pp_memory.requests TO pp_memory_runtime;
GRANT INSERT ON pp_memory.events TO pp_memory_runtime;
GRANT USAGE ON SEQUENCE pp_memory.events_id_seq TO pp_memory_runtime;
COMMIT;
