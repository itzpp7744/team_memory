# PP 團隊 AI 工作區

版本 **0.3.0**。目前成員與新人都從 [START_HERE.md](START_HERE.md) 開始：取得姓名與個人工作 Google email、由管理者核准，再讓 Claude 與 Claude Code 連上同一份 PP 共用記憶。Google Drive 文件與 Obsidian 稍後設定，不影響先驗收記憶。

程式與說明的交付位置：[itzpp7744/team_memory](https://github.com/itzpp7744/team_memory)。本包不包含課程文件原文，也不修改成員的全域 AI 設定。

## 記憶與文件各放在哪裡

| 位置 | 用途 |
| --- | --- |
| Google 登入＋Neon 服務 | 保存使用者同意共享的結構化筆記，也就是固定欄位的決策、交接與待辦；專案為 `pp-product` |
| 私有工作區 | 未送出的記憶草稿、文件初稿、暫存、專案 Skills 與本機設定 |
| Google Drive 共享區 | 正式文件、同一套資料夾分類及各人的修改提案；權限另由管理者授予 |
| 共用版本標記 | 核對專案、套件與資產版本，防止裝錯專案或混用版本；不是權限控制 |

共用記憶不會自動同步所有聊天。Google 登入只要求 `openid`、`profile`、`email`，不取得 Gmail 或 Drive 讀取權限。成員不需要 Neon 管理用 MCP 或資料庫密碼；Neon Free 有配額及休眠，不承諾持續可用。

## 完整工作區提供什麼

6 個 Skills：`pp-start-work`、`pp-memory-handoff`、`pp-pm-documents`、`pp-onboarding`、`pp-team-improvement`、`pp-sync-check`。它們安裝到本人工作區的 `.claude/skills`，全員內容一致。本機安裝與草稿工具只需 Python 3.11 以上，不用安裝伺服器套件。

先完成記憶連線後，完整安裝沿用同一私有工作區，plan／install 都傳入正式 `--mcp-url`，保留已有 `.mcp.json`。同名設定衝突時停止，不擅改。文件原稿留 Drive；本機草稿在收到服務的實際 `id`、`version` 前都不算正式保存。

## 交付與驗收狀態

2026-10-28 真人驗收通過（PASS）：Google 登入、Claude Code 與網頁 Claude 連線、Neon 保存及雙端交換均已驗證。Code 新增版本 1 → 網頁讀回同一筆並更新成版本 2 → Code 實際讀回同一筆版本 2；證據見 [驗證紀錄](docs/VERIFICATION.md)。手機、Windows、Drive 分享／同步與 Obsidian 仍未實測；GitHub 發布版本以 repo 根目錄 manifest.json 為準。

Google Drive API、Gmail 收發及 Google Slides 自動產生不在此版能力內。既有 Python／Microsoft Entra 服務保留為替代部署路線，見 [Microsoft 設定](docs/MICROSOFT_SERVICE_SETUP.md)；Google／Neon 是新人優先路線。

[管理者設定](docs/ADMIN_SETUP.md) · [已知限制](docs/KNOWN_LIMITATIONS.md) · [驗收清單](docs/ACCEPTANCE.md) · [既有驗證紀錄](docs/VERIFICATION.md)

後續文件與 Obsidian 設定見 [上手流程](team-assets/reference/ONBOARDING.md)。要提功能或分享 Skill，走 [團隊改進與發布](team-assets/reference/TEAM_EVOLUTION.md)；新人不需為新增姓名重新發布套件，服務核准與其他平台權限仍須各自處理。
